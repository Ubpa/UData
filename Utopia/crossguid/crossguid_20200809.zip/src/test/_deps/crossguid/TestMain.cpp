#include "Test.hpp"
#include <iostream>

int main()
{
	return test(std::cout);
}
