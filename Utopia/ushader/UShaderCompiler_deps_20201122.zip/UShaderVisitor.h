
// Generated from UShader.g4 by ANTLR 4.8

#pragma once


#include "antlr4-runtime.h"
#include "UShaderParser.h"


namespace Ubpa::Utopia::details {

/**
 * This class defines an abstract visitor for a parse tree
 * produced by UShaderParser.
 */
class  UShaderVisitor : public antlr4::tree::AbstractParseTreeVisitor {
public:

  /**
   * Visit parse trees produced by UShaderParser.
   */
    virtual antlrcpp::Any visitShader(UShaderParser::ShaderContext *context) = 0;

    virtual antlrcpp::Any visitShader_name(UShaderParser::Shader_nameContext *context) = 0;

    virtual antlrcpp::Any visitHlsl(UShaderParser::HlslContext *context) = 0;

    virtual antlrcpp::Any visitProperty_block(UShaderParser::Property_blockContext *context) = 0;

    virtual antlrcpp::Any visitProperty(UShaderParser::PropertyContext *context) = 0;

    virtual antlrcpp::Any visitProperty_bool(UShaderParser::Property_boolContext *context) = 0;

    virtual antlrcpp::Any visitProperty_int(UShaderParser::Property_intContext *context) = 0;

    virtual antlrcpp::Any visitProperty_uint(UShaderParser::Property_uintContext *context) = 0;

    virtual antlrcpp::Any visitProperty_float(UShaderParser::Property_floatContext *context) = 0;

    virtual antlrcpp::Any visitProperty_double(UShaderParser::Property_doubleContext *context) = 0;

    virtual antlrcpp::Any visitProperty_bool2(UShaderParser::Property_bool2Context *context) = 0;

    virtual antlrcpp::Any visitProperty_bool3(UShaderParser::Property_bool3Context *context) = 0;

    virtual antlrcpp::Any visitProperty_bool4(UShaderParser::Property_bool4Context *context) = 0;

    virtual antlrcpp::Any visitProperty_int2(UShaderParser::Property_int2Context *context) = 0;

    virtual antlrcpp::Any visitProperty_int3(UShaderParser::Property_int3Context *context) = 0;

    virtual antlrcpp::Any visitProperty_int4(UShaderParser::Property_int4Context *context) = 0;

    virtual antlrcpp::Any visitProperty_uint2(UShaderParser::Property_uint2Context *context) = 0;

    virtual antlrcpp::Any visitProperty_uint3(UShaderParser::Property_uint3Context *context) = 0;

    virtual antlrcpp::Any visitProperty_uint4(UShaderParser::Property_uint4Context *context) = 0;

    virtual antlrcpp::Any visitProperty_float2(UShaderParser::Property_float2Context *context) = 0;

    virtual antlrcpp::Any visitProperty_float3(UShaderParser::Property_float3Context *context) = 0;

    virtual antlrcpp::Any visitProperty_float4(UShaderParser::Property_float4Context *context) = 0;

    virtual antlrcpp::Any visitProperty_double2(UShaderParser::Property_double2Context *context) = 0;

    virtual antlrcpp::Any visitProperty_double3(UShaderParser::Property_double3Context *context) = 0;

    virtual antlrcpp::Any visitProperty_double4(UShaderParser::Property_double4Context *context) = 0;

    virtual antlrcpp::Any visitProperty_2D(UShaderParser::Property_2DContext *context) = 0;

    virtual antlrcpp::Any visitProperty_cube(UShaderParser::Property_cubeContext *context) = 0;

    virtual antlrcpp::Any visitProperty_rgb(UShaderParser::Property_rgbContext *context) = 0;

    virtual antlrcpp::Any visitProperty_rgba(UShaderParser::Property_rgbaContext *context) = 0;

    virtual antlrcpp::Any visitVal_bool(UShaderParser::Val_boolContext *context) = 0;

    virtual antlrcpp::Any visitVal_int(UShaderParser::Val_intContext *context) = 0;

    virtual antlrcpp::Any visitVal_uint(UShaderParser::Val_uintContext *context) = 0;

    virtual antlrcpp::Any visitVal_float(UShaderParser::Val_floatContext *context) = 0;

    virtual antlrcpp::Any visitVal_double(UShaderParser::Val_doubleContext *context) = 0;

    virtual antlrcpp::Any visitVal_bool2(UShaderParser::Val_bool2Context *context) = 0;

    virtual antlrcpp::Any visitVal_bool3(UShaderParser::Val_bool3Context *context) = 0;

    virtual antlrcpp::Any visitVal_bool4(UShaderParser::Val_bool4Context *context) = 0;

    virtual antlrcpp::Any visitVal_int2(UShaderParser::Val_int2Context *context) = 0;

    virtual antlrcpp::Any visitVal_int3(UShaderParser::Val_int3Context *context) = 0;

    virtual antlrcpp::Any visitVal_int4(UShaderParser::Val_int4Context *context) = 0;

    virtual antlrcpp::Any visitVal_uint2(UShaderParser::Val_uint2Context *context) = 0;

    virtual antlrcpp::Any visitVal_uint3(UShaderParser::Val_uint3Context *context) = 0;

    virtual antlrcpp::Any visitVal_uint4(UShaderParser::Val_uint4Context *context) = 0;

    virtual antlrcpp::Any visitVal_float2(UShaderParser::Val_float2Context *context) = 0;

    virtual antlrcpp::Any visitVal_float3(UShaderParser::Val_float3Context *context) = 0;

    virtual antlrcpp::Any visitVal_float4(UShaderParser::Val_float4Context *context) = 0;

    virtual antlrcpp::Any visitVal_double2(UShaderParser::Val_double2Context *context) = 0;

    virtual antlrcpp::Any visitVal_double3(UShaderParser::Val_double3Context *context) = 0;

    virtual antlrcpp::Any visitVal_double4(UShaderParser::Val_double4Context *context) = 0;

    virtual antlrcpp::Any visitVal_tex2d(UShaderParser::Val_tex2dContext *context) = 0;

    virtual antlrcpp::Any visitDefault_texture_2d(UShaderParser::Default_texture_2dContext *context) = 0;

    virtual antlrcpp::Any visitVal_texcube(UShaderParser::Val_texcubeContext *context) = 0;

    virtual antlrcpp::Any visitDefault_texture_cube(UShaderParser::Default_texture_cubeContext *context) = 0;

    virtual antlrcpp::Any visitProperty_name(UShaderParser::Property_nameContext *context) = 0;

    virtual antlrcpp::Any visitDisplay_name(UShaderParser::Display_nameContext *context) = 0;

    virtual antlrcpp::Any visitRoot_signature(UShaderParser::Root_signatureContext *context) = 0;

    virtual antlrcpp::Any visitRoot_parameter(UShaderParser::Root_parameterContext *context) = 0;

    virtual antlrcpp::Any visitRegister_index(UShaderParser::Register_indexContext *context) = 0;

    virtual antlrcpp::Any visitShader_register(UShaderParser::Shader_registerContext *context) = 0;

    virtual antlrcpp::Any visitRegister_space(UShaderParser::Register_spaceContext *context) = 0;

    virtual antlrcpp::Any visitRegister_num(UShaderParser::Register_numContext *context) = 0;

    virtual antlrcpp::Any visitPass(UShaderParser::PassContext *context) = 0;

    virtual antlrcpp::Any visitVs(UShaderParser::VsContext *context) = 0;

    virtual antlrcpp::Any visitPs(UShaderParser::PsContext *context) = 0;

    virtual antlrcpp::Any visitPass_statement(UShaderParser::Pass_statementContext *context) = 0;

    virtual antlrcpp::Any visitTags(UShaderParser::TagsContext *context) = 0;

    virtual antlrcpp::Any visitTag(UShaderParser::TagContext *context) = 0;

    virtual antlrcpp::Any visitRender_state_setup(UShaderParser::Render_state_setupContext *context) = 0;

    virtual antlrcpp::Any visitFill(UShaderParser::FillContext *context) = 0;

    virtual antlrcpp::Any visitCull(UShaderParser::CullContext *context) = 0;

    virtual antlrcpp::Any visitZtest(UShaderParser::ZtestContext *context) = 0;

    virtual antlrcpp::Any visitZwrite_off(UShaderParser::Zwrite_offContext *context) = 0;

    virtual antlrcpp::Any visitBlend(UShaderParser::BlendContext *context) = 0;

    virtual antlrcpp::Any visitBlend_expr(UShaderParser::Blend_exprContext *context) = 0;

    virtual antlrcpp::Any visitIndex(UShaderParser::IndexContext *context) = 0;

    virtual antlrcpp::Any visitBlend_src_factor_color(UShaderParser::Blend_src_factor_colorContext *context) = 0;

    virtual antlrcpp::Any visitBlend_dst_factor_color(UShaderParser::Blend_dst_factor_colorContext *context) = 0;

    virtual antlrcpp::Any visitBlend_src_factor_alpha(UShaderParser::Blend_src_factor_alphaContext *context) = 0;

    virtual antlrcpp::Any visitBlend_dst_factor_alpha(UShaderParser::Blend_dst_factor_alphaContext *context) = 0;

    virtual antlrcpp::Any visitBlend_factor(UShaderParser::Blend_factorContext *context) = 0;

    virtual antlrcpp::Any visitBlend_op(UShaderParser::Blend_opContext *context) = 0;

    virtual antlrcpp::Any visitBlend_op_color(UShaderParser::Blend_op_colorContext *context) = 0;

    virtual antlrcpp::Any visitBlend_op_alpha(UShaderParser::Blend_op_alphaContext *context) = 0;

    virtual antlrcpp::Any visitColor_mask(UShaderParser::Color_maskContext *context) = 0;

    virtual antlrcpp::Any visitColor_mask_value(UShaderParser::Color_mask_valueContext *context) = 0;

    virtual antlrcpp::Any visitStencil(UShaderParser::StencilContext *context) = 0;

    virtual antlrcpp::Any visitStencil_state_setup(UShaderParser::Stencil_state_setupContext *context) = 0;

    virtual antlrcpp::Any visitStencil_ref(UShaderParser::Stencil_refContext *context) = 0;

    virtual antlrcpp::Any visitStencil_mask_read(UShaderParser::Stencil_mask_readContext *context) = 0;

    virtual antlrcpp::Any visitStencil_mask_write(UShaderParser::Stencil_mask_writeContext *context) = 0;

    virtual antlrcpp::Any visitStencil_compare(UShaderParser::Stencil_compareContext *context) = 0;

    virtual antlrcpp::Any visitStencil_pass(UShaderParser::Stencil_passContext *context) = 0;

    virtual antlrcpp::Any visitStencil_fail(UShaderParser::Stencil_failContext *context) = 0;

    virtual antlrcpp::Any visitStencil_zfail(UShaderParser::Stencil_zfailContext *context) = 0;

    virtual antlrcpp::Any visitStencil_op(UShaderParser::Stencil_opContext *context) = 0;

    virtual antlrcpp::Any visitQueue(UShaderParser::QueueContext *context) = 0;

    virtual antlrcpp::Any visitVal_queue(UShaderParser::Val_queueContext *context) = 0;

    virtual antlrcpp::Any visitQueue_key(UShaderParser::Queue_keyContext *context) = 0;


};

}  // namespace Ubpa::Utopia::details
