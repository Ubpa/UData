
// Generated from UShader.g4 by ANTLR 4.8

#pragma once


#include "antlr4-runtime.h"
#include "UShaderParser.h"


namespace Ubpa::Utopia::details {

/**
 * This interface defines an abstract listener for a parse tree produced by UShaderParser.
 */
class  UShaderListener : public antlr4::tree::ParseTreeListener {
public:

  virtual void enterShader(UShaderParser::ShaderContext *ctx) = 0;
  virtual void exitShader(UShaderParser::ShaderContext *ctx) = 0;

  virtual void enterShader_name(UShaderParser::Shader_nameContext *ctx) = 0;
  virtual void exitShader_name(UShaderParser::Shader_nameContext *ctx) = 0;

  virtual void enterHlsl(UShaderParser::HlslContext *ctx) = 0;
  virtual void exitHlsl(UShaderParser::HlslContext *ctx) = 0;

  virtual void enterProperty_block(UShaderParser::Property_blockContext *ctx) = 0;
  virtual void exitProperty_block(UShaderParser::Property_blockContext *ctx) = 0;

  virtual void enterProperty(UShaderParser::PropertyContext *ctx) = 0;
  virtual void exitProperty(UShaderParser::PropertyContext *ctx) = 0;

  virtual void enterProperty_bool(UShaderParser::Property_boolContext *ctx) = 0;
  virtual void exitProperty_bool(UShaderParser::Property_boolContext *ctx) = 0;

  virtual void enterProperty_int(UShaderParser::Property_intContext *ctx) = 0;
  virtual void exitProperty_int(UShaderParser::Property_intContext *ctx) = 0;

  virtual void enterProperty_uint(UShaderParser::Property_uintContext *ctx) = 0;
  virtual void exitProperty_uint(UShaderParser::Property_uintContext *ctx) = 0;

  virtual void enterProperty_float(UShaderParser::Property_floatContext *ctx) = 0;
  virtual void exitProperty_float(UShaderParser::Property_floatContext *ctx) = 0;

  virtual void enterProperty_double(UShaderParser::Property_doubleContext *ctx) = 0;
  virtual void exitProperty_double(UShaderParser::Property_doubleContext *ctx) = 0;

  virtual void enterProperty_bool2(UShaderParser::Property_bool2Context *ctx) = 0;
  virtual void exitProperty_bool2(UShaderParser::Property_bool2Context *ctx) = 0;

  virtual void enterProperty_bool3(UShaderParser::Property_bool3Context *ctx) = 0;
  virtual void exitProperty_bool3(UShaderParser::Property_bool3Context *ctx) = 0;

  virtual void enterProperty_bool4(UShaderParser::Property_bool4Context *ctx) = 0;
  virtual void exitProperty_bool4(UShaderParser::Property_bool4Context *ctx) = 0;

  virtual void enterProperty_int2(UShaderParser::Property_int2Context *ctx) = 0;
  virtual void exitProperty_int2(UShaderParser::Property_int2Context *ctx) = 0;

  virtual void enterProperty_int3(UShaderParser::Property_int3Context *ctx) = 0;
  virtual void exitProperty_int3(UShaderParser::Property_int3Context *ctx) = 0;

  virtual void enterProperty_int4(UShaderParser::Property_int4Context *ctx) = 0;
  virtual void exitProperty_int4(UShaderParser::Property_int4Context *ctx) = 0;

  virtual void enterProperty_uint2(UShaderParser::Property_uint2Context *ctx) = 0;
  virtual void exitProperty_uint2(UShaderParser::Property_uint2Context *ctx) = 0;

  virtual void enterProperty_uint3(UShaderParser::Property_uint3Context *ctx) = 0;
  virtual void exitProperty_uint3(UShaderParser::Property_uint3Context *ctx) = 0;

  virtual void enterProperty_uint4(UShaderParser::Property_uint4Context *ctx) = 0;
  virtual void exitProperty_uint4(UShaderParser::Property_uint4Context *ctx) = 0;

  virtual void enterProperty_float2(UShaderParser::Property_float2Context *ctx) = 0;
  virtual void exitProperty_float2(UShaderParser::Property_float2Context *ctx) = 0;

  virtual void enterProperty_float3(UShaderParser::Property_float3Context *ctx) = 0;
  virtual void exitProperty_float3(UShaderParser::Property_float3Context *ctx) = 0;

  virtual void enterProperty_float4(UShaderParser::Property_float4Context *ctx) = 0;
  virtual void exitProperty_float4(UShaderParser::Property_float4Context *ctx) = 0;

  virtual void enterProperty_double2(UShaderParser::Property_double2Context *ctx) = 0;
  virtual void exitProperty_double2(UShaderParser::Property_double2Context *ctx) = 0;

  virtual void enterProperty_double3(UShaderParser::Property_double3Context *ctx) = 0;
  virtual void exitProperty_double3(UShaderParser::Property_double3Context *ctx) = 0;

  virtual void enterProperty_double4(UShaderParser::Property_double4Context *ctx) = 0;
  virtual void exitProperty_double4(UShaderParser::Property_double4Context *ctx) = 0;

  virtual void enterProperty_2D(UShaderParser::Property_2DContext *ctx) = 0;
  virtual void exitProperty_2D(UShaderParser::Property_2DContext *ctx) = 0;

  virtual void enterProperty_cube(UShaderParser::Property_cubeContext *ctx) = 0;
  virtual void exitProperty_cube(UShaderParser::Property_cubeContext *ctx) = 0;

  virtual void enterProperty_rgb(UShaderParser::Property_rgbContext *ctx) = 0;
  virtual void exitProperty_rgb(UShaderParser::Property_rgbContext *ctx) = 0;

  virtual void enterProperty_rgba(UShaderParser::Property_rgbaContext *ctx) = 0;
  virtual void exitProperty_rgba(UShaderParser::Property_rgbaContext *ctx) = 0;

  virtual void enterVal_bool(UShaderParser::Val_boolContext *ctx) = 0;
  virtual void exitVal_bool(UShaderParser::Val_boolContext *ctx) = 0;

  virtual void enterVal_int(UShaderParser::Val_intContext *ctx) = 0;
  virtual void exitVal_int(UShaderParser::Val_intContext *ctx) = 0;

  virtual void enterVal_uint(UShaderParser::Val_uintContext *ctx) = 0;
  virtual void exitVal_uint(UShaderParser::Val_uintContext *ctx) = 0;

  virtual void enterVal_float(UShaderParser::Val_floatContext *ctx) = 0;
  virtual void exitVal_float(UShaderParser::Val_floatContext *ctx) = 0;

  virtual void enterVal_double(UShaderParser::Val_doubleContext *ctx) = 0;
  virtual void exitVal_double(UShaderParser::Val_doubleContext *ctx) = 0;

  virtual void enterVal_bool2(UShaderParser::Val_bool2Context *ctx) = 0;
  virtual void exitVal_bool2(UShaderParser::Val_bool2Context *ctx) = 0;

  virtual void enterVal_bool3(UShaderParser::Val_bool3Context *ctx) = 0;
  virtual void exitVal_bool3(UShaderParser::Val_bool3Context *ctx) = 0;

  virtual void enterVal_bool4(UShaderParser::Val_bool4Context *ctx) = 0;
  virtual void exitVal_bool4(UShaderParser::Val_bool4Context *ctx) = 0;

  virtual void enterVal_int2(UShaderParser::Val_int2Context *ctx) = 0;
  virtual void exitVal_int2(UShaderParser::Val_int2Context *ctx) = 0;

  virtual void enterVal_int3(UShaderParser::Val_int3Context *ctx) = 0;
  virtual void exitVal_int3(UShaderParser::Val_int3Context *ctx) = 0;

  virtual void enterVal_int4(UShaderParser::Val_int4Context *ctx) = 0;
  virtual void exitVal_int4(UShaderParser::Val_int4Context *ctx) = 0;

  virtual void enterVal_uint2(UShaderParser::Val_uint2Context *ctx) = 0;
  virtual void exitVal_uint2(UShaderParser::Val_uint2Context *ctx) = 0;

  virtual void enterVal_uint3(UShaderParser::Val_uint3Context *ctx) = 0;
  virtual void exitVal_uint3(UShaderParser::Val_uint3Context *ctx) = 0;

  virtual void enterVal_uint4(UShaderParser::Val_uint4Context *ctx) = 0;
  virtual void exitVal_uint4(UShaderParser::Val_uint4Context *ctx) = 0;

  virtual void enterVal_float2(UShaderParser::Val_float2Context *ctx) = 0;
  virtual void exitVal_float2(UShaderParser::Val_float2Context *ctx) = 0;

  virtual void enterVal_float3(UShaderParser::Val_float3Context *ctx) = 0;
  virtual void exitVal_float3(UShaderParser::Val_float3Context *ctx) = 0;

  virtual void enterVal_float4(UShaderParser::Val_float4Context *ctx) = 0;
  virtual void exitVal_float4(UShaderParser::Val_float4Context *ctx) = 0;

  virtual void enterVal_double2(UShaderParser::Val_double2Context *ctx) = 0;
  virtual void exitVal_double2(UShaderParser::Val_double2Context *ctx) = 0;

  virtual void enterVal_double3(UShaderParser::Val_double3Context *ctx) = 0;
  virtual void exitVal_double3(UShaderParser::Val_double3Context *ctx) = 0;

  virtual void enterVal_double4(UShaderParser::Val_double4Context *ctx) = 0;
  virtual void exitVal_double4(UShaderParser::Val_double4Context *ctx) = 0;

  virtual void enterVal_tex2d(UShaderParser::Val_tex2dContext *ctx) = 0;
  virtual void exitVal_tex2d(UShaderParser::Val_tex2dContext *ctx) = 0;

  virtual void enterDefault_texture_2d(UShaderParser::Default_texture_2dContext *ctx) = 0;
  virtual void exitDefault_texture_2d(UShaderParser::Default_texture_2dContext *ctx) = 0;

  virtual void enterVal_texcube(UShaderParser::Val_texcubeContext *ctx) = 0;
  virtual void exitVal_texcube(UShaderParser::Val_texcubeContext *ctx) = 0;

  virtual void enterDefault_texture_cube(UShaderParser::Default_texture_cubeContext *ctx) = 0;
  virtual void exitDefault_texture_cube(UShaderParser::Default_texture_cubeContext *ctx) = 0;

  virtual void enterProperty_name(UShaderParser::Property_nameContext *ctx) = 0;
  virtual void exitProperty_name(UShaderParser::Property_nameContext *ctx) = 0;

  virtual void enterDisplay_name(UShaderParser::Display_nameContext *ctx) = 0;
  virtual void exitDisplay_name(UShaderParser::Display_nameContext *ctx) = 0;

  virtual void enterRoot_signature(UShaderParser::Root_signatureContext *ctx) = 0;
  virtual void exitRoot_signature(UShaderParser::Root_signatureContext *ctx) = 0;

  virtual void enterRoot_parameter(UShaderParser::Root_parameterContext *ctx) = 0;
  virtual void exitRoot_parameter(UShaderParser::Root_parameterContext *ctx) = 0;

  virtual void enterRegister_index(UShaderParser::Register_indexContext *ctx) = 0;
  virtual void exitRegister_index(UShaderParser::Register_indexContext *ctx) = 0;

  virtual void enterShader_register(UShaderParser::Shader_registerContext *ctx) = 0;
  virtual void exitShader_register(UShaderParser::Shader_registerContext *ctx) = 0;

  virtual void enterRegister_space(UShaderParser::Register_spaceContext *ctx) = 0;
  virtual void exitRegister_space(UShaderParser::Register_spaceContext *ctx) = 0;

  virtual void enterRegister_num(UShaderParser::Register_numContext *ctx) = 0;
  virtual void exitRegister_num(UShaderParser::Register_numContext *ctx) = 0;

  virtual void enterPass(UShaderParser::PassContext *ctx) = 0;
  virtual void exitPass(UShaderParser::PassContext *ctx) = 0;

  virtual void enterVs(UShaderParser::VsContext *ctx) = 0;
  virtual void exitVs(UShaderParser::VsContext *ctx) = 0;

  virtual void enterPs(UShaderParser::PsContext *ctx) = 0;
  virtual void exitPs(UShaderParser::PsContext *ctx) = 0;

  virtual void enterPass_statement(UShaderParser::Pass_statementContext *ctx) = 0;
  virtual void exitPass_statement(UShaderParser::Pass_statementContext *ctx) = 0;

  virtual void enterTags(UShaderParser::TagsContext *ctx) = 0;
  virtual void exitTags(UShaderParser::TagsContext *ctx) = 0;

  virtual void enterTag(UShaderParser::TagContext *ctx) = 0;
  virtual void exitTag(UShaderParser::TagContext *ctx) = 0;

  virtual void enterRender_state_setup(UShaderParser::Render_state_setupContext *ctx) = 0;
  virtual void exitRender_state_setup(UShaderParser::Render_state_setupContext *ctx) = 0;

  virtual void enterFill(UShaderParser::FillContext *ctx) = 0;
  virtual void exitFill(UShaderParser::FillContext *ctx) = 0;

  virtual void enterCull(UShaderParser::CullContext *ctx) = 0;
  virtual void exitCull(UShaderParser::CullContext *ctx) = 0;

  virtual void enterZtest(UShaderParser::ZtestContext *ctx) = 0;
  virtual void exitZtest(UShaderParser::ZtestContext *ctx) = 0;

  virtual void enterZwrite_off(UShaderParser::Zwrite_offContext *ctx) = 0;
  virtual void exitZwrite_off(UShaderParser::Zwrite_offContext *ctx) = 0;

  virtual void enterBlend(UShaderParser::BlendContext *ctx) = 0;
  virtual void exitBlend(UShaderParser::BlendContext *ctx) = 0;

  virtual void enterBlend_expr(UShaderParser::Blend_exprContext *ctx) = 0;
  virtual void exitBlend_expr(UShaderParser::Blend_exprContext *ctx) = 0;

  virtual void enterIndex(UShaderParser::IndexContext *ctx) = 0;
  virtual void exitIndex(UShaderParser::IndexContext *ctx) = 0;

  virtual void enterBlend_src_factor_color(UShaderParser::Blend_src_factor_colorContext *ctx) = 0;
  virtual void exitBlend_src_factor_color(UShaderParser::Blend_src_factor_colorContext *ctx) = 0;

  virtual void enterBlend_dst_factor_color(UShaderParser::Blend_dst_factor_colorContext *ctx) = 0;
  virtual void exitBlend_dst_factor_color(UShaderParser::Blend_dst_factor_colorContext *ctx) = 0;

  virtual void enterBlend_src_factor_alpha(UShaderParser::Blend_src_factor_alphaContext *ctx) = 0;
  virtual void exitBlend_src_factor_alpha(UShaderParser::Blend_src_factor_alphaContext *ctx) = 0;

  virtual void enterBlend_dst_factor_alpha(UShaderParser::Blend_dst_factor_alphaContext *ctx) = 0;
  virtual void exitBlend_dst_factor_alpha(UShaderParser::Blend_dst_factor_alphaContext *ctx) = 0;

  virtual void enterBlend_factor(UShaderParser::Blend_factorContext *ctx) = 0;
  virtual void exitBlend_factor(UShaderParser::Blend_factorContext *ctx) = 0;

  virtual void enterBlend_op(UShaderParser::Blend_opContext *ctx) = 0;
  virtual void exitBlend_op(UShaderParser::Blend_opContext *ctx) = 0;

  virtual void enterBlend_op_color(UShaderParser::Blend_op_colorContext *ctx) = 0;
  virtual void exitBlend_op_color(UShaderParser::Blend_op_colorContext *ctx) = 0;

  virtual void enterBlend_op_alpha(UShaderParser::Blend_op_alphaContext *ctx) = 0;
  virtual void exitBlend_op_alpha(UShaderParser::Blend_op_alphaContext *ctx) = 0;

  virtual void enterColor_mask(UShaderParser::Color_maskContext *ctx) = 0;
  virtual void exitColor_mask(UShaderParser::Color_maskContext *ctx) = 0;

  virtual void enterColor_mask_value(UShaderParser::Color_mask_valueContext *ctx) = 0;
  virtual void exitColor_mask_value(UShaderParser::Color_mask_valueContext *ctx) = 0;

  virtual void enterStencil(UShaderParser::StencilContext *ctx) = 0;
  virtual void exitStencil(UShaderParser::StencilContext *ctx) = 0;

  virtual void enterStencil_state_setup(UShaderParser::Stencil_state_setupContext *ctx) = 0;
  virtual void exitStencil_state_setup(UShaderParser::Stencil_state_setupContext *ctx) = 0;

  virtual void enterStencil_ref(UShaderParser::Stencil_refContext *ctx) = 0;
  virtual void exitStencil_ref(UShaderParser::Stencil_refContext *ctx) = 0;

  virtual void enterStencil_mask_read(UShaderParser::Stencil_mask_readContext *ctx) = 0;
  virtual void exitStencil_mask_read(UShaderParser::Stencil_mask_readContext *ctx) = 0;

  virtual void enterStencil_mask_write(UShaderParser::Stencil_mask_writeContext *ctx) = 0;
  virtual void exitStencil_mask_write(UShaderParser::Stencil_mask_writeContext *ctx) = 0;

  virtual void enterStencil_compare(UShaderParser::Stencil_compareContext *ctx) = 0;
  virtual void exitStencil_compare(UShaderParser::Stencil_compareContext *ctx) = 0;

  virtual void enterStencil_pass(UShaderParser::Stencil_passContext *ctx) = 0;
  virtual void exitStencil_pass(UShaderParser::Stencil_passContext *ctx) = 0;

  virtual void enterStencil_fail(UShaderParser::Stencil_failContext *ctx) = 0;
  virtual void exitStencil_fail(UShaderParser::Stencil_failContext *ctx) = 0;

  virtual void enterStencil_zfail(UShaderParser::Stencil_zfailContext *ctx) = 0;
  virtual void exitStencil_zfail(UShaderParser::Stencil_zfailContext *ctx) = 0;

  virtual void enterStencil_op(UShaderParser::Stencil_opContext *ctx) = 0;
  virtual void exitStencil_op(UShaderParser::Stencil_opContext *ctx) = 0;

  virtual void enterQueue(UShaderParser::QueueContext *ctx) = 0;
  virtual void exitQueue(UShaderParser::QueueContext *ctx) = 0;

  virtual void enterVal_queue(UShaderParser::Val_queueContext *ctx) = 0;
  virtual void exitVal_queue(UShaderParser::Val_queueContext *ctx) = 0;

  virtual void enterQueue_key(UShaderParser::Queue_keyContext *ctx) = 0;
  virtual void exitQueue_key(UShaderParser::Queue_keyContext *ctx) = 0;


};

}  // namespace Ubpa::Utopia::details
