
// Generated from UShader.g4 by ANTLR 4.8


#include "UShaderListener.h"
#include "UShaderVisitor.h"

#include "UShaderParser.h"


using namespace antlrcpp;
using namespace Ubpa::Utopia::details;
using namespace antlr4;

UShaderParser::UShaderParser(TokenStream *input) : Parser(input) {
  _interpreter = new atn::ParserATNSimulator(this, _atn, _decisionToDFA, _sharedContextCache);
}

UShaderParser::~UShaderParser() {
  delete _interpreter;
}

std::string UShaderParser::getGrammarFileName() const {
  return "UShader.g4";
}

const std::vector<std::string>& UShaderParser::getRuleNames() const {
  return _ruleNames;
}

dfa::Vocabulary& UShaderParser::getVocabulary() const {
  return _vocabulary;
}


//----------------- ShaderContext ------------------------------------------------------------------

UShaderParser::ShaderContext::ShaderContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Shader_nameContext* UShaderParser::ShaderContext::shader_name() {
  return getRuleContext<UShaderParser::Shader_nameContext>(0);
}

UShaderParser::HlslContext* UShaderParser::ShaderContext::hlsl() {
  return getRuleContext<UShaderParser::HlslContext>(0);
}

UShaderParser::Root_signatureContext* UShaderParser::ShaderContext::root_signature() {
  return getRuleContext<UShaderParser::Root_signatureContext>(0);
}

UShaderParser::Property_blockContext* UShaderParser::ShaderContext::property_block() {
  return getRuleContext<UShaderParser::Property_blockContext>(0);
}

std::vector<UShaderParser::PassContext *> UShaderParser::ShaderContext::pass() {
  return getRuleContexts<UShaderParser::PassContext>();
}

UShaderParser::PassContext* UShaderParser::ShaderContext::pass(size_t i) {
  return getRuleContext<UShaderParser::PassContext>(i);
}


size_t UShaderParser::ShaderContext::getRuleIndex() const {
  return UShaderParser::RuleShader;
}

void UShaderParser::ShaderContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterShader(this);
}

void UShaderParser::ShaderContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitShader(this);
}


antlrcpp::Any UShaderParser::ShaderContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitShader(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::ShaderContext* UShaderParser::shader() {
  ShaderContext *_localctx = _tracker.createInstance<ShaderContext>(_ctx, getState());
  enterRule(_localctx, 0, UShaderParser::RuleShader);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(196);
    match(UShaderParser::T__0);
    setState(197);
    shader_name();
    setState(198);
    match(UShaderParser::T__1);
    setState(199);
    hlsl();
    setState(200);
    root_signature();
    setState(202);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == UShaderParser::T__5) {
      setState(201);
      property_block();
    }
    setState(205); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(204);
      pass();
      setState(207); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while (_la == UShaderParser::T__39);
    setState(209);
    match(UShaderParser::T__2);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Shader_nameContext ------------------------------------------------------------------

UShaderParser::Shader_nameContext::Shader_nameContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Shader_nameContext::StringLiteral() {
  return getToken(UShaderParser::StringLiteral, 0);
}


size_t UShaderParser::Shader_nameContext::getRuleIndex() const {
  return UShaderParser::RuleShader_name;
}

void UShaderParser::Shader_nameContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterShader_name(this);
}

void UShaderParser::Shader_nameContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitShader_name(this);
}


antlrcpp::Any UShaderParser::Shader_nameContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitShader_name(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Shader_nameContext* UShaderParser::shader_name() {
  Shader_nameContext *_localctx = _tracker.createInstance<Shader_nameContext>(_ctx, getState());
  enterRule(_localctx, 2, UShaderParser::RuleShader_name);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(211);
    match(UShaderParser::StringLiteral);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- HlslContext ------------------------------------------------------------------

UShaderParser::HlslContext::HlslContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::HlslContext::StringLiteral() {
  return getToken(UShaderParser::StringLiteral, 0);
}


size_t UShaderParser::HlslContext::getRuleIndex() const {
  return UShaderParser::RuleHlsl;
}

void UShaderParser::HlslContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterHlsl(this);
}

void UShaderParser::HlslContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitHlsl(this);
}


antlrcpp::Any UShaderParser::HlslContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitHlsl(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::HlslContext* UShaderParser::hlsl() {
  HlslContext *_localctx = _tracker.createInstance<HlslContext>(_ctx, getState());
  enterRule(_localctx, 4, UShaderParser::RuleHlsl);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(213);
    match(UShaderParser::T__3);
    setState(214);
    match(UShaderParser::T__4);
    setState(215);
    match(UShaderParser::StringLiteral);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_blockContext ------------------------------------------------------------------

UShaderParser::Property_blockContext::Property_blockContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::PropertyContext *> UShaderParser::Property_blockContext::property() {
  return getRuleContexts<UShaderParser::PropertyContext>();
}

UShaderParser::PropertyContext* UShaderParser::Property_blockContext::property(size_t i) {
  return getRuleContext<UShaderParser::PropertyContext>(i);
}


size_t UShaderParser::Property_blockContext::getRuleIndex() const {
  return UShaderParser::RuleProperty_block;
}

void UShaderParser::Property_blockContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_block(this);
}

void UShaderParser::Property_blockContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_block(this);
}


antlrcpp::Any UShaderParser::Property_blockContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_block(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_blockContext* UShaderParser::property_block() {
  Property_blockContext *_localctx = _tracker.createInstance<Property_blockContext>(_ctx, getState());
  enterRule(_localctx, 6, UShaderParser::RuleProperty_block);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(217);
    match(UShaderParser::T__5);
    setState(218);
    match(UShaderParser::T__1);
    setState(220); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(219);
      property();
      setState(222); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while (_la == UShaderParser::ID);
    setState(224);
    match(UShaderParser::T__2);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- PropertyContext ------------------------------------------------------------------

UShaderParser::PropertyContext::PropertyContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_boolContext* UShaderParser::PropertyContext::property_bool() {
  return getRuleContext<UShaderParser::Property_boolContext>(0);
}

UShaderParser::Property_intContext* UShaderParser::PropertyContext::property_int() {
  return getRuleContext<UShaderParser::Property_intContext>(0);
}

UShaderParser::Property_uintContext* UShaderParser::PropertyContext::property_uint() {
  return getRuleContext<UShaderParser::Property_uintContext>(0);
}

UShaderParser::Property_floatContext* UShaderParser::PropertyContext::property_float() {
  return getRuleContext<UShaderParser::Property_floatContext>(0);
}

UShaderParser::Property_doubleContext* UShaderParser::PropertyContext::property_double() {
  return getRuleContext<UShaderParser::Property_doubleContext>(0);
}

UShaderParser::Property_bool2Context* UShaderParser::PropertyContext::property_bool2() {
  return getRuleContext<UShaderParser::Property_bool2Context>(0);
}

UShaderParser::Property_bool3Context* UShaderParser::PropertyContext::property_bool3() {
  return getRuleContext<UShaderParser::Property_bool3Context>(0);
}

UShaderParser::Property_bool4Context* UShaderParser::PropertyContext::property_bool4() {
  return getRuleContext<UShaderParser::Property_bool4Context>(0);
}

UShaderParser::Property_int2Context* UShaderParser::PropertyContext::property_int2() {
  return getRuleContext<UShaderParser::Property_int2Context>(0);
}

UShaderParser::Property_int3Context* UShaderParser::PropertyContext::property_int3() {
  return getRuleContext<UShaderParser::Property_int3Context>(0);
}

UShaderParser::Property_int4Context* UShaderParser::PropertyContext::property_int4() {
  return getRuleContext<UShaderParser::Property_int4Context>(0);
}

UShaderParser::Property_uint2Context* UShaderParser::PropertyContext::property_uint2() {
  return getRuleContext<UShaderParser::Property_uint2Context>(0);
}

UShaderParser::Property_uint3Context* UShaderParser::PropertyContext::property_uint3() {
  return getRuleContext<UShaderParser::Property_uint3Context>(0);
}

UShaderParser::Property_uint4Context* UShaderParser::PropertyContext::property_uint4() {
  return getRuleContext<UShaderParser::Property_uint4Context>(0);
}

UShaderParser::Property_float2Context* UShaderParser::PropertyContext::property_float2() {
  return getRuleContext<UShaderParser::Property_float2Context>(0);
}

UShaderParser::Property_float3Context* UShaderParser::PropertyContext::property_float3() {
  return getRuleContext<UShaderParser::Property_float3Context>(0);
}

UShaderParser::Property_float4Context* UShaderParser::PropertyContext::property_float4() {
  return getRuleContext<UShaderParser::Property_float4Context>(0);
}

UShaderParser::Property_double2Context* UShaderParser::PropertyContext::property_double2() {
  return getRuleContext<UShaderParser::Property_double2Context>(0);
}

UShaderParser::Property_double3Context* UShaderParser::PropertyContext::property_double3() {
  return getRuleContext<UShaderParser::Property_double3Context>(0);
}

UShaderParser::Property_double4Context* UShaderParser::PropertyContext::property_double4() {
  return getRuleContext<UShaderParser::Property_double4Context>(0);
}

UShaderParser::Property_2DContext* UShaderParser::PropertyContext::property_2D() {
  return getRuleContext<UShaderParser::Property_2DContext>(0);
}

UShaderParser::Property_cubeContext* UShaderParser::PropertyContext::property_cube() {
  return getRuleContext<UShaderParser::Property_cubeContext>(0);
}

UShaderParser::Property_rgbContext* UShaderParser::PropertyContext::property_rgb() {
  return getRuleContext<UShaderParser::Property_rgbContext>(0);
}

UShaderParser::Property_rgbaContext* UShaderParser::PropertyContext::property_rgba() {
  return getRuleContext<UShaderParser::Property_rgbaContext>(0);
}


size_t UShaderParser::PropertyContext::getRuleIndex() const {
  return UShaderParser::RuleProperty;
}

void UShaderParser::PropertyContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty(this);
}

void UShaderParser::PropertyContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty(this);
}


antlrcpp::Any UShaderParser::PropertyContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::PropertyContext* UShaderParser::property() {
  PropertyContext *_localctx = _tracker.createInstance<PropertyContext>(_ctx, getState());
  enterRule(_localctx, 8, UShaderParser::RuleProperty);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(250);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 3, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(226);
      property_bool();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(227);
      property_int();
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(228);
      property_uint();
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(229);
      property_float();
      break;
    }

    case 5: {
      enterOuterAlt(_localctx, 5);
      setState(230);
      property_double();
      break;
    }

    case 6: {
      enterOuterAlt(_localctx, 6);
      setState(231);
      property_bool2();
      break;
    }

    case 7: {
      enterOuterAlt(_localctx, 7);
      setState(232);
      property_bool3();
      break;
    }

    case 8: {
      enterOuterAlt(_localctx, 8);
      setState(233);
      property_bool4();
      break;
    }

    case 9: {
      enterOuterAlt(_localctx, 9);
      setState(234);
      property_int2();
      break;
    }

    case 10: {
      enterOuterAlt(_localctx, 10);
      setState(235);
      property_int3();
      break;
    }

    case 11: {
      enterOuterAlt(_localctx, 11);
      setState(236);
      property_int4();
      break;
    }

    case 12: {
      enterOuterAlt(_localctx, 12);
      setState(237);
      property_uint2();
      break;
    }

    case 13: {
      enterOuterAlt(_localctx, 13);
      setState(238);
      property_uint3();
      break;
    }

    case 14: {
      enterOuterAlt(_localctx, 14);
      setState(239);
      property_uint4();
      break;
    }

    case 15: {
      enterOuterAlt(_localctx, 15);
      setState(240);
      property_float2();
      break;
    }

    case 16: {
      enterOuterAlt(_localctx, 16);
      setState(241);
      property_float3();
      break;
    }

    case 17: {
      enterOuterAlt(_localctx, 17);
      setState(242);
      property_float4();
      break;
    }

    case 18: {
      enterOuterAlt(_localctx, 18);
      setState(243);
      property_double2();
      break;
    }

    case 19: {
      enterOuterAlt(_localctx, 19);
      setState(244);
      property_double3();
      break;
    }

    case 20: {
      enterOuterAlt(_localctx, 20);
      setState(245);
      property_double4();
      break;
    }

    case 21: {
      enterOuterAlt(_localctx, 21);
      setState(246);
      property_2D();
      break;
    }

    case 22: {
      enterOuterAlt(_localctx, 22);
      setState(247);
      property_cube();
      break;
    }

    case 23: {
      enterOuterAlt(_localctx, 23);
      setState(248);
      property_rgb();
      break;
    }

    case 24: {
      enterOuterAlt(_localctx, 24);
      setState(249);
      property_rgba();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_boolContext ------------------------------------------------------------------

UShaderParser::Property_boolContext::Property_boolContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_boolContext::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_boolContext::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_boolContext* UShaderParser::Property_boolContext::val_bool() {
  return getRuleContext<UShaderParser::Val_boolContext>(0);
}


size_t UShaderParser::Property_boolContext::getRuleIndex() const {
  return UShaderParser::RuleProperty_bool;
}

void UShaderParser::Property_boolContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_bool(this);
}

void UShaderParser::Property_boolContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_bool(this);
}


antlrcpp::Any UShaderParser::Property_boolContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_bool(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_boolContext* UShaderParser::property_bool() {
  Property_boolContext *_localctx = _tracker.createInstance<Property_boolContext>(_ctx, getState());
  enterRule(_localctx, 10, UShaderParser::RuleProperty_bool);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(252);
    property_name();
    setState(253);
    match(UShaderParser::T__6);
    setState(254);
    display_name();
    setState(255);
    match(UShaderParser::T__7);
    setState(256);
    match(UShaderParser::T__8);
    setState(257);
    match(UShaderParser::T__9);
    setState(258);
    match(UShaderParser::T__4);
    setState(259);
    val_bool();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_intContext ------------------------------------------------------------------

UShaderParser::Property_intContext::Property_intContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_intContext::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_intContext::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_intContext* UShaderParser::Property_intContext::val_int() {
  return getRuleContext<UShaderParser::Val_intContext>(0);
}


size_t UShaderParser::Property_intContext::getRuleIndex() const {
  return UShaderParser::RuleProperty_int;
}

void UShaderParser::Property_intContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_int(this);
}

void UShaderParser::Property_intContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_int(this);
}


antlrcpp::Any UShaderParser::Property_intContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_int(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_intContext* UShaderParser::property_int() {
  Property_intContext *_localctx = _tracker.createInstance<Property_intContext>(_ctx, getState());
  enterRule(_localctx, 12, UShaderParser::RuleProperty_int);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(261);
    property_name();
    setState(262);
    match(UShaderParser::T__6);
    setState(263);
    display_name();
    setState(264);
    match(UShaderParser::T__7);
    setState(265);
    match(UShaderParser::T__10);
    setState(266);
    match(UShaderParser::T__9);
    setState(267);
    match(UShaderParser::T__4);
    setState(268);
    val_int();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_uintContext ------------------------------------------------------------------

UShaderParser::Property_uintContext::Property_uintContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_uintContext::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_uintContext::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_uintContext* UShaderParser::Property_uintContext::val_uint() {
  return getRuleContext<UShaderParser::Val_uintContext>(0);
}


size_t UShaderParser::Property_uintContext::getRuleIndex() const {
  return UShaderParser::RuleProperty_uint;
}

void UShaderParser::Property_uintContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_uint(this);
}

void UShaderParser::Property_uintContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_uint(this);
}


antlrcpp::Any UShaderParser::Property_uintContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_uint(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_uintContext* UShaderParser::property_uint() {
  Property_uintContext *_localctx = _tracker.createInstance<Property_uintContext>(_ctx, getState());
  enterRule(_localctx, 14, UShaderParser::RuleProperty_uint);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(270);
    property_name();
    setState(271);
    match(UShaderParser::T__6);
    setState(272);
    display_name();
    setState(273);
    match(UShaderParser::T__7);
    setState(274);
    match(UShaderParser::T__11);
    setState(275);
    match(UShaderParser::T__9);
    setState(276);
    match(UShaderParser::T__4);
    setState(277);
    val_uint();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_floatContext ------------------------------------------------------------------

UShaderParser::Property_floatContext::Property_floatContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_floatContext::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_floatContext::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_floatContext* UShaderParser::Property_floatContext::val_float() {
  return getRuleContext<UShaderParser::Val_floatContext>(0);
}


size_t UShaderParser::Property_floatContext::getRuleIndex() const {
  return UShaderParser::RuleProperty_float;
}

void UShaderParser::Property_floatContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_float(this);
}

void UShaderParser::Property_floatContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_float(this);
}


antlrcpp::Any UShaderParser::Property_floatContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_float(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_floatContext* UShaderParser::property_float() {
  Property_floatContext *_localctx = _tracker.createInstance<Property_floatContext>(_ctx, getState());
  enterRule(_localctx, 16, UShaderParser::RuleProperty_float);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(279);
    property_name();
    setState(280);
    match(UShaderParser::T__6);
    setState(281);
    display_name();
    setState(282);
    match(UShaderParser::T__7);
    setState(283);
    match(UShaderParser::T__12);
    setState(284);
    match(UShaderParser::T__9);
    setState(285);
    match(UShaderParser::T__4);
    setState(286);
    val_float();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_doubleContext ------------------------------------------------------------------

UShaderParser::Property_doubleContext::Property_doubleContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_doubleContext::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_doubleContext::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_doubleContext* UShaderParser::Property_doubleContext::val_double() {
  return getRuleContext<UShaderParser::Val_doubleContext>(0);
}


size_t UShaderParser::Property_doubleContext::getRuleIndex() const {
  return UShaderParser::RuleProperty_double;
}

void UShaderParser::Property_doubleContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_double(this);
}

void UShaderParser::Property_doubleContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_double(this);
}


antlrcpp::Any UShaderParser::Property_doubleContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_double(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_doubleContext* UShaderParser::property_double() {
  Property_doubleContext *_localctx = _tracker.createInstance<Property_doubleContext>(_ctx, getState());
  enterRule(_localctx, 18, UShaderParser::RuleProperty_double);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(288);
    property_name();
    setState(289);
    match(UShaderParser::T__6);
    setState(290);
    display_name();
    setState(291);
    match(UShaderParser::T__7);
    setState(292);
    match(UShaderParser::T__13);
    setState(293);
    match(UShaderParser::T__9);
    setState(294);
    match(UShaderParser::T__4);
    setState(295);
    val_double();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_bool2Context ------------------------------------------------------------------

UShaderParser::Property_bool2Context::Property_bool2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_bool2Context::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_bool2Context::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_bool2Context* UShaderParser::Property_bool2Context::val_bool2() {
  return getRuleContext<UShaderParser::Val_bool2Context>(0);
}


size_t UShaderParser::Property_bool2Context::getRuleIndex() const {
  return UShaderParser::RuleProperty_bool2;
}

void UShaderParser::Property_bool2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_bool2(this);
}

void UShaderParser::Property_bool2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_bool2(this);
}


antlrcpp::Any UShaderParser::Property_bool2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_bool2(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_bool2Context* UShaderParser::property_bool2() {
  Property_bool2Context *_localctx = _tracker.createInstance<Property_bool2Context>(_ctx, getState());
  enterRule(_localctx, 20, UShaderParser::RuleProperty_bool2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(297);
    property_name();
    setState(298);
    match(UShaderParser::T__6);
    setState(299);
    display_name();
    setState(300);
    match(UShaderParser::T__7);
    setState(301);
    match(UShaderParser::T__14);
    setState(302);
    match(UShaderParser::T__9);
    setState(303);
    match(UShaderParser::T__4);
    setState(304);
    val_bool2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_bool3Context ------------------------------------------------------------------

UShaderParser::Property_bool3Context::Property_bool3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_bool3Context::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_bool3Context::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_bool3Context* UShaderParser::Property_bool3Context::val_bool3() {
  return getRuleContext<UShaderParser::Val_bool3Context>(0);
}


size_t UShaderParser::Property_bool3Context::getRuleIndex() const {
  return UShaderParser::RuleProperty_bool3;
}

void UShaderParser::Property_bool3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_bool3(this);
}

void UShaderParser::Property_bool3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_bool3(this);
}


antlrcpp::Any UShaderParser::Property_bool3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_bool3(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_bool3Context* UShaderParser::property_bool3() {
  Property_bool3Context *_localctx = _tracker.createInstance<Property_bool3Context>(_ctx, getState());
  enterRule(_localctx, 22, UShaderParser::RuleProperty_bool3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(306);
    property_name();
    setState(307);
    match(UShaderParser::T__6);
    setState(308);
    display_name();
    setState(309);
    match(UShaderParser::T__7);
    setState(310);
    match(UShaderParser::T__15);
    setState(311);
    match(UShaderParser::T__9);
    setState(312);
    match(UShaderParser::T__4);
    setState(313);
    val_bool3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_bool4Context ------------------------------------------------------------------

UShaderParser::Property_bool4Context::Property_bool4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_bool4Context::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_bool4Context::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_bool4Context* UShaderParser::Property_bool4Context::val_bool4() {
  return getRuleContext<UShaderParser::Val_bool4Context>(0);
}


size_t UShaderParser::Property_bool4Context::getRuleIndex() const {
  return UShaderParser::RuleProperty_bool4;
}

void UShaderParser::Property_bool4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_bool4(this);
}

void UShaderParser::Property_bool4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_bool4(this);
}


antlrcpp::Any UShaderParser::Property_bool4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_bool4(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_bool4Context* UShaderParser::property_bool4() {
  Property_bool4Context *_localctx = _tracker.createInstance<Property_bool4Context>(_ctx, getState());
  enterRule(_localctx, 24, UShaderParser::RuleProperty_bool4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(315);
    property_name();
    setState(316);
    match(UShaderParser::T__6);
    setState(317);
    display_name();
    setState(318);
    match(UShaderParser::T__7);
    setState(319);
    match(UShaderParser::T__16);
    setState(320);
    match(UShaderParser::T__9);
    setState(321);
    match(UShaderParser::T__4);
    setState(322);
    val_bool4();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_int2Context ------------------------------------------------------------------

UShaderParser::Property_int2Context::Property_int2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_int2Context::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_int2Context::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_int2Context* UShaderParser::Property_int2Context::val_int2() {
  return getRuleContext<UShaderParser::Val_int2Context>(0);
}


size_t UShaderParser::Property_int2Context::getRuleIndex() const {
  return UShaderParser::RuleProperty_int2;
}

void UShaderParser::Property_int2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_int2(this);
}

void UShaderParser::Property_int2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_int2(this);
}


antlrcpp::Any UShaderParser::Property_int2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_int2(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_int2Context* UShaderParser::property_int2() {
  Property_int2Context *_localctx = _tracker.createInstance<Property_int2Context>(_ctx, getState());
  enterRule(_localctx, 26, UShaderParser::RuleProperty_int2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(324);
    property_name();
    setState(325);
    match(UShaderParser::T__6);
    setState(326);
    display_name();
    setState(327);
    match(UShaderParser::T__7);
    setState(328);
    match(UShaderParser::T__17);
    setState(329);
    match(UShaderParser::T__9);
    setState(330);
    match(UShaderParser::T__4);
    setState(331);
    val_int2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_int3Context ------------------------------------------------------------------

UShaderParser::Property_int3Context::Property_int3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_int3Context::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_int3Context::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_int3Context* UShaderParser::Property_int3Context::val_int3() {
  return getRuleContext<UShaderParser::Val_int3Context>(0);
}


size_t UShaderParser::Property_int3Context::getRuleIndex() const {
  return UShaderParser::RuleProperty_int3;
}

void UShaderParser::Property_int3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_int3(this);
}

void UShaderParser::Property_int3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_int3(this);
}


antlrcpp::Any UShaderParser::Property_int3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_int3(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_int3Context* UShaderParser::property_int3() {
  Property_int3Context *_localctx = _tracker.createInstance<Property_int3Context>(_ctx, getState());
  enterRule(_localctx, 28, UShaderParser::RuleProperty_int3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(333);
    property_name();
    setState(334);
    match(UShaderParser::T__6);
    setState(335);
    display_name();
    setState(336);
    match(UShaderParser::T__7);
    setState(337);
    match(UShaderParser::T__18);
    setState(338);
    match(UShaderParser::T__9);
    setState(339);
    match(UShaderParser::T__4);
    setState(340);
    val_int3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_int4Context ------------------------------------------------------------------

UShaderParser::Property_int4Context::Property_int4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_int4Context::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_int4Context::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_int4Context* UShaderParser::Property_int4Context::val_int4() {
  return getRuleContext<UShaderParser::Val_int4Context>(0);
}


size_t UShaderParser::Property_int4Context::getRuleIndex() const {
  return UShaderParser::RuleProperty_int4;
}

void UShaderParser::Property_int4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_int4(this);
}

void UShaderParser::Property_int4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_int4(this);
}


antlrcpp::Any UShaderParser::Property_int4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_int4(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_int4Context* UShaderParser::property_int4() {
  Property_int4Context *_localctx = _tracker.createInstance<Property_int4Context>(_ctx, getState());
  enterRule(_localctx, 30, UShaderParser::RuleProperty_int4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(342);
    property_name();
    setState(343);
    match(UShaderParser::T__6);
    setState(344);
    display_name();
    setState(345);
    match(UShaderParser::T__7);
    setState(346);
    match(UShaderParser::T__19);
    setState(347);
    match(UShaderParser::T__9);
    setState(348);
    match(UShaderParser::T__4);
    setState(349);
    val_int4();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_uint2Context ------------------------------------------------------------------

UShaderParser::Property_uint2Context::Property_uint2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_uint2Context::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_uint2Context::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_uint2Context* UShaderParser::Property_uint2Context::val_uint2() {
  return getRuleContext<UShaderParser::Val_uint2Context>(0);
}


size_t UShaderParser::Property_uint2Context::getRuleIndex() const {
  return UShaderParser::RuleProperty_uint2;
}

void UShaderParser::Property_uint2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_uint2(this);
}

void UShaderParser::Property_uint2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_uint2(this);
}


antlrcpp::Any UShaderParser::Property_uint2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_uint2(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_uint2Context* UShaderParser::property_uint2() {
  Property_uint2Context *_localctx = _tracker.createInstance<Property_uint2Context>(_ctx, getState());
  enterRule(_localctx, 32, UShaderParser::RuleProperty_uint2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(351);
    property_name();
    setState(352);
    match(UShaderParser::T__6);
    setState(353);
    display_name();
    setState(354);
    match(UShaderParser::T__7);
    setState(355);
    match(UShaderParser::T__20);
    setState(356);
    match(UShaderParser::T__9);
    setState(357);
    match(UShaderParser::T__4);
    setState(358);
    val_uint2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_uint3Context ------------------------------------------------------------------

UShaderParser::Property_uint3Context::Property_uint3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_uint3Context::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_uint3Context::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_uint3Context* UShaderParser::Property_uint3Context::val_uint3() {
  return getRuleContext<UShaderParser::Val_uint3Context>(0);
}


size_t UShaderParser::Property_uint3Context::getRuleIndex() const {
  return UShaderParser::RuleProperty_uint3;
}

void UShaderParser::Property_uint3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_uint3(this);
}

void UShaderParser::Property_uint3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_uint3(this);
}


antlrcpp::Any UShaderParser::Property_uint3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_uint3(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_uint3Context* UShaderParser::property_uint3() {
  Property_uint3Context *_localctx = _tracker.createInstance<Property_uint3Context>(_ctx, getState());
  enterRule(_localctx, 34, UShaderParser::RuleProperty_uint3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(360);
    property_name();
    setState(361);
    match(UShaderParser::T__6);
    setState(362);
    display_name();
    setState(363);
    match(UShaderParser::T__7);
    setState(364);
    match(UShaderParser::T__21);
    setState(365);
    match(UShaderParser::T__9);
    setState(366);
    match(UShaderParser::T__4);
    setState(367);
    val_uint3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_uint4Context ------------------------------------------------------------------

UShaderParser::Property_uint4Context::Property_uint4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_uint4Context::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_uint4Context::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_uint4Context* UShaderParser::Property_uint4Context::val_uint4() {
  return getRuleContext<UShaderParser::Val_uint4Context>(0);
}


size_t UShaderParser::Property_uint4Context::getRuleIndex() const {
  return UShaderParser::RuleProperty_uint4;
}

void UShaderParser::Property_uint4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_uint4(this);
}

void UShaderParser::Property_uint4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_uint4(this);
}


antlrcpp::Any UShaderParser::Property_uint4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_uint4(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_uint4Context* UShaderParser::property_uint4() {
  Property_uint4Context *_localctx = _tracker.createInstance<Property_uint4Context>(_ctx, getState());
  enterRule(_localctx, 36, UShaderParser::RuleProperty_uint4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(369);
    property_name();
    setState(370);
    match(UShaderParser::T__6);
    setState(371);
    display_name();
    setState(372);
    match(UShaderParser::T__7);
    setState(373);
    match(UShaderParser::T__22);
    setState(374);
    match(UShaderParser::T__9);
    setState(375);
    match(UShaderParser::T__4);
    setState(376);
    val_uint4();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_float2Context ------------------------------------------------------------------

UShaderParser::Property_float2Context::Property_float2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_float2Context::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_float2Context::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_float2Context* UShaderParser::Property_float2Context::val_float2() {
  return getRuleContext<UShaderParser::Val_float2Context>(0);
}


size_t UShaderParser::Property_float2Context::getRuleIndex() const {
  return UShaderParser::RuleProperty_float2;
}

void UShaderParser::Property_float2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_float2(this);
}

void UShaderParser::Property_float2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_float2(this);
}


antlrcpp::Any UShaderParser::Property_float2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_float2(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_float2Context* UShaderParser::property_float2() {
  Property_float2Context *_localctx = _tracker.createInstance<Property_float2Context>(_ctx, getState());
  enterRule(_localctx, 38, UShaderParser::RuleProperty_float2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(378);
    property_name();
    setState(379);
    match(UShaderParser::T__6);
    setState(380);
    display_name();
    setState(381);
    match(UShaderParser::T__7);
    setState(382);
    match(UShaderParser::T__23);
    setState(383);
    match(UShaderParser::T__9);
    setState(384);
    match(UShaderParser::T__4);
    setState(385);
    val_float2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_float3Context ------------------------------------------------------------------

UShaderParser::Property_float3Context::Property_float3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_float3Context::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_float3Context::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_float3Context* UShaderParser::Property_float3Context::val_float3() {
  return getRuleContext<UShaderParser::Val_float3Context>(0);
}


size_t UShaderParser::Property_float3Context::getRuleIndex() const {
  return UShaderParser::RuleProperty_float3;
}

void UShaderParser::Property_float3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_float3(this);
}

void UShaderParser::Property_float3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_float3(this);
}


antlrcpp::Any UShaderParser::Property_float3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_float3(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_float3Context* UShaderParser::property_float3() {
  Property_float3Context *_localctx = _tracker.createInstance<Property_float3Context>(_ctx, getState());
  enterRule(_localctx, 40, UShaderParser::RuleProperty_float3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(387);
    property_name();
    setState(388);
    match(UShaderParser::T__6);
    setState(389);
    display_name();
    setState(390);
    match(UShaderParser::T__7);
    setState(391);
    match(UShaderParser::T__24);
    setState(392);
    match(UShaderParser::T__9);
    setState(393);
    match(UShaderParser::T__4);
    setState(394);
    val_float3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_float4Context ------------------------------------------------------------------

UShaderParser::Property_float4Context::Property_float4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_float4Context::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_float4Context::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_float4Context* UShaderParser::Property_float4Context::val_float4() {
  return getRuleContext<UShaderParser::Val_float4Context>(0);
}


size_t UShaderParser::Property_float4Context::getRuleIndex() const {
  return UShaderParser::RuleProperty_float4;
}

void UShaderParser::Property_float4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_float4(this);
}

void UShaderParser::Property_float4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_float4(this);
}


antlrcpp::Any UShaderParser::Property_float4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_float4(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_float4Context* UShaderParser::property_float4() {
  Property_float4Context *_localctx = _tracker.createInstance<Property_float4Context>(_ctx, getState());
  enterRule(_localctx, 42, UShaderParser::RuleProperty_float4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(396);
    property_name();
    setState(397);
    match(UShaderParser::T__6);
    setState(398);
    display_name();
    setState(399);
    match(UShaderParser::T__7);
    setState(400);
    match(UShaderParser::T__25);
    setState(401);
    match(UShaderParser::T__9);
    setState(402);
    match(UShaderParser::T__4);
    setState(403);
    val_float4();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_double2Context ------------------------------------------------------------------

UShaderParser::Property_double2Context::Property_double2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_double2Context::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_double2Context::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_double2Context* UShaderParser::Property_double2Context::val_double2() {
  return getRuleContext<UShaderParser::Val_double2Context>(0);
}


size_t UShaderParser::Property_double2Context::getRuleIndex() const {
  return UShaderParser::RuleProperty_double2;
}

void UShaderParser::Property_double2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_double2(this);
}

void UShaderParser::Property_double2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_double2(this);
}


antlrcpp::Any UShaderParser::Property_double2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_double2(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_double2Context* UShaderParser::property_double2() {
  Property_double2Context *_localctx = _tracker.createInstance<Property_double2Context>(_ctx, getState());
  enterRule(_localctx, 44, UShaderParser::RuleProperty_double2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(405);
    property_name();
    setState(406);
    match(UShaderParser::T__6);
    setState(407);
    display_name();
    setState(408);
    match(UShaderParser::T__7);
    setState(409);
    match(UShaderParser::T__26);
    setState(410);
    match(UShaderParser::T__9);
    setState(411);
    match(UShaderParser::T__4);
    setState(412);
    val_double2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_double3Context ------------------------------------------------------------------

UShaderParser::Property_double3Context::Property_double3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_double3Context::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_double3Context::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_double3Context* UShaderParser::Property_double3Context::val_double3() {
  return getRuleContext<UShaderParser::Val_double3Context>(0);
}


size_t UShaderParser::Property_double3Context::getRuleIndex() const {
  return UShaderParser::RuleProperty_double3;
}

void UShaderParser::Property_double3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_double3(this);
}

void UShaderParser::Property_double3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_double3(this);
}


antlrcpp::Any UShaderParser::Property_double3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_double3(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_double3Context* UShaderParser::property_double3() {
  Property_double3Context *_localctx = _tracker.createInstance<Property_double3Context>(_ctx, getState());
  enterRule(_localctx, 46, UShaderParser::RuleProperty_double3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(414);
    property_name();
    setState(415);
    match(UShaderParser::T__6);
    setState(416);
    display_name();
    setState(417);
    match(UShaderParser::T__7);
    setState(418);
    match(UShaderParser::T__27);
    setState(419);
    match(UShaderParser::T__9);
    setState(420);
    match(UShaderParser::T__4);
    setState(421);
    val_double3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_double4Context ------------------------------------------------------------------

UShaderParser::Property_double4Context::Property_double4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_double4Context::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_double4Context::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_double4Context* UShaderParser::Property_double4Context::val_double4() {
  return getRuleContext<UShaderParser::Val_double4Context>(0);
}


size_t UShaderParser::Property_double4Context::getRuleIndex() const {
  return UShaderParser::RuleProperty_double4;
}

void UShaderParser::Property_double4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_double4(this);
}

void UShaderParser::Property_double4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_double4(this);
}


antlrcpp::Any UShaderParser::Property_double4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_double4(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_double4Context* UShaderParser::property_double4() {
  Property_double4Context *_localctx = _tracker.createInstance<Property_double4Context>(_ctx, getState());
  enterRule(_localctx, 48, UShaderParser::RuleProperty_double4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(423);
    property_name();
    setState(424);
    match(UShaderParser::T__6);
    setState(425);
    display_name();
    setState(426);
    match(UShaderParser::T__7);
    setState(427);
    match(UShaderParser::T__28);
    setState(428);
    match(UShaderParser::T__9);
    setState(429);
    match(UShaderParser::T__4);
    setState(430);
    val_double4();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_2DContext ------------------------------------------------------------------

UShaderParser::Property_2DContext::Property_2DContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_2DContext::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_2DContext::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_tex2dContext* UShaderParser::Property_2DContext::val_tex2d() {
  return getRuleContext<UShaderParser::Val_tex2dContext>(0);
}


size_t UShaderParser::Property_2DContext::getRuleIndex() const {
  return UShaderParser::RuleProperty_2D;
}

void UShaderParser::Property_2DContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_2D(this);
}

void UShaderParser::Property_2DContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_2D(this);
}


antlrcpp::Any UShaderParser::Property_2DContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_2D(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_2DContext* UShaderParser::property_2D() {
  Property_2DContext *_localctx = _tracker.createInstance<Property_2DContext>(_ctx, getState());
  enterRule(_localctx, 50, UShaderParser::RuleProperty_2D);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(432);
    property_name();
    setState(433);
    match(UShaderParser::T__6);
    setState(434);
    display_name();
    setState(435);
    match(UShaderParser::T__7);
    setState(436);
    match(UShaderParser::T__29);
    setState(437);
    match(UShaderParser::T__9);
    setState(438);
    match(UShaderParser::T__4);
    setState(439);
    val_tex2d();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_cubeContext ------------------------------------------------------------------

UShaderParser::Property_cubeContext::Property_cubeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_cubeContext::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_cubeContext::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_texcubeContext* UShaderParser::Property_cubeContext::val_texcube() {
  return getRuleContext<UShaderParser::Val_texcubeContext>(0);
}


size_t UShaderParser::Property_cubeContext::getRuleIndex() const {
  return UShaderParser::RuleProperty_cube;
}

void UShaderParser::Property_cubeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_cube(this);
}

void UShaderParser::Property_cubeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_cube(this);
}


antlrcpp::Any UShaderParser::Property_cubeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_cube(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_cubeContext* UShaderParser::property_cube() {
  Property_cubeContext *_localctx = _tracker.createInstance<Property_cubeContext>(_ctx, getState());
  enterRule(_localctx, 52, UShaderParser::RuleProperty_cube);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(441);
    property_name();
    setState(442);
    match(UShaderParser::T__6);
    setState(443);
    display_name();
    setState(444);
    match(UShaderParser::T__7);
    setState(445);
    match(UShaderParser::T__30);
    setState(446);
    match(UShaderParser::T__9);
    setState(447);
    match(UShaderParser::T__4);
    setState(448);
    val_texcube();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_rgbContext ------------------------------------------------------------------

UShaderParser::Property_rgbContext::Property_rgbContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_rgbContext::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_rgbContext::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_float3Context* UShaderParser::Property_rgbContext::val_float3() {
  return getRuleContext<UShaderParser::Val_float3Context>(0);
}


size_t UShaderParser::Property_rgbContext::getRuleIndex() const {
  return UShaderParser::RuleProperty_rgb;
}

void UShaderParser::Property_rgbContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_rgb(this);
}

void UShaderParser::Property_rgbContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_rgb(this);
}


antlrcpp::Any UShaderParser::Property_rgbContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_rgb(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_rgbContext* UShaderParser::property_rgb() {
  Property_rgbContext *_localctx = _tracker.createInstance<Property_rgbContext>(_ctx, getState());
  enterRule(_localctx, 54, UShaderParser::RuleProperty_rgb);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(450);
    property_name();
    setState(451);
    match(UShaderParser::T__6);
    setState(452);
    display_name();
    setState(453);
    match(UShaderParser::T__7);
    setState(454);
    match(UShaderParser::T__31);
    setState(455);
    match(UShaderParser::T__9);
    setState(456);
    match(UShaderParser::T__4);
    setState(457);
    val_float3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_rgbaContext ------------------------------------------------------------------

UShaderParser::Property_rgbaContext::Property_rgbaContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Property_nameContext* UShaderParser::Property_rgbaContext::property_name() {
  return getRuleContext<UShaderParser::Property_nameContext>(0);
}

UShaderParser::Display_nameContext* UShaderParser::Property_rgbaContext::display_name() {
  return getRuleContext<UShaderParser::Display_nameContext>(0);
}

UShaderParser::Val_float4Context* UShaderParser::Property_rgbaContext::val_float4() {
  return getRuleContext<UShaderParser::Val_float4Context>(0);
}


size_t UShaderParser::Property_rgbaContext::getRuleIndex() const {
  return UShaderParser::RuleProperty_rgba;
}

void UShaderParser::Property_rgbaContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_rgba(this);
}

void UShaderParser::Property_rgbaContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_rgba(this);
}


antlrcpp::Any UShaderParser::Property_rgbaContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_rgba(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_rgbaContext* UShaderParser::property_rgba() {
  Property_rgbaContext *_localctx = _tracker.createInstance<Property_rgbaContext>(_ctx, getState());
  enterRule(_localctx, 56, UShaderParser::RuleProperty_rgba);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(459);
    property_name();
    setState(460);
    match(UShaderParser::T__6);
    setState(461);
    display_name();
    setState(462);
    match(UShaderParser::T__7);
    setState(463);
    match(UShaderParser::T__32);
    setState(464);
    match(UShaderParser::T__9);
    setState(465);
    match(UShaderParser::T__4);
    setState(466);
    val_float4();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_boolContext ------------------------------------------------------------------

UShaderParser::Val_boolContext::Val_boolContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Val_boolContext::BooleanLiteral() {
  return getToken(UShaderParser::BooleanLiteral, 0);
}


size_t UShaderParser::Val_boolContext::getRuleIndex() const {
  return UShaderParser::RuleVal_bool;
}

void UShaderParser::Val_boolContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_bool(this);
}

void UShaderParser::Val_boolContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_bool(this);
}


antlrcpp::Any UShaderParser::Val_boolContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_bool(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_boolContext* UShaderParser::val_bool() {
  Val_boolContext *_localctx = _tracker.createInstance<Val_boolContext>(_ctx, getState());
  enterRule(_localctx, 58, UShaderParser::RuleVal_bool);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(468);
    match(UShaderParser::BooleanLiteral);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_intContext ------------------------------------------------------------------

UShaderParser::Val_intContext::Val_intContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Val_intContext::IntegerLiteral() {
  return getToken(UShaderParser::IntegerLiteral, 0);
}

tree::TerminalNode* UShaderParser::Val_intContext::Sign() {
  return getToken(UShaderParser::Sign, 0);
}


size_t UShaderParser::Val_intContext::getRuleIndex() const {
  return UShaderParser::RuleVal_int;
}

void UShaderParser::Val_intContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_int(this);
}

void UShaderParser::Val_intContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_int(this);
}


antlrcpp::Any UShaderParser::Val_intContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_int(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_intContext* UShaderParser::val_int() {
  Val_intContext *_localctx = _tracker.createInstance<Val_intContext>(_ctx, getState());
  enterRule(_localctx, 60, UShaderParser::RuleVal_int);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(471);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == UShaderParser::Sign) {
      setState(470);
      match(UShaderParser::Sign);
    }
    setState(473);
    match(UShaderParser::IntegerLiteral);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_uintContext ------------------------------------------------------------------

UShaderParser::Val_uintContext::Val_uintContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Val_uintContext::IntegerLiteral() {
  return getToken(UShaderParser::IntegerLiteral, 0);
}


size_t UShaderParser::Val_uintContext::getRuleIndex() const {
  return UShaderParser::RuleVal_uint;
}

void UShaderParser::Val_uintContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_uint(this);
}

void UShaderParser::Val_uintContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_uint(this);
}


antlrcpp::Any UShaderParser::Val_uintContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_uint(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_uintContext* UShaderParser::val_uint() {
  Val_uintContext *_localctx = _tracker.createInstance<Val_uintContext>(_ctx, getState());
  enterRule(_localctx, 62, UShaderParser::RuleVal_uint);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(475);
    match(UShaderParser::IntegerLiteral);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_floatContext ------------------------------------------------------------------

UShaderParser::Val_floatContext::Val_floatContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Val_floatContext::IntegerLiteral() {
  return getToken(UShaderParser::IntegerLiteral, 0);
}

tree::TerminalNode* UShaderParser::Val_floatContext::Sign() {
  return getToken(UShaderParser::Sign, 0);
}

tree::TerminalNode* UShaderParser::Val_floatContext::FloatingLiteral() {
  return getToken(UShaderParser::FloatingLiteral, 0);
}


size_t UShaderParser::Val_floatContext::getRuleIndex() const {
  return UShaderParser::RuleVal_float;
}

void UShaderParser::Val_floatContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_float(this);
}

void UShaderParser::Val_floatContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_float(this);
}


antlrcpp::Any UShaderParser::Val_floatContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_float(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_floatContext* UShaderParser::val_float() {
  Val_floatContext *_localctx = _tracker.createInstance<Val_floatContext>(_ctx, getState());
  enterRule(_localctx, 64, UShaderParser::RuleVal_float);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(485);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 7, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(478);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == UShaderParser::Sign) {
        setState(477);
        match(UShaderParser::Sign);
      }
      setState(480);
      match(UShaderParser::IntegerLiteral);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(482);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == UShaderParser::Sign) {
        setState(481);
        match(UShaderParser::Sign);
      }
      setState(484);
      match(UShaderParser::FloatingLiteral);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_doubleContext ------------------------------------------------------------------

UShaderParser::Val_doubleContext::Val_doubleContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Val_doubleContext::IntegerLiteral() {
  return getToken(UShaderParser::IntegerLiteral, 0);
}

tree::TerminalNode* UShaderParser::Val_doubleContext::Sign() {
  return getToken(UShaderParser::Sign, 0);
}

tree::TerminalNode* UShaderParser::Val_doubleContext::FloatingLiteral() {
  return getToken(UShaderParser::FloatingLiteral, 0);
}


size_t UShaderParser::Val_doubleContext::getRuleIndex() const {
  return UShaderParser::RuleVal_double;
}

void UShaderParser::Val_doubleContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_double(this);
}

void UShaderParser::Val_doubleContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_double(this);
}


antlrcpp::Any UShaderParser::Val_doubleContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_double(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_doubleContext* UShaderParser::val_double() {
  Val_doubleContext *_localctx = _tracker.createInstance<Val_doubleContext>(_ctx, getState());
  enterRule(_localctx, 66, UShaderParser::RuleVal_double);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(495);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 10, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(488);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == UShaderParser::Sign) {
        setState(487);
        match(UShaderParser::Sign);
      }
      setState(490);
      match(UShaderParser::IntegerLiteral);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(492);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == UShaderParser::Sign) {
        setState(491);
        match(UShaderParser::Sign);
      }
      setState(494);
      match(UShaderParser::FloatingLiteral);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_bool2Context ------------------------------------------------------------------

UShaderParser::Val_bool2Context::Val_bool2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Val_boolContext *> UShaderParser::Val_bool2Context::val_bool() {
  return getRuleContexts<UShaderParser::Val_boolContext>();
}

UShaderParser::Val_boolContext* UShaderParser::Val_bool2Context::val_bool(size_t i) {
  return getRuleContext<UShaderParser::Val_boolContext>(i);
}


size_t UShaderParser::Val_bool2Context::getRuleIndex() const {
  return UShaderParser::RuleVal_bool2;
}

void UShaderParser::Val_bool2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_bool2(this);
}

void UShaderParser::Val_bool2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_bool2(this);
}


antlrcpp::Any UShaderParser::Val_bool2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_bool2(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_bool2Context* UShaderParser::val_bool2() {
  Val_bool2Context *_localctx = _tracker.createInstance<Val_bool2Context>(_ctx, getState());
  enterRule(_localctx, 68, UShaderParser::RuleVal_bool2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(497);
    match(UShaderParser::T__6);
    setState(498);
    val_bool();
    setState(499);
    match(UShaderParser::T__7);
    setState(500);
    val_bool();
    setState(501);
    match(UShaderParser::T__9);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_bool3Context ------------------------------------------------------------------

UShaderParser::Val_bool3Context::Val_bool3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Val_boolContext *> UShaderParser::Val_bool3Context::val_bool() {
  return getRuleContexts<UShaderParser::Val_boolContext>();
}

UShaderParser::Val_boolContext* UShaderParser::Val_bool3Context::val_bool(size_t i) {
  return getRuleContext<UShaderParser::Val_boolContext>(i);
}


size_t UShaderParser::Val_bool3Context::getRuleIndex() const {
  return UShaderParser::RuleVal_bool3;
}

void UShaderParser::Val_bool3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_bool3(this);
}

void UShaderParser::Val_bool3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_bool3(this);
}


antlrcpp::Any UShaderParser::Val_bool3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_bool3(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_bool3Context* UShaderParser::val_bool3() {
  Val_bool3Context *_localctx = _tracker.createInstance<Val_bool3Context>(_ctx, getState());
  enterRule(_localctx, 70, UShaderParser::RuleVal_bool3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(503);
    match(UShaderParser::T__6);
    setState(504);
    val_bool();
    setState(505);
    match(UShaderParser::T__7);
    setState(506);
    val_bool();
    setState(507);
    match(UShaderParser::T__7);
    setState(508);
    val_bool();
    setState(509);
    match(UShaderParser::T__9);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_bool4Context ------------------------------------------------------------------

UShaderParser::Val_bool4Context::Val_bool4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Val_boolContext *> UShaderParser::Val_bool4Context::val_bool() {
  return getRuleContexts<UShaderParser::Val_boolContext>();
}

UShaderParser::Val_boolContext* UShaderParser::Val_bool4Context::val_bool(size_t i) {
  return getRuleContext<UShaderParser::Val_boolContext>(i);
}


size_t UShaderParser::Val_bool4Context::getRuleIndex() const {
  return UShaderParser::RuleVal_bool4;
}

void UShaderParser::Val_bool4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_bool4(this);
}

void UShaderParser::Val_bool4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_bool4(this);
}


antlrcpp::Any UShaderParser::Val_bool4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_bool4(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_bool4Context* UShaderParser::val_bool4() {
  Val_bool4Context *_localctx = _tracker.createInstance<Val_bool4Context>(_ctx, getState());
  enterRule(_localctx, 72, UShaderParser::RuleVal_bool4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(511);
    match(UShaderParser::T__6);
    setState(512);
    val_bool();
    setState(513);
    match(UShaderParser::T__7);
    setState(514);
    val_bool();
    setState(515);
    match(UShaderParser::T__7);
    setState(516);
    val_bool();
    setState(517);
    match(UShaderParser::T__7);
    setState(518);
    val_bool();
    setState(519);
    match(UShaderParser::T__9);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_int2Context ------------------------------------------------------------------

UShaderParser::Val_int2Context::Val_int2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Val_intContext *> UShaderParser::Val_int2Context::val_int() {
  return getRuleContexts<UShaderParser::Val_intContext>();
}

UShaderParser::Val_intContext* UShaderParser::Val_int2Context::val_int(size_t i) {
  return getRuleContext<UShaderParser::Val_intContext>(i);
}


size_t UShaderParser::Val_int2Context::getRuleIndex() const {
  return UShaderParser::RuleVal_int2;
}

void UShaderParser::Val_int2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_int2(this);
}

void UShaderParser::Val_int2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_int2(this);
}


antlrcpp::Any UShaderParser::Val_int2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_int2(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_int2Context* UShaderParser::val_int2() {
  Val_int2Context *_localctx = _tracker.createInstance<Val_int2Context>(_ctx, getState());
  enterRule(_localctx, 74, UShaderParser::RuleVal_int2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(521);
    match(UShaderParser::T__6);
    setState(522);
    val_int();
    setState(523);
    match(UShaderParser::T__7);
    setState(524);
    val_int();
    setState(525);
    match(UShaderParser::T__9);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_int3Context ------------------------------------------------------------------

UShaderParser::Val_int3Context::Val_int3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Val_intContext *> UShaderParser::Val_int3Context::val_int() {
  return getRuleContexts<UShaderParser::Val_intContext>();
}

UShaderParser::Val_intContext* UShaderParser::Val_int3Context::val_int(size_t i) {
  return getRuleContext<UShaderParser::Val_intContext>(i);
}


size_t UShaderParser::Val_int3Context::getRuleIndex() const {
  return UShaderParser::RuleVal_int3;
}

void UShaderParser::Val_int3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_int3(this);
}

void UShaderParser::Val_int3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_int3(this);
}


antlrcpp::Any UShaderParser::Val_int3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_int3(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_int3Context* UShaderParser::val_int3() {
  Val_int3Context *_localctx = _tracker.createInstance<Val_int3Context>(_ctx, getState());
  enterRule(_localctx, 76, UShaderParser::RuleVal_int3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(527);
    match(UShaderParser::T__6);
    setState(528);
    val_int();
    setState(529);
    match(UShaderParser::T__7);
    setState(530);
    val_int();
    setState(531);
    match(UShaderParser::T__7);
    setState(532);
    val_int();
    setState(533);
    match(UShaderParser::T__9);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_int4Context ------------------------------------------------------------------

UShaderParser::Val_int4Context::Val_int4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Val_intContext *> UShaderParser::Val_int4Context::val_int() {
  return getRuleContexts<UShaderParser::Val_intContext>();
}

UShaderParser::Val_intContext* UShaderParser::Val_int4Context::val_int(size_t i) {
  return getRuleContext<UShaderParser::Val_intContext>(i);
}


size_t UShaderParser::Val_int4Context::getRuleIndex() const {
  return UShaderParser::RuleVal_int4;
}

void UShaderParser::Val_int4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_int4(this);
}

void UShaderParser::Val_int4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_int4(this);
}


antlrcpp::Any UShaderParser::Val_int4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_int4(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_int4Context* UShaderParser::val_int4() {
  Val_int4Context *_localctx = _tracker.createInstance<Val_int4Context>(_ctx, getState());
  enterRule(_localctx, 78, UShaderParser::RuleVal_int4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(535);
    match(UShaderParser::T__6);
    setState(536);
    val_int();
    setState(537);
    match(UShaderParser::T__7);
    setState(538);
    val_int();
    setState(539);
    match(UShaderParser::T__7);
    setState(540);
    val_int();
    setState(541);
    match(UShaderParser::T__7);
    setState(542);
    val_int();
    setState(543);
    match(UShaderParser::T__9);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_uint2Context ------------------------------------------------------------------

UShaderParser::Val_uint2Context::Val_uint2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Val_uintContext *> UShaderParser::Val_uint2Context::val_uint() {
  return getRuleContexts<UShaderParser::Val_uintContext>();
}

UShaderParser::Val_uintContext* UShaderParser::Val_uint2Context::val_uint(size_t i) {
  return getRuleContext<UShaderParser::Val_uintContext>(i);
}


size_t UShaderParser::Val_uint2Context::getRuleIndex() const {
  return UShaderParser::RuleVal_uint2;
}

void UShaderParser::Val_uint2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_uint2(this);
}

void UShaderParser::Val_uint2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_uint2(this);
}


antlrcpp::Any UShaderParser::Val_uint2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_uint2(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_uint2Context* UShaderParser::val_uint2() {
  Val_uint2Context *_localctx = _tracker.createInstance<Val_uint2Context>(_ctx, getState());
  enterRule(_localctx, 80, UShaderParser::RuleVal_uint2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(545);
    match(UShaderParser::T__6);
    setState(546);
    val_uint();
    setState(547);
    match(UShaderParser::T__7);
    setState(548);
    val_uint();
    setState(549);
    match(UShaderParser::T__9);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_uint3Context ------------------------------------------------------------------

UShaderParser::Val_uint3Context::Val_uint3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Val_uintContext *> UShaderParser::Val_uint3Context::val_uint() {
  return getRuleContexts<UShaderParser::Val_uintContext>();
}

UShaderParser::Val_uintContext* UShaderParser::Val_uint3Context::val_uint(size_t i) {
  return getRuleContext<UShaderParser::Val_uintContext>(i);
}


size_t UShaderParser::Val_uint3Context::getRuleIndex() const {
  return UShaderParser::RuleVal_uint3;
}

void UShaderParser::Val_uint3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_uint3(this);
}

void UShaderParser::Val_uint3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_uint3(this);
}


antlrcpp::Any UShaderParser::Val_uint3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_uint3(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_uint3Context* UShaderParser::val_uint3() {
  Val_uint3Context *_localctx = _tracker.createInstance<Val_uint3Context>(_ctx, getState());
  enterRule(_localctx, 82, UShaderParser::RuleVal_uint3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(551);
    match(UShaderParser::T__6);
    setState(552);
    val_uint();
    setState(553);
    match(UShaderParser::T__7);
    setState(554);
    val_uint();
    setState(555);
    match(UShaderParser::T__7);
    setState(556);
    val_uint();
    setState(557);
    match(UShaderParser::T__9);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_uint4Context ------------------------------------------------------------------

UShaderParser::Val_uint4Context::Val_uint4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Val_uintContext *> UShaderParser::Val_uint4Context::val_uint() {
  return getRuleContexts<UShaderParser::Val_uintContext>();
}

UShaderParser::Val_uintContext* UShaderParser::Val_uint4Context::val_uint(size_t i) {
  return getRuleContext<UShaderParser::Val_uintContext>(i);
}


size_t UShaderParser::Val_uint4Context::getRuleIndex() const {
  return UShaderParser::RuleVal_uint4;
}

void UShaderParser::Val_uint4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_uint4(this);
}

void UShaderParser::Val_uint4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_uint4(this);
}


antlrcpp::Any UShaderParser::Val_uint4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_uint4(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_uint4Context* UShaderParser::val_uint4() {
  Val_uint4Context *_localctx = _tracker.createInstance<Val_uint4Context>(_ctx, getState());
  enterRule(_localctx, 84, UShaderParser::RuleVal_uint4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(559);
    match(UShaderParser::T__6);
    setState(560);
    val_uint();
    setState(561);
    match(UShaderParser::T__7);
    setState(562);
    val_uint();
    setState(563);
    match(UShaderParser::T__7);
    setState(564);
    val_uint();
    setState(565);
    match(UShaderParser::T__7);
    setState(566);
    val_uint();
    setState(567);
    match(UShaderParser::T__9);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_float2Context ------------------------------------------------------------------

UShaderParser::Val_float2Context::Val_float2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Val_floatContext *> UShaderParser::Val_float2Context::val_float() {
  return getRuleContexts<UShaderParser::Val_floatContext>();
}

UShaderParser::Val_floatContext* UShaderParser::Val_float2Context::val_float(size_t i) {
  return getRuleContext<UShaderParser::Val_floatContext>(i);
}


size_t UShaderParser::Val_float2Context::getRuleIndex() const {
  return UShaderParser::RuleVal_float2;
}

void UShaderParser::Val_float2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_float2(this);
}

void UShaderParser::Val_float2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_float2(this);
}


antlrcpp::Any UShaderParser::Val_float2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_float2(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_float2Context* UShaderParser::val_float2() {
  Val_float2Context *_localctx = _tracker.createInstance<Val_float2Context>(_ctx, getState());
  enterRule(_localctx, 86, UShaderParser::RuleVal_float2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(569);
    match(UShaderParser::T__6);
    setState(570);
    val_float();
    setState(571);
    match(UShaderParser::T__7);
    setState(572);
    val_float();
    setState(573);
    match(UShaderParser::T__9);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_float3Context ------------------------------------------------------------------

UShaderParser::Val_float3Context::Val_float3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Val_floatContext *> UShaderParser::Val_float3Context::val_float() {
  return getRuleContexts<UShaderParser::Val_floatContext>();
}

UShaderParser::Val_floatContext* UShaderParser::Val_float3Context::val_float(size_t i) {
  return getRuleContext<UShaderParser::Val_floatContext>(i);
}


size_t UShaderParser::Val_float3Context::getRuleIndex() const {
  return UShaderParser::RuleVal_float3;
}

void UShaderParser::Val_float3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_float3(this);
}

void UShaderParser::Val_float3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_float3(this);
}


antlrcpp::Any UShaderParser::Val_float3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_float3(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_float3Context* UShaderParser::val_float3() {
  Val_float3Context *_localctx = _tracker.createInstance<Val_float3Context>(_ctx, getState());
  enterRule(_localctx, 88, UShaderParser::RuleVal_float3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(575);
    match(UShaderParser::T__6);
    setState(576);
    val_float();
    setState(577);
    match(UShaderParser::T__7);
    setState(578);
    val_float();
    setState(579);
    match(UShaderParser::T__7);
    setState(580);
    val_float();
    setState(581);
    match(UShaderParser::T__9);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_float4Context ------------------------------------------------------------------

UShaderParser::Val_float4Context::Val_float4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Val_floatContext *> UShaderParser::Val_float4Context::val_float() {
  return getRuleContexts<UShaderParser::Val_floatContext>();
}

UShaderParser::Val_floatContext* UShaderParser::Val_float4Context::val_float(size_t i) {
  return getRuleContext<UShaderParser::Val_floatContext>(i);
}


size_t UShaderParser::Val_float4Context::getRuleIndex() const {
  return UShaderParser::RuleVal_float4;
}

void UShaderParser::Val_float4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_float4(this);
}

void UShaderParser::Val_float4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_float4(this);
}


antlrcpp::Any UShaderParser::Val_float4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_float4(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_float4Context* UShaderParser::val_float4() {
  Val_float4Context *_localctx = _tracker.createInstance<Val_float4Context>(_ctx, getState());
  enterRule(_localctx, 90, UShaderParser::RuleVal_float4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(583);
    match(UShaderParser::T__6);
    setState(584);
    val_float();
    setState(585);
    match(UShaderParser::T__7);
    setState(586);
    val_float();
    setState(587);
    match(UShaderParser::T__7);
    setState(588);
    val_float();
    setState(589);
    match(UShaderParser::T__7);
    setState(590);
    val_float();
    setState(591);
    match(UShaderParser::T__9);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_double2Context ------------------------------------------------------------------

UShaderParser::Val_double2Context::Val_double2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Val_doubleContext *> UShaderParser::Val_double2Context::val_double() {
  return getRuleContexts<UShaderParser::Val_doubleContext>();
}

UShaderParser::Val_doubleContext* UShaderParser::Val_double2Context::val_double(size_t i) {
  return getRuleContext<UShaderParser::Val_doubleContext>(i);
}


size_t UShaderParser::Val_double2Context::getRuleIndex() const {
  return UShaderParser::RuleVal_double2;
}

void UShaderParser::Val_double2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_double2(this);
}

void UShaderParser::Val_double2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_double2(this);
}


antlrcpp::Any UShaderParser::Val_double2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_double2(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_double2Context* UShaderParser::val_double2() {
  Val_double2Context *_localctx = _tracker.createInstance<Val_double2Context>(_ctx, getState());
  enterRule(_localctx, 92, UShaderParser::RuleVal_double2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(593);
    match(UShaderParser::T__6);
    setState(594);
    val_double();
    setState(595);
    match(UShaderParser::T__7);
    setState(596);
    val_double();
    setState(597);
    match(UShaderParser::T__9);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_double3Context ------------------------------------------------------------------

UShaderParser::Val_double3Context::Val_double3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Val_doubleContext *> UShaderParser::Val_double3Context::val_double() {
  return getRuleContexts<UShaderParser::Val_doubleContext>();
}

UShaderParser::Val_doubleContext* UShaderParser::Val_double3Context::val_double(size_t i) {
  return getRuleContext<UShaderParser::Val_doubleContext>(i);
}


size_t UShaderParser::Val_double3Context::getRuleIndex() const {
  return UShaderParser::RuleVal_double3;
}

void UShaderParser::Val_double3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_double3(this);
}

void UShaderParser::Val_double3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_double3(this);
}


antlrcpp::Any UShaderParser::Val_double3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_double3(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_double3Context* UShaderParser::val_double3() {
  Val_double3Context *_localctx = _tracker.createInstance<Val_double3Context>(_ctx, getState());
  enterRule(_localctx, 94, UShaderParser::RuleVal_double3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(599);
    match(UShaderParser::T__6);
    setState(600);
    val_double();
    setState(601);
    match(UShaderParser::T__7);
    setState(602);
    val_double();
    setState(603);
    match(UShaderParser::T__7);
    setState(604);
    val_double();
    setState(605);
    match(UShaderParser::T__9);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_double4Context ------------------------------------------------------------------

UShaderParser::Val_double4Context::Val_double4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Val_doubleContext *> UShaderParser::Val_double4Context::val_double() {
  return getRuleContexts<UShaderParser::Val_doubleContext>();
}

UShaderParser::Val_doubleContext* UShaderParser::Val_double4Context::val_double(size_t i) {
  return getRuleContext<UShaderParser::Val_doubleContext>(i);
}


size_t UShaderParser::Val_double4Context::getRuleIndex() const {
  return UShaderParser::RuleVal_double4;
}

void UShaderParser::Val_double4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_double4(this);
}

void UShaderParser::Val_double4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_double4(this);
}


antlrcpp::Any UShaderParser::Val_double4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_double4(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_double4Context* UShaderParser::val_double4() {
  Val_double4Context *_localctx = _tracker.createInstance<Val_double4Context>(_ctx, getState());
  enterRule(_localctx, 96, UShaderParser::RuleVal_double4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(607);
    match(UShaderParser::T__6);
    setState(608);
    val_double();
    setState(609);
    match(UShaderParser::T__7);
    setState(610);
    val_double();
    setState(611);
    match(UShaderParser::T__7);
    setState(612);
    val_double();
    setState(613);
    match(UShaderParser::T__7);
    setState(614);
    val_double();
    setState(615);
    match(UShaderParser::T__9);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_tex2dContext ------------------------------------------------------------------

UShaderParser::Val_tex2dContext::Val_tex2dContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Default_texture_2dContext* UShaderParser::Val_tex2dContext::default_texture_2d() {
  return getRuleContext<UShaderParser::Default_texture_2dContext>(0);
}

tree::TerminalNode* UShaderParser::Val_tex2dContext::StringLiteral() {
  return getToken(UShaderParser::StringLiteral, 0);
}


size_t UShaderParser::Val_tex2dContext::getRuleIndex() const {
  return UShaderParser::RuleVal_tex2d;
}

void UShaderParser::Val_tex2dContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_tex2d(this);
}

void UShaderParser::Val_tex2dContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_tex2d(this);
}


antlrcpp::Any UShaderParser::Val_tex2dContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_tex2d(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_tex2dContext* UShaderParser::val_tex2d() {
  Val_tex2dContext *_localctx = _tracker.createInstance<Val_tex2dContext>(_ctx, getState());
  enterRule(_localctx, 98, UShaderParser::RuleVal_tex2d);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(619);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case UShaderParser::T__33:
      case UShaderParser::T__34:
      case UShaderParser::T__35: {
        enterOuterAlt(_localctx, 1);
        setState(617);
        default_texture_2d();
        break;
      }

      case UShaderParser::StringLiteral: {
        enterOuterAlt(_localctx, 2);
        setState(618);
        match(UShaderParser::StringLiteral);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Default_texture_2dContext ------------------------------------------------------------------

UShaderParser::Default_texture_2dContext::Default_texture_2dContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t UShaderParser::Default_texture_2dContext::getRuleIndex() const {
  return UShaderParser::RuleDefault_texture_2d;
}

void UShaderParser::Default_texture_2dContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDefault_texture_2d(this);
}

void UShaderParser::Default_texture_2dContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDefault_texture_2d(this);
}


antlrcpp::Any UShaderParser::Default_texture_2dContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitDefault_texture_2d(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Default_texture_2dContext* UShaderParser::default_texture_2d() {
  Default_texture_2dContext *_localctx = _tracker.createInstance<Default_texture_2dContext>(_ctx, getState());
  enterRule(_localctx, 100, UShaderParser::RuleDefault_texture_2d);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(621);
    _la = _input->LA(1);
    if (!((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << UShaderParser::T__33)
      | (1ULL << UShaderParser::T__34)
      | (1ULL << UShaderParser::T__35))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_texcubeContext ------------------------------------------------------------------

UShaderParser::Val_texcubeContext::Val_texcubeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Default_texture_cubeContext* UShaderParser::Val_texcubeContext::default_texture_cube() {
  return getRuleContext<UShaderParser::Default_texture_cubeContext>(0);
}

tree::TerminalNode* UShaderParser::Val_texcubeContext::StringLiteral() {
  return getToken(UShaderParser::StringLiteral, 0);
}


size_t UShaderParser::Val_texcubeContext::getRuleIndex() const {
  return UShaderParser::RuleVal_texcube;
}

void UShaderParser::Val_texcubeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_texcube(this);
}

void UShaderParser::Val_texcubeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_texcube(this);
}


antlrcpp::Any UShaderParser::Val_texcubeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_texcube(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_texcubeContext* UShaderParser::val_texcube() {
  Val_texcubeContext *_localctx = _tracker.createInstance<Val_texcubeContext>(_ctx, getState());
  enterRule(_localctx, 102, UShaderParser::RuleVal_texcube);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(625);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case UShaderParser::T__33:
      case UShaderParser::T__34: {
        enterOuterAlt(_localctx, 1);
        setState(623);
        default_texture_cube();
        break;
      }

      case UShaderParser::StringLiteral: {
        enterOuterAlt(_localctx, 2);
        setState(624);
        match(UShaderParser::StringLiteral);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Default_texture_cubeContext ------------------------------------------------------------------

UShaderParser::Default_texture_cubeContext::Default_texture_cubeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t UShaderParser::Default_texture_cubeContext::getRuleIndex() const {
  return UShaderParser::RuleDefault_texture_cube;
}

void UShaderParser::Default_texture_cubeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDefault_texture_cube(this);
}

void UShaderParser::Default_texture_cubeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDefault_texture_cube(this);
}


antlrcpp::Any UShaderParser::Default_texture_cubeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitDefault_texture_cube(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Default_texture_cubeContext* UShaderParser::default_texture_cube() {
  Default_texture_cubeContext *_localctx = _tracker.createInstance<Default_texture_cubeContext>(_ctx, getState());
  enterRule(_localctx, 104, UShaderParser::RuleDefault_texture_cube);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(627);
    _la = _input->LA(1);
    if (!(_la == UShaderParser::T__33

    || _la == UShaderParser::T__34)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Property_nameContext ------------------------------------------------------------------

UShaderParser::Property_nameContext::Property_nameContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Property_nameContext::ID() {
  return getToken(UShaderParser::ID, 0);
}


size_t UShaderParser::Property_nameContext::getRuleIndex() const {
  return UShaderParser::RuleProperty_name;
}

void UShaderParser::Property_nameContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterProperty_name(this);
}

void UShaderParser::Property_nameContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitProperty_name(this);
}


antlrcpp::Any UShaderParser::Property_nameContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitProperty_name(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Property_nameContext* UShaderParser::property_name() {
  Property_nameContext *_localctx = _tracker.createInstance<Property_nameContext>(_ctx, getState());
  enterRule(_localctx, 106, UShaderParser::RuleProperty_name);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(629);
    match(UShaderParser::ID);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Display_nameContext ------------------------------------------------------------------

UShaderParser::Display_nameContext::Display_nameContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Display_nameContext::StringLiteral() {
  return getToken(UShaderParser::StringLiteral, 0);
}


size_t UShaderParser::Display_nameContext::getRuleIndex() const {
  return UShaderParser::RuleDisplay_name;
}

void UShaderParser::Display_nameContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDisplay_name(this);
}

void UShaderParser::Display_nameContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDisplay_name(this);
}


antlrcpp::Any UShaderParser::Display_nameContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitDisplay_name(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Display_nameContext* UShaderParser::display_name() {
  Display_nameContext *_localctx = _tracker.createInstance<Display_nameContext>(_ctx, getState());
  enterRule(_localctx, 108, UShaderParser::RuleDisplay_name);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(631);
    match(UShaderParser::StringLiteral);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Root_signatureContext ------------------------------------------------------------------

UShaderParser::Root_signatureContext::Root_signatureContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Root_parameterContext *> UShaderParser::Root_signatureContext::root_parameter() {
  return getRuleContexts<UShaderParser::Root_parameterContext>();
}

UShaderParser::Root_parameterContext* UShaderParser::Root_signatureContext::root_parameter(size_t i) {
  return getRuleContext<UShaderParser::Root_parameterContext>(i);
}


size_t UShaderParser::Root_signatureContext::getRuleIndex() const {
  return UShaderParser::RuleRoot_signature;
}

void UShaderParser::Root_signatureContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterRoot_signature(this);
}

void UShaderParser::Root_signatureContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitRoot_signature(this);
}


antlrcpp::Any UShaderParser::Root_signatureContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitRoot_signature(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Root_signatureContext* UShaderParser::root_signature() {
  Root_signatureContext *_localctx = _tracker.createInstance<Root_signatureContext>(_ctx, getState());
  enterRule(_localctx, 110, UShaderParser::RuleRoot_signature);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(633);
    match(UShaderParser::T__36);
    setState(634);
    match(UShaderParser::T__1);
    setState(636); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(635);
      root_parameter();
      setState(638); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while (_la == UShaderParser::RootDescriptorType);
    setState(640);
    match(UShaderParser::T__2);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Root_parameterContext ------------------------------------------------------------------

UShaderParser::Root_parameterContext::Root_parameterContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Root_parameterContext::RootDescriptorType() {
  return getToken(UShaderParser::RootDescriptorType, 0);
}

UShaderParser::Register_indexContext* UShaderParser::Root_parameterContext::register_index() {
  return getRuleContext<UShaderParser::Register_indexContext>(0);
}

UShaderParser::Register_numContext* UShaderParser::Root_parameterContext::register_num() {
  return getRuleContext<UShaderParser::Register_numContext>(0);
}


size_t UShaderParser::Root_parameterContext::getRuleIndex() const {
  return UShaderParser::RuleRoot_parameter;
}

void UShaderParser::Root_parameterContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterRoot_parameter(this);
}

void UShaderParser::Root_parameterContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitRoot_parameter(this);
}


antlrcpp::Any UShaderParser::Root_parameterContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitRoot_parameter(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Root_parameterContext* UShaderParser::root_parameter() {
  Root_parameterContext *_localctx = _tracker.createInstance<Root_parameterContext>(_ctx, getState());
  enterRule(_localctx, 112, UShaderParser::RuleRoot_parameter);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(642);
    match(UShaderParser::RootDescriptorType);
    setState(647);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == UShaderParser::T__37) {
      setState(643);
      match(UShaderParser::T__37);
      setState(644);
      register_num();
      setState(645);
      match(UShaderParser::T__38);
    }
    setState(649);
    match(UShaderParser::T__4);
    setState(650);
    register_index();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Register_indexContext ------------------------------------------------------------------

UShaderParser::Register_indexContext::Register_indexContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Shader_registerContext* UShaderParser::Register_indexContext::shader_register() {
  return getRuleContext<UShaderParser::Shader_registerContext>(0);
}

UShaderParser::Register_spaceContext* UShaderParser::Register_indexContext::register_space() {
  return getRuleContext<UShaderParser::Register_spaceContext>(0);
}


size_t UShaderParser::Register_indexContext::getRuleIndex() const {
  return UShaderParser::RuleRegister_index;
}

void UShaderParser::Register_indexContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterRegister_index(this);
}

void UShaderParser::Register_indexContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitRegister_index(this);
}


antlrcpp::Any UShaderParser::Register_indexContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitRegister_index(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Register_indexContext* UShaderParser::register_index() {
  Register_indexContext *_localctx = _tracker.createInstance<Register_indexContext>(_ctx, getState());
  enterRule(_localctx, 114, UShaderParser::RuleRegister_index);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(659);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case UShaderParser::IntegerLiteral: {
        enterOuterAlt(_localctx, 1);
        setState(652);
        shader_register();
        break;
      }

      case UShaderParser::T__6: {
        enterOuterAlt(_localctx, 2);
        setState(653);
        match(UShaderParser::T__6);
        setState(654);
        shader_register();
        setState(655);
        match(UShaderParser::T__7);
        setState(656);
        register_space();
        setState(657);
        match(UShaderParser::T__9);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Shader_registerContext ------------------------------------------------------------------

UShaderParser::Shader_registerContext::Shader_registerContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Shader_registerContext::IntegerLiteral() {
  return getToken(UShaderParser::IntegerLiteral, 0);
}


size_t UShaderParser::Shader_registerContext::getRuleIndex() const {
  return UShaderParser::RuleShader_register;
}

void UShaderParser::Shader_registerContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterShader_register(this);
}

void UShaderParser::Shader_registerContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitShader_register(this);
}


antlrcpp::Any UShaderParser::Shader_registerContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitShader_register(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Shader_registerContext* UShaderParser::shader_register() {
  Shader_registerContext *_localctx = _tracker.createInstance<Shader_registerContext>(_ctx, getState());
  enterRule(_localctx, 116, UShaderParser::RuleShader_register);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(661);
    match(UShaderParser::IntegerLiteral);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Register_spaceContext ------------------------------------------------------------------

UShaderParser::Register_spaceContext::Register_spaceContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Register_spaceContext::IntegerLiteral() {
  return getToken(UShaderParser::IntegerLiteral, 0);
}


size_t UShaderParser::Register_spaceContext::getRuleIndex() const {
  return UShaderParser::RuleRegister_space;
}

void UShaderParser::Register_spaceContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterRegister_space(this);
}

void UShaderParser::Register_spaceContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitRegister_space(this);
}


antlrcpp::Any UShaderParser::Register_spaceContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitRegister_space(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Register_spaceContext* UShaderParser::register_space() {
  Register_spaceContext *_localctx = _tracker.createInstance<Register_spaceContext>(_ctx, getState());
  enterRule(_localctx, 118, UShaderParser::RuleRegister_space);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(663);
    match(UShaderParser::IntegerLiteral);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Register_numContext ------------------------------------------------------------------

UShaderParser::Register_numContext::Register_numContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Register_numContext::IntegerLiteral() {
  return getToken(UShaderParser::IntegerLiteral, 0);
}


size_t UShaderParser::Register_numContext::getRuleIndex() const {
  return UShaderParser::RuleRegister_num;
}

void UShaderParser::Register_numContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterRegister_num(this);
}

void UShaderParser::Register_numContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitRegister_num(this);
}


antlrcpp::Any UShaderParser::Register_numContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitRegister_num(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Register_numContext* UShaderParser::register_num() {
  Register_numContext *_localctx = _tracker.createInstance<Register_numContext>(_ctx, getState());
  enterRule(_localctx, 120, UShaderParser::RuleRegister_num);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(665);
    match(UShaderParser::IntegerLiteral);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- PassContext ------------------------------------------------------------------

UShaderParser::PassContext::PassContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::VsContext* UShaderParser::PassContext::vs() {
  return getRuleContext<UShaderParser::VsContext>(0);
}

UShaderParser::PsContext* UShaderParser::PassContext::ps() {
  return getRuleContext<UShaderParser::PsContext>(0);
}

std::vector<UShaderParser::Pass_statementContext *> UShaderParser::PassContext::pass_statement() {
  return getRuleContexts<UShaderParser::Pass_statementContext>();
}

UShaderParser::Pass_statementContext* UShaderParser::PassContext::pass_statement(size_t i) {
  return getRuleContext<UShaderParser::Pass_statementContext>(i);
}


size_t UShaderParser::PassContext::getRuleIndex() const {
  return UShaderParser::RulePass;
}

void UShaderParser::PassContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterPass(this);
}

void UShaderParser::PassContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitPass(this);
}


antlrcpp::Any UShaderParser::PassContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitPass(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::PassContext* UShaderParser::pass() {
  PassContext *_localctx = _tracker.createInstance<PassContext>(_ctx, getState());
  enterRule(_localctx, 122, UShaderParser::RulePass);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(667);
    match(UShaderParser::T__39);
    setState(668);
    match(UShaderParser::T__6);
    setState(669);
    vs();
    setState(670);
    match(UShaderParser::T__7);
    setState(671);
    ps();
    setState(672);
    match(UShaderParser::T__9);
    setState(673);
    match(UShaderParser::T__1);
    setState(677);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (((((_la - 41) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 41)) & ((1ULL << (UShaderParser::T__40 - 41))
      | (1ULL << (UShaderParser::T__41 - 41))
      | (1ULL << (UShaderParser::T__42 - 41))
      | (1ULL << (UShaderParser::T__43 - 41))
      | (1ULL << (UShaderParser::T__44 - 41))
      | (1ULL << (UShaderParser::T__45 - 41))
      | (1ULL << (UShaderParser::T__50 - 41))
      | (1ULL << (UShaderParser::T__51 - 41))
      | (1ULL << (UShaderParser::T__52 - 41))
      | (1ULL << (UShaderParser::T__67 - 41)))) != 0)) {
      setState(674);
      pass_statement();
      setState(679);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
    setState(680);
    match(UShaderParser::T__2);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- VsContext ------------------------------------------------------------------

UShaderParser::VsContext::VsContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::VsContext::ID() {
  return getToken(UShaderParser::ID, 0);
}


size_t UShaderParser::VsContext::getRuleIndex() const {
  return UShaderParser::RuleVs;
}

void UShaderParser::VsContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVs(this);
}

void UShaderParser::VsContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVs(this);
}


antlrcpp::Any UShaderParser::VsContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVs(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::VsContext* UShaderParser::vs() {
  VsContext *_localctx = _tracker.createInstance<VsContext>(_ctx, getState());
  enterRule(_localctx, 124, UShaderParser::RuleVs);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(682);
    match(UShaderParser::ID);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- PsContext ------------------------------------------------------------------

UShaderParser::PsContext::PsContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::PsContext::ID() {
  return getToken(UShaderParser::ID, 0);
}


size_t UShaderParser::PsContext::getRuleIndex() const {
  return UShaderParser::RulePs;
}

void UShaderParser::PsContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterPs(this);
}

void UShaderParser::PsContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitPs(this);
}


antlrcpp::Any UShaderParser::PsContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitPs(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::PsContext* UShaderParser::ps() {
  PsContext *_localctx = _tracker.createInstance<PsContext>(_ctx, getState());
  enterRule(_localctx, 126, UShaderParser::RulePs);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(684);
    match(UShaderParser::ID);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Pass_statementContext ------------------------------------------------------------------

UShaderParser::Pass_statementContext::Pass_statementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Render_state_setupContext* UShaderParser::Pass_statementContext::render_state_setup() {
  return getRuleContext<UShaderParser::Render_state_setupContext>(0);
}

UShaderParser::TagsContext* UShaderParser::Pass_statementContext::tags() {
  return getRuleContext<UShaderParser::TagsContext>(0);
}

UShaderParser::QueueContext* UShaderParser::Pass_statementContext::queue() {
  return getRuleContext<UShaderParser::QueueContext>(0);
}


size_t UShaderParser::Pass_statementContext::getRuleIndex() const {
  return UShaderParser::RulePass_statement;
}

void UShaderParser::Pass_statementContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterPass_statement(this);
}

void UShaderParser::Pass_statementContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitPass_statement(this);
}


antlrcpp::Any UShaderParser::Pass_statementContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitPass_statement(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Pass_statementContext* UShaderParser::pass_statement() {
  Pass_statementContext *_localctx = _tracker.createInstance<Pass_statementContext>(_ctx, getState());
  enterRule(_localctx, 128, UShaderParser::RulePass_statement);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(689);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case UShaderParser::T__41:
      case UShaderParser::T__42:
      case UShaderParser::T__43:
      case UShaderParser::T__44:
      case UShaderParser::T__45:
      case UShaderParser::T__50:
      case UShaderParser::T__51:
      case UShaderParser::T__52: {
        enterOuterAlt(_localctx, 1);
        setState(686);
        render_state_setup();
        break;
      }

      case UShaderParser::T__40: {
        enterOuterAlt(_localctx, 2);
        setState(687);
        tags();
        break;
      }

      case UShaderParser::T__67: {
        enterOuterAlt(_localctx, 3);
        setState(688);
        queue();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TagsContext ------------------------------------------------------------------

UShaderParser::TagsContext::TagsContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::TagContext *> UShaderParser::TagsContext::tag() {
  return getRuleContexts<UShaderParser::TagContext>();
}

UShaderParser::TagContext* UShaderParser::TagsContext::tag(size_t i) {
  return getRuleContext<UShaderParser::TagContext>(i);
}


size_t UShaderParser::TagsContext::getRuleIndex() const {
  return UShaderParser::RuleTags;
}

void UShaderParser::TagsContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTags(this);
}

void UShaderParser::TagsContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTags(this);
}


antlrcpp::Any UShaderParser::TagsContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitTags(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::TagsContext* UShaderParser::tags() {
  TagsContext *_localctx = _tracker.createInstance<TagsContext>(_ctx, getState());
  enterRule(_localctx, 130, UShaderParser::RuleTags);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(691);
    match(UShaderParser::T__40);
    setState(692);
    match(UShaderParser::T__1);
    setState(694); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(693);
      tag();
      setState(696); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while (_la == UShaderParser::StringLiteral);
    setState(698);
    match(UShaderParser::T__2);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TagContext ------------------------------------------------------------------

UShaderParser::TagContext::TagContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<tree::TerminalNode *> UShaderParser::TagContext::StringLiteral() {
  return getTokens(UShaderParser::StringLiteral);
}

tree::TerminalNode* UShaderParser::TagContext::StringLiteral(size_t i) {
  return getToken(UShaderParser::StringLiteral, i);
}


size_t UShaderParser::TagContext::getRuleIndex() const {
  return UShaderParser::RuleTag;
}

void UShaderParser::TagContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTag(this);
}

void UShaderParser::TagContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTag(this);
}


antlrcpp::Any UShaderParser::TagContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitTag(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::TagContext* UShaderParser::tag() {
  TagContext *_localctx = _tracker.createInstance<TagContext>(_ctx, getState());
  enterRule(_localctx, 132, UShaderParser::RuleTag);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(700);
    match(UShaderParser::StringLiteral);
    setState(701);
    match(UShaderParser::T__4);
    setState(702);
    match(UShaderParser::StringLiteral);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Render_state_setupContext ------------------------------------------------------------------

UShaderParser::Render_state_setupContext::Render_state_setupContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::FillContext* UShaderParser::Render_state_setupContext::fill() {
  return getRuleContext<UShaderParser::FillContext>(0);
}

UShaderParser::CullContext* UShaderParser::Render_state_setupContext::cull() {
  return getRuleContext<UShaderParser::CullContext>(0);
}

UShaderParser::ZtestContext* UShaderParser::Render_state_setupContext::ztest() {
  return getRuleContext<UShaderParser::ZtestContext>(0);
}

UShaderParser::Zwrite_offContext* UShaderParser::Render_state_setupContext::zwrite_off() {
  return getRuleContext<UShaderParser::Zwrite_offContext>(0);
}

UShaderParser::BlendContext* UShaderParser::Render_state_setupContext::blend() {
  return getRuleContext<UShaderParser::BlendContext>(0);
}

UShaderParser::Blend_opContext* UShaderParser::Render_state_setupContext::blend_op() {
  return getRuleContext<UShaderParser::Blend_opContext>(0);
}

UShaderParser::Color_maskContext* UShaderParser::Render_state_setupContext::color_mask() {
  return getRuleContext<UShaderParser::Color_maskContext>(0);
}

UShaderParser::StencilContext* UShaderParser::Render_state_setupContext::stencil() {
  return getRuleContext<UShaderParser::StencilContext>(0);
}


size_t UShaderParser::Render_state_setupContext::getRuleIndex() const {
  return UShaderParser::RuleRender_state_setup;
}

void UShaderParser::Render_state_setupContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterRender_state_setup(this);
}

void UShaderParser::Render_state_setupContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitRender_state_setup(this);
}


antlrcpp::Any UShaderParser::Render_state_setupContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitRender_state_setup(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Render_state_setupContext* UShaderParser::render_state_setup() {
  Render_state_setupContext *_localctx = _tracker.createInstance<Render_state_setupContext>(_ctx, getState());
  enterRule(_localctx, 134, UShaderParser::RuleRender_state_setup);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(712);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case UShaderParser::T__41: {
        enterOuterAlt(_localctx, 1);
        setState(704);
        fill();
        break;
      }

      case UShaderParser::T__42: {
        enterOuterAlt(_localctx, 2);
        setState(705);
        cull();
        break;
      }

      case UShaderParser::T__43: {
        enterOuterAlt(_localctx, 3);
        setState(706);
        ztest();
        break;
      }

      case UShaderParser::T__44: {
        enterOuterAlt(_localctx, 4);
        setState(707);
        zwrite_off();
        break;
      }

      case UShaderParser::T__45: {
        enterOuterAlt(_localctx, 5);
        setState(708);
        blend();
        break;
      }

      case UShaderParser::T__50: {
        enterOuterAlt(_localctx, 6);
        setState(709);
        blend_op();
        break;
      }

      case UShaderParser::T__51: {
        enterOuterAlt(_localctx, 7);
        setState(710);
        color_mask();
        break;
      }

      case UShaderParser::T__52: {
        enterOuterAlt(_localctx, 8);
        setState(711);
        stencil();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- FillContext ------------------------------------------------------------------

UShaderParser::FillContext::FillContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::FillContext::FillMode() {
  return getToken(UShaderParser::FillMode, 0);
}


size_t UShaderParser::FillContext::getRuleIndex() const {
  return UShaderParser::RuleFill;
}

void UShaderParser::FillContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFill(this);
}

void UShaderParser::FillContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFill(this);
}


antlrcpp::Any UShaderParser::FillContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitFill(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::FillContext* UShaderParser::fill() {
  FillContext *_localctx = _tracker.createInstance<FillContext>(_ctx, getState());
  enterRule(_localctx, 136, UShaderParser::RuleFill);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(714);
    match(UShaderParser::T__41);
    setState(715);
    match(UShaderParser::FillMode);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- CullContext ------------------------------------------------------------------

UShaderParser::CullContext::CullContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::CullContext::CullMode() {
  return getToken(UShaderParser::CullMode, 0);
}


size_t UShaderParser::CullContext::getRuleIndex() const {
  return UShaderParser::RuleCull;
}

void UShaderParser::CullContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterCull(this);
}

void UShaderParser::CullContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitCull(this);
}


antlrcpp::Any UShaderParser::CullContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitCull(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::CullContext* UShaderParser::cull() {
  CullContext *_localctx = _tracker.createInstance<CullContext>(_ctx, getState());
  enterRule(_localctx, 138, UShaderParser::RuleCull);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(717);
    match(UShaderParser::T__42);
    setState(718);
    match(UShaderParser::CullMode);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ZtestContext ------------------------------------------------------------------

UShaderParser::ZtestContext::ZtestContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::ZtestContext::Comparator() {
  return getToken(UShaderParser::Comparator, 0);
}


size_t UShaderParser::ZtestContext::getRuleIndex() const {
  return UShaderParser::RuleZtest;
}

void UShaderParser::ZtestContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterZtest(this);
}

void UShaderParser::ZtestContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitZtest(this);
}


antlrcpp::Any UShaderParser::ZtestContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitZtest(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::ZtestContext* UShaderParser::ztest() {
  ZtestContext *_localctx = _tracker.createInstance<ZtestContext>(_ctx, getState());
  enterRule(_localctx, 140, UShaderParser::RuleZtest);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(720);
    match(UShaderParser::T__43);
    setState(721);
    match(UShaderParser::Comparator);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Zwrite_offContext ------------------------------------------------------------------

UShaderParser::Zwrite_offContext::Zwrite_offContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t UShaderParser::Zwrite_offContext::getRuleIndex() const {
  return UShaderParser::RuleZwrite_off;
}

void UShaderParser::Zwrite_offContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterZwrite_off(this);
}

void UShaderParser::Zwrite_offContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitZwrite_off(this);
}


antlrcpp::Any UShaderParser::Zwrite_offContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitZwrite_off(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Zwrite_offContext* UShaderParser::zwrite_off() {
  Zwrite_offContext *_localctx = _tracker.createInstance<Zwrite_offContext>(_ctx, getState());
  enterRule(_localctx, 142, UShaderParser::RuleZwrite_off);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(723);
    match(UShaderParser::T__44);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- BlendContext ------------------------------------------------------------------

UShaderParser::BlendContext::BlendContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::IndexContext* UShaderParser::BlendContext::index() {
  return getRuleContext<UShaderParser::IndexContext>(0);
}

UShaderParser::Blend_exprContext* UShaderParser::BlendContext::blend_expr() {
  return getRuleContext<UShaderParser::Blend_exprContext>(0);
}


size_t UShaderParser::BlendContext::getRuleIndex() const {
  return UShaderParser::RuleBlend;
}

void UShaderParser::BlendContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterBlend(this);
}

void UShaderParser::BlendContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitBlend(this);
}


antlrcpp::Any UShaderParser::BlendContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitBlend(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::BlendContext* UShaderParser::blend() {
  BlendContext *_localctx = _tracker.createInstance<BlendContext>(_ctx, getState());
  enterRule(_localctx, 144, UShaderParser::RuleBlend);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(725);
    match(UShaderParser::T__45);
    setState(730);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == UShaderParser::T__37) {
      setState(726);
      match(UShaderParser::T__37);
      setState(727);
      index();
      setState(728);
      match(UShaderParser::T__38);
    }
    setState(733);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == UShaderParser::T__6) {
      setState(732);
      blend_expr();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Blend_exprContext ------------------------------------------------------------------

UShaderParser::Blend_exprContext::Blend_exprContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Blend_src_factor_colorContext* UShaderParser::Blend_exprContext::blend_src_factor_color() {
  return getRuleContext<UShaderParser::Blend_src_factor_colorContext>(0);
}

UShaderParser::Blend_dst_factor_colorContext* UShaderParser::Blend_exprContext::blend_dst_factor_color() {
  return getRuleContext<UShaderParser::Blend_dst_factor_colorContext>(0);
}

UShaderParser::Blend_src_factor_alphaContext* UShaderParser::Blend_exprContext::blend_src_factor_alpha() {
  return getRuleContext<UShaderParser::Blend_src_factor_alphaContext>(0);
}

UShaderParser::Blend_dst_factor_alphaContext* UShaderParser::Blend_exprContext::blend_dst_factor_alpha() {
  return getRuleContext<UShaderParser::Blend_dst_factor_alphaContext>(0);
}


size_t UShaderParser::Blend_exprContext::getRuleIndex() const {
  return UShaderParser::RuleBlend_expr;
}

void UShaderParser::Blend_exprContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterBlend_expr(this);
}

void UShaderParser::Blend_exprContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitBlend_expr(this);
}


antlrcpp::Any UShaderParser::Blend_exprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitBlend_expr(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Blend_exprContext* UShaderParser::blend_expr() {
  Blend_exprContext *_localctx = _tracker.createInstance<Blend_exprContext>(_ctx, getState());
  enterRule(_localctx, 146, UShaderParser::RuleBlend_expr);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(751);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 22, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(735);
      match(UShaderParser::T__6);
      setState(736);
      blend_src_factor_color();
      setState(737);
      match(UShaderParser::T__7);
      setState(738);
      blend_dst_factor_color();
      setState(739);
      match(UShaderParser::T__9);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(741);
      match(UShaderParser::T__6);
      setState(742);
      blend_src_factor_color();
      setState(743);
      match(UShaderParser::T__7);
      setState(744);
      blend_dst_factor_color();
      setState(745);
      match(UShaderParser::T__7);
      setState(746);
      blend_src_factor_alpha();
      setState(747);
      match(UShaderParser::T__7);
      setState(748);
      blend_dst_factor_alpha();
      setState(749);
      match(UShaderParser::T__9);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- IndexContext ------------------------------------------------------------------

UShaderParser::IndexContext::IndexContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::IndexContext::IntegerLiteral() {
  return getToken(UShaderParser::IntegerLiteral, 0);
}


size_t UShaderParser::IndexContext::getRuleIndex() const {
  return UShaderParser::RuleIndex;
}

void UShaderParser::IndexContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterIndex(this);
}

void UShaderParser::IndexContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitIndex(this);
}


antlrcpp::Any UShaderParser::IndexContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitIndex(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::IndexContext* UShaderParser::index() {
  IndexContext *_localctx = _tracker.createInstance<IndexContext>(_ctx, getState());
  enterRule(_localctx, 148, UShaderParser::RuleIndex);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(753);
    match(UShaderParser::IntegerLiteral);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Blend_src_factor_colorContext ------------------------------------------------------------------

UShaderParser::Blend_src_factor_colorContext::Blend_src_factor_colorContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Blend_factorContext* UShaderParser::Blend_src_factor_colorContext::blend_factor() {
  return getRuleContext<UShaderParser::Blend_factorContext>(0);
}


size_t UShaderParser::Blend_src_factor_colorContext::getRuleIndex() const {
  return UShaderParser::RuleBlend_src_factor_color;
}

void UShaderParser::Blend_src_factor_colorContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterBlend_src_factor_color(this);
}

void UShaderParser::Blend_src_factor_colorContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitBlend_src_factor_color(this);
}


antlrcpp::Any UShaderParser::Blend_src_factor_colorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitBlend_src_factor_color(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Blend_src_factor_colorContext* UShaderParser::blend_src_factor_color() {
  Blend_src_factor_colorContext *_localctx = _tracker.createInstance<Blend_src_factor_colorContext>(_ctx, getState());
  enterRule(_localctx, 150, UShaderParser::RuleBlend_src_factor_color);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(755);
    blend_factor();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Blend_dst_factor_colorContext ------------------------------------------------------------------

UShaderParser::Blend_dst_factor_colorContext::Blend_dst_factor_colorContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Blend_factorContext* UShaderParser::Blend_dst_factor_colorContext::blend_factor() {
  return getRuleContext<UShaderParser::Blend_factorContext>(0);
}


size_t UShaderParser::Blend_dst_factor_colorContext::getRuleIndex() const {
  return UShaderParser::RuleBlend_dst_factor_color;
}

void UShaderParser::Blend_dst_factor_colorContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterBlend_dst_factor_color(this);
}

void UShaderParser::Blend_dst_factor_colorContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitBlend_dst_factor_color(this);
}


antlrcpp::Any UShaderParser::Blend_dst_factor_colorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitBlend_dst_factor_color(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Blend_dst_factor_colorContext* UShaderParser::blend_dst_factor_color() {
  Blend_dst_factor_colorContext *_localctx = _tracker.createInstance<Blend_dst_factor_colorContext>(_ctx, getState());
  enterRule(_localctx, 152, UShaderParser::RuleBlend_dst_factor_color);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(757);
    blend_factor();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Blend_src_factor_alphaContext ------------------------------------------------------------------

UShaderParser::Blend_src_factor_alphaContext::Blend_src_factor_alphaContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Blend_src_factor_alphaContext::BlendFactorAlpha() {
  return getToken(UShaderParser::BlendFactorAlpha, 0);
}


size_t UShaderParser::Blend_src_factor_alphaContext::getRuleIndex() const {
  return UShaderParser::RuleBlend_src_factor_alpha;
}

void UShaderParser::Blend_src_factor_alphaContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterBlend_src_factor_alpha(this);
}

void UShaderParser::Blend_src_factor_alphaContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitBlend_src_factor_alpha(this);
}


antlrcpp::Any UShaderParser::Blend_src_factor_alphaContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitBlend_src_factor_alpha(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Blend_src_factor_alphaContext* UShaderParser::blend_src_factor_alpha() {
  Blend_src_factor_alphaContext *_localctx = _tracker.createInstance<Blend_src_factor_alphaContext>(_ctx, getState());
  enterRule(_localctx, 154, UShaderParser::RuleBlend_src_factor_alpha);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(759);
    match(UShaderParser::BlendFactorAlpha);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Blend_dst_factor_alphaContext ------------------------------------------------------------------

UShaderParser::Blend_dst_factor_alphaContext::Blend_dst_factor_alphaContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Blend_dst_factor_alphaContext::BlendFactorAlpha() {
  return getToken(UShaderParser::BlendFactorAlpha, 0);
}


size_t UShaderParser::Blend_dst_factor_alphaContext::getRuleIndex() const {
  return UShaderParser::RuleBlend_dst_factor_alpha;
}

void UShaderParser::Blend_dst_factor_alphaContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterBlend_dst_factor_alpha(this);
}

void UShaderParser::Blend_dst_factor_alphaContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitBlend_dst_factor_alpha(this);
}


antlrcpp::Any UShaderParser::Blend_dst_factor_alphaContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitBlend_dst_factor_alpha(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Blend_dst_factor_alphaContext* UShaderParser::blend_dst_factor_alpha() {
  Blend_dst_factor_alphaContext *_localctx = _tracker.createInstance<Blend_dst_factor_alphaContext>(_ctx, getState());
  enterRule(_localctx, 156, UShaderParser::RuleBlend_dst_factor_alpha);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(761);
    match(UShaderParser::BlendFactorAlpha);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Blend_factorContext ------------------------------------------------------------------

UShaderParser::Blend_factorContext::Blend_factorContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Blend_factorContext::BlendFactorAlpha() {
  return getToken(UShaderParser::BlendFactorAlpha, 0);
}


size_t UShaderParser::Blend_factorContext::getRuleIndex() const {
  return UShaderParser::RuleBlend_factor;
}

void UShaderParser::Blend_factorContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterBlend_factor(this);
}

void UShaderParser::Blend_factorContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitBlend_factor(this);
}


antlrcpp::Any UShaderParser::Blend_factorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitBlend_factor(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Blend_factorContext* UShaderParser::blend_factor() {
  Blend_factorContext *_localctx = _tracker.createInstance<Blend_factorContext>(_ctx, getState());
  enterRule(_localctx, 158, UShaderParser::RuleBlend_factor);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(763);
    _la = _input->LA(1);
    if (!(((((_la - 47) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 47)) & ((1ULL << (UShaderParser::T__46 - 47))
      | (1ULL << (UShaderParser::T__47 - 47))
      | (1ULL << (UShaderParser::T__48 - 47))
      | (1ULL << (UShaderParser::T__49 - 47))
      | (1ULL << (UShaderParser::BlendFactorAlpha - 47)))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Blend_opContext ------------------------------------------------------------------

UShaderParser::Blend_opContext::Blend_opContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Blend_op_colorContext* UShaderParser::Blend_opContext::blend_op_color() {
  return getRuleContext<UShaderParser::Blend_op_colorContext>(0);
}

UShaderParser::IndexContext* UShaderParser::Blend_opContext::index() {
  return getRuleContext<UShaderParser::IndexContext>(0);
}

UShaderParser::Blend_op_alphaContext* UShaderParser::Blend_opContext::blend_op_alpha() {
  return getRuleContext<UShaderParser::Blend_op_alphaContext>(0);
}


size_t UShaderParser::Blend_opContext::getRuleIndex() const {
  return UShaderParser::RuleBlend_op;
}

void UShaderParser::Blend_opContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterBlend_op(this);
}

void UShaderParser::Blend_opContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitBlend_op(this);
}


antlrcpp::Any UShaderParser::Blend_opContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitBlend_op(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Blend_opContext* UShaderParser::blend_op() {
  Blend_opContext *_localctx = _tracker.createInstance<Blend_opContext>(_ctx, getState());
  enterRule(_localctx, 160, UShaderParser::RuleBlend_op);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(786);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 25, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(765);
      match(UShaderParser::T__50);
      setState(770);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == UShaderParser::T__37) {
        setState(766);
        match(UShaderParser::T__37);
        setState(767);
        index();
        setState(768);
        match(UShaderParser::T__38);
      }
      setState(772);
      blend_op_color();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(773);
      match(UShaderParser::T__50);
      setState(778);
      _errHandler->sync(this);

      _la = _input->LA(1);
      if (_la == UShaderParser::T__37) {
        setState(774);
        match(UShaderParser::T__37);
        setState(775);
        index();
        setState(776);
        match(UShaderParser::T__38);
      }
      setState(780);
      match(UShaderParser::T__6);
      setState(781);
      blend_op_color();
      setState(782);
      match(UShaderParser::T__7);
      setState(783);
      blend_op_alpha();
      setState(784);
      match(UShaderParser::T__9);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Blend_op_colorContext ------------------------------------------------------------------

UShaderParser::Blend_op_colorContext::Blend_op_colorContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Blend_op_colorContext::BlendOpEnum() {
  return getToken(UShaderParser::BlendOpEnum, 0);
}


size_t UShaderParser::Blend_op_colorContext::getRuleIndex() const {
  return UShaderParser::RuleBlend_op_color;
}

void UShaderParser::Blend_op_colorContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterBlend_op_color(this);
}

void UShaderParser::Blend_op_colorContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitBlend_op_color(this);
}


antlrcpp::Any UShaderParser::Blend_op_colorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitBlend_op_color(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Blend_op_colorContext* UShaderParser::blend_op_color() {
  Blend_op_colorContext *_localctx = _tracker.createInstance<Blend_op_colorContext>(_ctx, getState());
  enterRule(_localctx, 162, UShaderParser::RuleBlend_op_color);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(788);
    match(UShaderParser::BlendOpEnum);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Blend_op_alphaContext ------------------------------------------------------------------

UShaderParser::Blend_op_alphaContext::Blend_op_alphaContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Blend_op_alphaContext::BlendOpEnum() {
  return getToken(UShaderParser::BlendOpEnum, 0);
}


size_t UShaderParser::Blend_op_alphaContext::getRuleIndex() const {
  return UShaderParser::RuleBlend_op_alpha;
}

void UShaderParser::Blend_op_alphaContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterBlend_op_alpha(this);
}

void UShaderParser::Blend_op_alphaContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitBlend_op_alpha(this);
}


antlrcpp::Any UShaderParser::Blend_op_alphaContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitBlend_op_alpha(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Blend_op_alphaContext* UShaderParser::blend_op_alpha() {
  Blend_op_alphaContext *_localctx = _tracker.createInstance<Blend_op_alphaContext>(_ctx, getState());
  enterRule(_localctx, 164, UShaderParser::RuleBlend_op_alpha);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(790);
    match(UShaderParser::BlendOpEnum);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Color_maskContext ------------------------------------------------------------------

UShaderParser::Color_maskContext::Color_maskContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Color_mask_valueContext* UShaderParser::Color_maskContext::color_mask_value() {
  return getRuleContext<UShaderParser::Color_mask_valueContext>(0);
}

UShaderParser::IndexContext* UShaderParser::Color_maskContext::index() {
  return getRuleContext<UShaderParser::IndexContext>(0);
}


size_t UShaderParser::Color_maskContext::getRuleIndex() const {
  return UShaderParser::RuleColor_mask;
}

void UShaderParser::Color_maskContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterColor_mask(this);
}

void UShaderParser::Color_maskContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitColor_mask(this);
}


antlrcpp::Any UShaderParser::Color_maskContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitColor_mask(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Color_maskContext* UShaderParser::color_mask() {
  Color_maskContext *_localctx = _tracker.createInstance<Color_maskContext>(_ctx, getState());
  enterRule(_localctx, 166, UShaderParser::RuleColor_mask);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(792);
    match(UShaderParser::T__51);
    setState(797);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == UShaderParser::T__37) {
      setState(793);
      match(UShaderParser::T__37);
      setState(794);
      index();
      setState(795);
      match(UShaderParser::T__38);
    }
    setState(799);
    color_mask_value();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Color_mask_valueContext ------------------------------------------------------------------

UShaderParser::Color_mask_valueContext::Color_mask_valueContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Color_mask_valueContext::IntegerLiteral() {
  return getToken(UShaderParser::IntegerLiteral, 0);
}

tree::TerminalNode* UShaderParser::Color_mask_valueContext::ColorMask_RGBA() {
  return getToken(UShaderParser::ColorMask_RGBA, 0);
}


size_t UShaderParser::Color_mask_valueContext::getRuleIndex() const {
  return UShaderParser::RuleColor_mask_value;
}

void UShaderParser::Color_mask_valueContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterColor_mask_value(this);
}

void UShaderParser::Color_mask_valueContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitColor_mask_value(this);
}


antlrcpp::Any UShaderParser::Color_mask_valueContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitColor_mask_value(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Color_mask_valueContext* UShaderParser::color_mask_value() {
  Color_mask_valueContext *_localctx = _tracker.createInstance<Color_mask_valueContext>(_ctx, getState());
  enterRule(_localctx, 168, UShaderParser::RuleColor_mask_value);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(801);
    _la = _input->LA(1);
    if (!(_la == UShaderParser::ColorMask_RGBA

    || _la == UShaderParser::IntegerLiteral)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StencilContext ------------------------------------------------------------------

UShaderParser::StencilContext::StencilContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<UShaderParser::Stencil_state_setupContext *> UShaderParser::StencilContext::stencil_state_setup() {
  return getRuleContexts<UShaderParser::Stencil_state_setupContext>();
}

UShaderParser::Stencil_state_setupContext* UShaderParser::StencilContext::stencil_state_setup(size_t i) {
  return getRuleContext<UShaderParser::Stencil_state_setupContext>(i);
}


size_t UShaderParser::StencilContext::getRuleIndex() const {
  return UShaderParser::RuleStencil;
}

void UShaderParser::StencilContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStencil(this);
}

void UShaderParser::StencilContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStencil(this);
}


antlrcpp::Any UShaderParser::StencilContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitStencil(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::StencilContext* UShaderParser::stencil() {
  StencilContext *_localctx = _tracker.createInstance<StencilContext>(_ctx, getState());
  enterRule(_localctx, 170, UShaderParser::RuleStencil);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(803);
    match(UShaderParser::T__52);
    setState(804);
    match(UShaderParser::T__1);
    setState(806); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(805);
      stencil_state_setup();
      setState(808); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << UShaderParser::T__39)
      | (1ULL << UShaderParser::T__53)
      | (1ULL << UShaderParser::T__54)
      | (1ULL << UShaderParser::T__55)
      | (1ULL << UShaderParser::T__56)
      | (1ULL << UShaderParser::T__57)
      | (1ULL << UShaderParser::T__58))) != 0));
    setState(810);
    match(UShaderParser::T__2);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Stencil_state_setupContext ------------------------------------------------------------------

UShaderParser::Stencil_state_setupContext::Stencil_state_setupContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Stencil_refContext* UShaderParser::Stencil_state_setupContext::stencil_ref() {
  return getRuleContext<UShaderParser::Stencil_refContext>(0);
}

UShaderParser::Stencil_mask_readContext* UShaderParser::Stencil_state_setupContext::stencil_mask_read() {
  return getRuleContext<UShaderParser::Stencil_mask_readContext>(0);
}

UShaderParser::Stencil_mask_writeContext* UShaderParser::Stencil_state_setupContext::stencil_mask_write() {
  return getRuleContext<UShaderParser::Stencil_mask_writeContext>(0);
}

UShaderParser::Stencil_compareContext* UShaderParser::Stencil_state_setupContext::stencil_compare() {
  return getRuleContext<UShaderParser::Stencil_compareContext>(0);
}

UShaderParser::Stencil_passContext* UShaderParser::Stencil_state_setupContext::stencil_pass() {
  return getRuleContext<UShaderParser::Stencil_passContext>(0);
}

UShaderParser::Stencil_failContext* UShaderParser::Stencil_state_setupContext::stencil_fail() {
  return getRuleContext<UShaderParser::Stencil_failContext>(0);
}

UShaderParser::Stencil_zfailContext* UShaderParser::Stencil_state_setupContext::stencil_zfail() {
  return getRuleContext<UShaderParser::Stencil_zfailContext>(0);
}


size_t UShaderParser::Stencil_state_setupContext::getRuleIndex() const {
  return UShaderParser::RuleStencil_state_setup;
}

void UShaderParser::Stencil_state_setupContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStencil_state_setup(this);
}

void UShaderParser::Stencil_state_setupContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStencil_state_setup(this);
}


antlrcpp::Any UShaderParser::Stencil_state_setupContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitStencil_state_setup(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Stencil_state_setupContext* UShaderParser::stencil_state_setup() {
  Stencil_state_setupContext *_localctx = _tracker.createInstance<Stencil_state_setupContext>(_ctx, getState());
  enterRule(_localctx, 172, UShaderParser::RuleStencil_state_setup);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(819);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case UShaderParser::T__53: {
        enterOuterAlt(_localctx, 1);
        setState(812);
        stencil_ref();
        break;
      }

      case UShaderParser::T__54: {
        enterOuterAlt(_localctx, 2);
        setState(813);
        stencil_mask_read();
        break;
      }

      case UShaderParser::T__55: {
        enterOuterAlt(_localctx, 3);
        setState(814);
        stencil_mask_write();
        break;
      }

      case UShaderParser::T__56: {
        enterOuterAlt(_localctx, 4);
        setState(815);
        stencil_compare();
        break;
      }

      case UShaderParser::T__39: {
        enterOuterAlt(_localctx, 5);
        setState(816);
        stencil_pass();
        break;
      }

      case UShaderParser::T__57: {
        enterOuterAlt(_localctx, 6);
        setState(817);
        stencil_fail();
        break;
      }

      case UShaderParser::T__58: {
        enterOuterAlt(_localctx, 7);
        setState(818);
        stencil_zfail();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Stencil_refContext ------------------------------------------------------------------

UShaderParser::Stencil_refContext::Stencil_refContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Stencil_refContext::IntegerLiteral() {
  return getToken(UShaderParser::IntegerLiteral, 0);
}


size_t UShaderParser::Stencil_refContext::getRuleIndex() const {
  return UShaderParser::RuleStencil_ref;
}

void UShaderParser::Stencil_refContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStencil_ref(this);
}

void UShaderParser::Stencil_refContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStencil_ref(this);
}


antlrcpp::Any UShaderParser::Stencil_refContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitStencil_ref(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Stencil_refContext* UShaderParser::stencil_ref() {
  Stencil_refContext *_localctx = _tracker.createInstance<Stencil_refContext>(_ctx, getState());
  enterRule(_localctx, 174, UShaderParser::RuleStencil_ref);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(821);
    match(UShaderParser::T__53);
    setState(822);
    match(UShaderParser::IntegerLiteral);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Stencil_mask_readContext ------------------------------------------------------------------

UShaderParser::Stencil_mask_readContext::Stencil_mask_readContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Stencil_mask_readContext::IntegerLiteral() {
  return getToken(UShaderParser::IntegerLiteral, 0);
}


size_t UShaderParser::Stencil_mask_readContext::getRuleIndex() const {
  return UShaderParser::RuleStencil_mask_read;
}

void UShaderParser::Stencil_mask_readContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStencil_mask_read(this);
}

void UShaderParser::Stencil_mask_readContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStencil_mask_read(this);
}


antlrcpp::Any UShaderParser::Stencil_mask_readContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitStencil_mask_read(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Stencil_mask_readContext* UShaderParser::stencil_mask_read() {
  Stencil_mask_readContext *_localctx = _tracker.createInstance<Stencil_mask_readContext>(_ctx, getState());
  enterRule(_localctx, 176, UShaderParser::RuleStencil_mask_read);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(824);
    match(UShaderParser::T__54);
    setState(825);
    match(UShaderParser::IntegerLiteral);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Stencil_mask_writeContext ------------------------------------------------------------------

UShaderParser::Stencil_mask_writeContext::Stencil_mask_writeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Stencil_mask_writeContext::IntegerLiteral() {
  return getToken(UShaderParser::IntegerLiteral, 0);
}


size_t UShaderParser::Stencil_mask_writeContext::getRuleIndex() const {
  return UShaderParser::RuleStencil_mask_write;
}

void UShaderParser::Stencil_mask_writeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStencil_mask_write(this);
}

void UShaderParser::Stencil_mask_writeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStencil_mask_write(this);
}


antlrcpp::Any UShaderParser::Stencil_mask_writeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitStencil_mask_write(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Stencil_mask_writeContext* UShaderParser::stencil_mask_write() {
  Stencil_mask_writeContext *_localctx = _tracker.createInstance<Stencil_mask_writeContext>(_ctx, getState());
  enterRule(_localctx, 178, UShaderParser::RuleStencil_mask_write);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(827);
    match(UShaderParser::T__55);
    setState(828);
    match(UShaderParser::IntegerLiteral);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Stencil_compareContext ------------------------------------------------------------------

UShaderParser::Stencil_compareContext::Stencil_compareContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* UShaderParser::Stencil_compareContext::Comparator() {
  return getToken(UShaderParser::Comparator, 0);
}


size_t UShaderParser::Stencil_compareContext::getRuleIndex() const {
  return UShaderParser::RuleStencil_compare;
}

void UShaderParser::Stencil_compareContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStencil_compare(this);
}

void UShaderParser::Stencil_compareContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStencil_compare(this);
}


antlrcpp::Any UShaderParser::Stencil_compareContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitStencil_compare(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Stencil_compareContext* UShaderParser::stencil_compare() {
  Stencil_compareContext *_localctx = _tracker.createInstance<Stencil_compareContext>(_ctx, getState());
  enterRule(_localctx, 180, UShaderParser::RuleStencil_compare);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(830);
    match(UShaderParser::T__56);
    setState(831);
    match(UShaderParser::Comparator);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Stencil_passContext ------------------------------------------------------------------

UShaderParser::Stencil_passContext::Stencil_passContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Stencil_opContext* UShaderParser::Stencil_passContext::stencil_op() {
  return getRuleContext<UShaderParser::Stencil_opContext>(0);
}


size_t UShaderParser::Stencil_passContext::getRuleIndex() const {
  return UShaderParser::RuleStencil_pass;
}

void UShaderParser::Stencil_passContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStencil_pass(this);
}

void UShaderParser::Stencil_passContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStencil_pass(this);
}


antlrcpp::Any UShaderParser::Stencil_passContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitStencil_pass(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Stencil_passContext* UShaderParser::stencil_pass() {
  Stencil_passContext *_localctx = _tracker.createInstance<Stencil_passContext>(_ctx, getState());
  enterRule(_localctx, 182, UShaderParser::RuleStencil_pass);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(833);
    match(UShaderParser::T__39);
    setState(834);
    stencil_op();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Stencil_failContext ------------------------------------------------------------------

UShaderParser::Stencil_failContext::Stencil_failContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Stencil_opContext* UShaderParser::Stencil_failContext::stencil_op() {
  return getRuleContext<UShaderParser::Stencil_opContext>(0);
}


size_t UShaderParser::Stencil_failContext::getRuleIndex() const {
  return UShaderParser::RuleStencil_fail;
}

void UShaderParser::Stencil_failContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStencil_fail(this);
}

void UShaderParser::Stencil_failContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStencil_fail(this);
}


antlrcpp::Any UShaderParser::Stencil_failContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitStencil_fail(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Stencil_failContext* UShaderParser::stencil_fail() {
  Stencil_failContext *_localctx = _tracker.createInstance<Stencil_failContext>(_ctx, getState());
  enterRule(_localctx, 184, UShaderParser::RuleStencil_fail);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(836);
    match(UShaderParser::T__57);
    setState(837);
    stencil_op();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Stencil_zfailContext ------------------------------------------------------------------

UShaderParser::Stencil_zfailContext::Stencil_zfailContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Stencil_opContext* UShaderParser::Stencil_zfailContext::stencil_op() {
  return getRuleContext<UShaderParser::Stencil_opContext>(0);
}


size_t UShaderParser::Stencil_zfailContext::getRuleIndex() const {
  return UShaderParser::RuleStencil_zfail;
}

void UShaderParser::Stencil_zfailContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStencil_zfail(this);
}

void UShaderParser::Stencil_zfailContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStencil_zfail(this);
}


antlrcpp::Any UShaderParser::Stencil_zfailContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitStencil_zfail(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Stencil_zfailContext* UShaderParser::stencil_zfail() {
  Stencil_zfailContext *_localctx = _tracker.createInstance<Stencil_zfailContext>(_ctx, getState());
  enterRule(_localctx, 186, UShaderParser::RuleStencil_zfail);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(839);
    match(UShaderParser::T__58);
    setState(840);
    stencil_op();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Stencil_opContext ------------------------------------------------------------------

UShaderParser::Stencil_opContext::Stencil_opContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t UShaderParser::Stencil_opContext::getRuleIndex() const {
  return UShaderParser::RuleStencil_op;
}

void UShaderParser::Stencil_opContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStencil_op(this);
}

void UShaderParser::Stencil_opContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStencil_op(this);
}


antlrcpp::Any UShaderParser::Stencil_opContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitStencil_op(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Stencil_opContext* UShaderParser::stencil_op() {
  Stencil_opContext *_localctx = _tracker.createInstance<Stencil_opContext>(_ctx, getState());
  enterRule(_localctx, 188, UShaderParser::RuleStencil_op);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(842);
    _la = _input->LA(1);
    if (!(((((_la - 60) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 60)) & ((1ULL << (UShaderParser::T__59 - 60))
      | (1ULL << (UShaderParser::T__60 - 60))
      | (1ULL << (UShaderParser::T__61 - 60))
      | (1ULL << (UShaderParser::T__62 - 60))
      | (1ULL << (UShaderParser::T__63 - 60))
      | (1ULL << (UShaderParser::T__64 - 60))
      | (1ULL << (UShaderParser::T__65 - 60))
      | (1ULL << (UShaderParser::T__66 - 60)))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- QueueContext ------------------------------------------------------------------

UShaderParser::QueueContext::QueueContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Val_queueContext* UShaderParser::QueueContext::val_queue() {
  return getRuleContext<UShaderParser::Val_queueContext>(0);
}


size_t UShaderParser::QueueContext::getRuleIndex() const {
  return UShaderParser::RuleQueue;
}

void UShaderParser::QueueContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterQueue(this);
}

void UShaderParser::QueueContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitQueue(this);
}


antlrcpp::Any UShaderParser::QueueContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitQueue(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::QueueContext* UShaderParser::queue() {
  QueueContext *_localctx = _tracker.createInstance<QueueContext>(_ctx, getState());
  enterRule(_localctx, 190, UShaderParser::RuleQueue);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(844);
    match(UShaderParser::T__67);
    setState(845);
    val_queue();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Val_queueContext ------------------------------------------------------------------

UShaderParser::Val_queueContext::Val_queueContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

UShaderParser::Queue_keyContext* UShaderParser::Val_queueContext::queue_key() {
  return getRuleContext<UShaderParser::Queue_keyContext>(0);
}

tree::TerminalNode* UShaderParser::Val_queueContext::IntegerLiteral() {
  return getToken(UShaderParser::IntegerLiteral, 0);
}

tree::TerminalNode* UShaderParser::Val_queueContext::Sign() {
  return getToken(UShaderParser::Sign, 0);
}


size_t UShaderParser::Val_queueContext::getRuleIndex() const {
  return UShaderParser::RuleVal_queue;
}

void UShaderParser::Val_queueContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVal_queue(this);
}

void UShaderParser::Val_queueContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVal_queue(this);
}


antlrcpp::Any UShaderParser::Val_queueContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitVal_queue(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Val_queueContext* UShaderParser::val_queue() {
  Val_queueContext *_localctx = _tracker.createInstance<Val_queueContext>(_ctx, getState());
  enterRule(_localctx, 192, UShaderParser::RuleVal_queue);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(853);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 29, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(847);
      queue_key();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(848);
      match(UShaderParser::IntegerLiteral);
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(849);
      queue_key();
      setState(850);
      match(UShaderParser::Sign);
      setState(851);
      match(UShaderParser::IntegerLiteral);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Queue_keyContext ------------------------------------------------------------------

UShaderParser::Queue_keyContext::Queue_keyContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t UShaderParser::Queue_keyContext::getRuleIndex() const {
  return UShaderParser::RuleQueue_key;
}

void UShaderParser::Queue_keyContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterQueue_key(this);
}

void UShaderParser::Queue_keyContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<UShaderListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitQueue_key(this);
}


antlrcpp::Any UShaderParser::Queue_keyContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<UShaderVisitor*>(visitor))
    return parserVisitor->visitQueue_key(this);
  else
    return visitor->visitChildren(this);
}

UShaderParser::Queue_keyContext* UShaderParser::queue_key() {
  Queue_keyContext *_localctx = _tracker.createInstance<Queue_keyContext>(_ctx, getState());
  enterRule(_localctx, 194, UShaderParser::RuleQueue_key);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(855);
    _la = _input->LA(1);
    if (!(((((_la - 69) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 69)) & ((1ULL << (UShaderParser::T__68 - 69))
      | (1ULL << (UShaderParser::T__69 - 69))
      | (1ULL << (UShaderParser::T__70 - 69))
      | (1ULL << (UShaderParser::T__71 - 69))
      | (1ULL << (UShaderParser::T__72 - 69)))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

// Static vars and initialization.
std::vector<dfa::DFA> UShaderParser::_decisionToDFA;
atn::PredictionContextCache UShaderParser::_sharedContextCache;

// We own the ATN which in turn owns the ATN states.
atn::ATN UShaderParser::_atn;
std::vector<uint16_t> UShaderParser::_serializedATN;

std::vector<std::string> UShaderParser::_ruleNames = {
  "shader", "shader_name", "hlsl", "property_block", "property", "property_bool", 
  "property_int", "property_uint", "property_float", "property_double", 
  "property_bool2", "property_bool3", "property_bool4", "property_int2", 
  "property_int3", "property_int4", "property_uint2", "property_uint3", 
  "property_uint4", "property_float2", "property_float3", "property_float4", 
  "property_double2", "property_double3", "property_double4", "property_2D", 
  "property_cube", "property_rgb", "property_rgba", "val_bool", "val_int", 
  "val_uint", "val_float", "val_double", "val_bool2", "val_bool3", "val_bool4", 
  "val_int2", "val_int3", "val_int4", "val_uint2", "val_uint3", "val_uint4", 
  "val_float2", "val_float3", "val_float4", "val_double2", "val_double3", 
  "val_double4", "val_tex2d", "default_texture_2d", "val_texcube", "default_texture_cube", 
  "property_name", "display_name", "root_signature", "root_parameter", "register_index", 
  "shader_register", "register_space", "register_num", "pass", "vs", "ps", 
  "pass_statement", "tags", "tag", "render_state_setup", "fill", "cull", 
  "ztest", "zwrite_off", "blend", "blend_expr", "index", "blend_src_factor_color", 
  "blend_dst_factor_color", "blend_src_factor_alpha", "blend_dst_factor_alpha", 
  "blend_factor", "blend_op", "blend_op_color", "blend_op_alpha", "color_mask", 
  "color_mask_value", "stencil", "stencil_state_setup", "stencil_ref", "stencil_mask_read", 
  "stencil_mask_write", "stencil_compare", "stencil_pass", "stencil_fail", 
  "stencil_zfail", "stencil_op", "queue", "val_queue", "queue_key"
};

std::vector<std::string> UShaderParser::_literalNames = {
  "", "'Shader'", "'{'", "'}'", "'HLSL'", "':'", "'Properties'", "'('", 
  "','", "'bool'", "')'", "'int'", "'uint'", "'float'", "'double'", "'bool2'", 
  "'bool3'", "'bool4'", "'int2'", "'int3'", "'int4'", "'uint2'", "'uint3'", 
  "'uint4'", "'float2'", "'float3'", "'float4'", "'double2'", "'double3'", 
  "'double4'", "'2D'", "'Cube'", "'Color3'", "'Color4'", "'White'", "'Black'", 
  "'Bump'", "'RootSignature'", "'['", "']'", "'Pass'", "'Tags'", "'Fill'", 
  "'Cull'", "'ZTest'", "'ZWriteOff'", "'Blend'", "'SrcColor'", "'DstColor'", 
  "'OneMinusSrcColor'", "'OneMinusDstColor'", "'BlendOp'", "'ColorMask'", 
  "'Stencil'", "'Ref'", "'ReadMask'", "'WriteMask'", "'Comp'", "'Fail'", 
  "'ZFail'", "'Keep'", "'Zero'", "'Replace'", "'IncrSat'", "'DecrSat'", 
  "'Invert'", "'IncrWrap'", "'DecrWarp'", "'Queue'", "'Background'", "'Geometry'", 
  "'AlphaTest'", "'Transparent'", "'Overlay'"
};

std::vector<std::string> UShaderParser::_symbolicNames = {
  "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", 
  "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", 
  "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", 
  "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", 
  "", "", "BlendFactorAlpha", "BlendOpEnum", "StringLiteral", "Comparator", 
  "BooleanLiteral", "FillMode", "CullMode", "RootDescriptorType", "ColorMask_RGBA", 
  "IntegerLiteral", "FloatingLiteral", "ExponentPart", "DecimalLiteral", 
  "OctalLiteral", "HexadecimalLiteral", "BinaryLiteral", "Sign", "ID", "Whitespace", 
  "Newline", "BlockComment", "LineComment"
};

dfa::Vocabulary UShaderParser::_vocabulary(_literalNames, _symbolicNames);

std::vector<std::string> UShaderParser::_tokenNames;

UShaderParser::Initializer::Initializer() {
	for (size_t i = 0; i < _symbolicNames.size(); ++i) {
		std::string name = _vocabulary.getLiteralName(i);
		if (name.empty()) {
			name = _vocabulary.getSymbolicName(i);
		}

		if (name.empty()) {
			_tokenNames.push_back("<INVALID>");
		} else {
      _tokenNames.push_back(name);
    }
	}

  _serializedATN = {
    0x3, 0x608b, 0xa72a, 0x8133, 0xb9ed, 0x417c, 0x3be7, 0x7786, 0x5964, 
    0x3, 0x61, 0x35c, 0x4, 0x2, 0x9, 0x2, 0x4, 0x3, 0x9, 0x3, 0x4, 0x4, 
    0x9, 0x4, 0x4, 0x5, 0x9, 0x5, 0x4, 0x6, 0x9, 0x6, 0x4, 0x7, 0x9, 0x7, 
    0x4, 0x8, 0x9, 0x8, 0x4, 0x9, 0x9, 0x9, 0x4, 0xa, 0x9, 0xa, 0x4, 0xb, 
    0x9, 0xb, 0x4, 0xc, 0x9, 0xc, 0x4, 0xd, 0x9, 0xd, 0x4, 0xe, 0x9, 0xe, 
    0x4, 0xf, 0x9, 0xf, 0x4, 0x10, 0x9, 0x10, 0x4, 0x11, 0x9, 0x11, 0x4, 
    0x12, 0x9, 0x12, 0x4, 0x13, 0x9, 0x13, 0x4, 0x14, 0x9, 0x14, 0x4, 0x15, 
    0x9, 0x15, 0x4, 0x16, 0x9, 0x16, 0x4, 0x17, 0x9, 0x17, 0x4, 0x18, 0x9, 
    0x18, 0x4, 0x19, 0x9, 0x19, 0x4, 0x1a, 0x9, 0x1a, 0x4, 0x1b, 0x9, 0x1b, 
    0x4, 0x1c, 0x9, 0x1c, 0x4, 0x1d, 0x9, 0x1d, 0x4, 0x1e, 0x9, 0x1e, 0x4, 
    0x1f, 0x9, 0x1f, 0x4, 0x20, 0x9, 0x20, 0x4, 0x21, 0x9, 0x21, 0x4, 0x22, 
    0x9, 0x22, 0x4, 0x23, 0x9, 0x23, 0x4, 0x24, 0x9, 0x24, 0x4, 0x25, 0x9, 
    0x25, 0x4, 0x26, 0x9, 0x26, 0x4, 0x27, 0x9, 0x27, 0x4, 0x28, 0x9, 0x28, 
    0x4, 0x29, 0x9, 0x29, 0x4, 0x2a, 0x9, 0x2a, 0x4, 0x2b, 0x9, 0x2b, 0x4, 
    0x2c, 0x9, 0x2c, 0x4, 0x2d, 0x9, 0x2d, 0x4, 0x2e, 0x9, 0x2e, 0x4, 0x2f, 
    0x9, 0x2f, 0x4, 0x30, 0x9, 0x30, 0x4, 0x31, 0x9, 0x31, 0x4, 0x32, 0x9, 
    0x32, 0x4, 0x33, 0x9, 0x33, 0x4, 0x34, 0x9, 0x34, 0x4, 0x35, 0x9, 0x35, 
    0x4, 0x36, 0x9, 0x36, 0x4, 0x37, 0x9, 0x37, 0x4, 0x38, 0x9, 0x38, 0x4, 
    0x39, 0x9, 0x39, 0x4, 0x3a, 0x9, 0x3a, 0x4, 0x3b, 0x9, 0x3b, 0x4, 0x3c, 
    0x9, 0x3c, 0x4, 0x3d, 0x9, 0x3d, 0x4, 0x3e, 0x9, 0x3e, 0x4, 0x3f, 0x9, 
    0x3f, 0x4, 0x40, 0x9, 0x40, 0x4, 0x41, 0x9, 0x41, 0x4, 0x42, 0x9, 0x42, 
    0x4, 0x43, 0x9, 0x43, 0x4, 0x44, 0x9, 0x44, 0x4, 0x45, 0x9, 0x45, 0x4, 
    0x46, 0x9, 0x46, 0x4, 0x47, 0x9, 0x47, 0x4, 0x48, 0x9, 0x48, 0x4, 0x49, 
    0x9, 0x49, 0x4, 0x4a, 0x9, 0x4a, 0x4, 0x4b, 0x9, 0x4b, 0x4, 0x4c, 0x9, 
    0x4c, 0x4, 0x4d, 0x9, 0x4d, 0x4, 0x4e, 0x9, 0x4e, 0x4, 0x4f, 0x9, 0x4f, 
    0x4, 0x50, 0x9, 0x50, 0x4, 0x51, 0x9, 0x51, 0x4, 0x52, 0x9, 0x52, 0x4, 
    0x53, 0x9, 0x53, 0x4, 0x54, 0x9, 0x54, 0x4, 0x55, 0x9, 0x55, 0x4, 0x56, 
    0x9, 0x56, 0x4, 0x57, 0x9, 0x57, 0x4, 0x58, 0x9, 0x58, 0x4, 0x59, 0x9, 
    0x59, 0x4, 0x5a, 0x9, 0x5a, 0x4, 0x5b, 0x9, 0x5b, 0x4, 0x5c, 0x9, 0x5c, 
    0x4, 0x5d, 0x9, 0x5d, 0x4, 0x5e, 0x9, 0x5e, 0x4, 0x5f, 0x9, 0x5f, 0x4, 
    0x60, 0x9, 0x60, 0x4, 0x61, 0x9, 0x61, 0x4, 0x62, 0x9, 0x62, 0x4, 0x63, 
    0x9, 0x63, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 
    0x5, 0x2, 0xcd, 0xa, 0x2, 0x3, 0x2, 0x6, 0x2, 0xd0, 0xa, 0x2, 0xd, 0x2, 
    0xe, 0x2, 0xd1, 0x3, 0x2, 0x3, 0x2, 0x3, 0x3, 0x3, 0x3, 0x3, 0x4, 0x3, 
    0x4, 0x3, 0x4, 0x3, 0x4, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x6, 0x5, 0xdf, 
    0xa, 0x5, 0xd, 0x5, 0xe, 0x5, 0xe0, 0x3, 0x5, 0x3, 0x5, 0x3, 0x6, 0x3, 
    0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 
    0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 
    0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 0x6, 0x3, 
    0x6, 0x3, 0x6, 0x5, 0x6, 0xfd, 0xa, 0x6, 0x3, 0x7, 0x3, 0x7, 0x3, 0x7, 
    0x3, 0x7, 0x3, 0x7, 0x3, 0x7, 0x3, 0x7, 0x3, 0x7, 0x3, 0x7, 0x3, 0x8, 
    0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 
    0x3, 0x8, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 
    0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 
    0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xb, 0x3, 0xb, 
    0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 
    0x3, 0xc, 0x3, 0xc, 0x3, 0xc, 0x3, 0xc, 0x3, 0xc, 0x3, 0xc, 0x3, 0xc, 
    0x3, 0xc, 0x3, 0xc, 0x3, 0xd, 0x3, 0xd, 0x3, 0xd, 0x3, 0xd, 0x3, 0xd, 
    0x3, 0xd, 0x3, 0xd, 0x3, 0xd, 0x3, 0xd, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 
    0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xf, 
    0x3, 0xf, 0x3, 0xf, 0x3, 0xf, 0x3, 0xf, 0x3, 0xf, 0x3, 0xf, 0x3, 0xf, 
    0x3, 0xf, 0x3, 0x10, 0x3, 0x10, 0x3, 0x10, 0x3, 0x10, 0x3, 0x10, 0x3, 
    0x10, 0x3, 0x10, 0x3, 0x10, 0x3, 0x10, 0x3, 0x11, 0x3, 0x11, 0x3, 0x11, 
    0x3, 0x11, 0x3, 0x11, 0x3, 0x11, 0x3, 0x11, 0x3, 0x11, 0x3, 0x11, 0x3, 
    0x12, 0x3, 0x12, 0x3, 0x12, 0x3, 0x12, 0x3, 0x12, 0x3, 0x12, 0x3, 0x12, 
    0x3, 0x12, 0x3, 0x12, 0x3, 0x13, 0x3, 0x13, 0x3, 0x13, 0x3, 0x13, 0x3, 
    0x13, 0x3, 0x13, 0x3, 0x13, 0x3, 0x13, 0x3, 0x13, 0x3, 0x14, 0x3, 0x14, 
    0x3, 0x14, 0x3, 0x14, 0x3, 0x14, 0x3, 0x14, 0x3, 0x14, 0x3, 0x14, 0x3, 
    0x14, 0x3, 0x15, 0x3, 0x15, 0x3, 0x15, 0x3, 0x15, 0x3, 0x15, 0x3, 0x15, 
    0x3, 0x15, 0x3, 0x15, 0x3, 0x15, 0x3, 0x16, 0x3, 0x16, 0x3, 0x16, 0x3, 
    0x16, 0x3, 0x16, 0x3, 0x16, 0x3, 0x16, 0x3, 0x16, 0x3, 0x16, 0x3, 0x17, 
    0x3, 0x17, 0x3, 0x17, 0x3, 0x17, 0x3, 0x17, 0x3, 0x17, 0x3, 0x17, 0x3, 
    0x17, 0x3, 0x17, 0x3, 0x18, 0x3, 0x18, 0x3, 0x18, 0x3, 0x18, 0x3, 0x18, 
    0x3, 0x18, 0x3, 0x18, 0x3, 0x18, 0x3, 0x18, 0x3, 0x19, 0x3, 0x19, 0x3, 
    0x19, 0x3, 0x19, 0x3, 0x19, 0x3, 0x19, 0x3, 0x19, 0x3, 0x19, 0x3, 0x19, 
    0x3, 0x1a, 0x3, 0x1a, 0x3, 0x1a, 0x3, 0x1a, 0x3, 0x1a, 0x3, 0x1a, 0x3, 
    0x1a, 0x3, 0x1a, 0x3, 0x1a, 0x3, 0x1b, 0x3, 0x1b, 0x3, 0x1b, 0x3, 0x1b, 
    0x3, 0x1b, 0x3, 0x1b, 0x3, 0x1b, 0x3, 0x1b, 0x3, 0x1b, 0x3, 0x1c, 0x3, 
    0x1c, 0x3, 0x1c, 0x3, 0x1c, 0x3, 0x1c, 0x3, 0x1c, 0x3, 0x1c, 0x3, 0x1c, 
    0x3, 0x1c, 0x3, 0x1d, 0x3, 0x1d, 0x3, 0x1d, 0x3, 0x1d, 0x3, 0x1d, 0x3, 
    0x1d, 0x3, 0x1d, 0x3, 0x1d, 0x3, 0x1d, 0x3, 0x1e, 0x3, 0x1e, 0x3, 0x1e, 
    0x3, 0x1e, 0x3, 0x1e, 0x3, 0x1e, 0x3, 0x1e, 0x3, 0x1e, 0x3, 0x1e, 0x3, 
    0x1f, 0x3, 0x1f, 0x3, 0x20, 0x5, 0x20, 0x1da, 0xa, 0x20, 0x3, 0x20, 
    0x3, 0x20, 0x3, 0x21, 0x3, 0x21, 0x3, 0x22, 0x5, 0x22, 0x1e1, 0xa, 0x22, 
    0x3, 0x22, 0x3, 0x22, 0x5, 0x22, 0x1e5, 0xa, 0x22, 0x3, 0x22, 0x5, 0x22, 
    0x1e8, 0xa, 0x22, 0x3, 0x23, 0x5, 0x23, 0x1eb, 0xa, 0x23, 0x3, 0x23, 
    0x3, 0x23, 0x5, 0x23, 0x1ef, 0xa, 0x23, 0x3, 0x23, 0x5, 0x23, 0x1f2, 
    0xa, 0x23, 0x3, 0x24, 0x3, 0x24, 0x3, 0x24, 0x3, 0x24, 0x3, 0x24, 0x3, 
    0x24, 0x3, 0x25, 0x3, 0x25, 0x3, 0x25, 0x3, 0x25, 0x3, 0x25, 0x3, 0x25, 
    0x3, 0x25, 0x3, 0x25, 0x3, 0x26, 0x3, 0x26, 0x3, 0x26, 0x3, 0x26, 0x3, 
    0x26, 0x3, 0x26, 0x3, 0x26, 0x3, 0x26, 0x3, 0x26, 0x3, 0x26, 0x3, 0x27, 
    0x3, 0x27, 0x3, 0x27, 0x3, 0x27, 0x3, 0x27, 0x3, 0x27, 0x3, 0x28, 0x3, 
    0x28, 0x3, 0x28, 0x3, 0x28, 0x3, 0x28, 0x3, 0x28, 0x3, 0x28, 0x3, 0x28, 
    0x3, 0x29, 0x3, 0x29, 0x3, 0x29, 0x3, 0x29, 0x3, 0x29, 0x3, 0x29, 0x3, 
    0x29, 0x3, 0x29, 0x3, 0x29, 0x3, 0x29, 0x3, 0x2a, 0x3, 0x2a, 0x3, 0x2a, 
    0x3, 0x2a, 0x3, 0x2a, 0x3, 0x2a, 0x3, 0x2b, 0x3, 0x2b, 0x3, 0x2b, 0x3, 
    0x2b, 0x3, 0x2b, 0x3, 0x2b, 0x3, 0x2b, 0x3, 0x2b, 0x3, 0x2c, 0x3, 0x2c, 
    0x3, 0x2c, 0x3, 0x2c, 0x3, 0x2c, 0x3, 0x2c, 0x3, 0x2c, 0x3, 0x2c, 0x3, 
    0x2c, 0x3, 0x2c, 0x3, 0x2d, 0x3, 0x2d, 0x3, 0x2d, 0x3, 0x2d, 0x3, 0x2d, 
    0x3, 0x2d, 0x3, 0x2e, 0x3, 0x2e, 0x3, 0x2e, 0x3, 0x2e, 0x3, 0x2e, 0x3, 
    0x2e, 0x3, 0x2e, 0x3, 0x2e, 0x3, 0x2f, 0x3, 0x2f, 0x3, 0x2f, 0x3, 0x2f, 
    0x3, 0x2f, 0x3, 0x2f, 0x3, 0x2f, 0x3, 0x2f, 0x3, 0x2f, 0x3, 0x2f, 0x3, 
    0x30, 0x3, 0x30, 0x3, 0x30, 0x3, 0x30, 0x3, 0x30, 0x3, 0x30, 0x3, 0x31, 
    0x3, 0x31, 0x3, 0x31, 0x3, 0x31, 0x3, 0x31, 0x3, 0x31, 0x3, 0x31, 0x3, 
    0x31, 0x3, 0x32, 0x3, 0x32, 0x3, 0x32, 0x3, 0x32, 0x3, 0x32, 0x3, 0x32, 
    0x3, 0x32, 0x3, 0x32, 0x3, 0x32, 0x3, 0x32, 0x3, 0x33, 0x3, 0x33, 0x5, 
    0x33, 0x26e, 0xa, 0x33, 0x3, 0x34, 0x3, 0x34, 0x3, 0x35, 0x3, 0x35, 
    0x5, 0x35, 0x274, 0xa, 0x35, 0x3, 0x36, 0x3, 0x36, 0x3, 0x37, 0x3, 0x37, 
    0x3, 0x38, 0x3, 0x38, 0x3, 0x39, 0x3, 0x39, 0x3, 0x39, 0x6, 0x39, 0x27f, 
    0xa, 0x39, 0xd, 0x39, 0xe, 0x39, 0x280, 0x3, 0x39, 0x3, 0x39, 0x3, 0x3a, 
    0x3, 0x3a, 0x3, 0x3a, 0x3, 0x3a, 0x3, 0x3a, 0x5, 0x3a, 0x28a, 0xa, 0x3a, 
    0x3, 0x3a, 0x3, 0x3a, 0x3, 0x3a, 0x3, 0x3b, 0x3, 0x3b, 0x3, 0x3b, 0x3, 
    0x3b, 0x3, 0x3b, 0x3, 0x3b, 0x3, 0x3b, 0x5, 0x3b, 0x296, 0xa, 0x3b, 
    0x3, 0x3c, 0x3, 0x3c, 0x3, 0x3d, 0x3, 0x3d, 0x3, 0x3e, 0x3, 0x3e, 0x3, 
    0x3f, 0x3, 0x3f, 0x3, 0x3f, 0x3, 0x3f, 0x3, 0x3f, 0x3, 0x3f, 0x3, 0x3f, 
    0x3, 0x3f, 0x7, 0x3f, 0x2a6, 0xa, 0x3f, 0xc, 0x3f, 0xe, 0x3f, 0x2a9, 
    0xb, 0x3f, 0x3, 0x3f, 0x3, 0x3f, 0x3, 0x40, 0x3, 0x40, 0x3, 0x41, 0x3, 
    0x41, 0x3, 0x42, 0x3, 0x42, 0x3, 0x42, 0x5, 0x42, 0x2b4, 0xa, 0x42, 
    0x3, 0x43, 0x3, 0x43, 0x3, 0x43, 0x6, 0x43, 0x2b9, 0xa, 0x43, 0xd, 0x43, 
    0xe, 0x43, 0x2ba, 0x3, 0x43, 0x3, 0x43, 0x3, 0x44, 0x3, 0x44, 0x3, 0x44, 
    0x3, 0x44, 0x3, 0x45, 0x3, 0x45, 0x3, 0x45, 0x3, 0x45, 0x3, 0x45, 0x3, 
    0x45, 0x3, 0x45, 0x3, 0x45, 0x5, 0x45, 0x2cb, 0xa, 0x45, 0x3, 0x46, 
    0x3, 0x46, 0x3, 0x46, 0x3, 0x47, 0x3, 0x47, 0x3, 0x47, 0x3, 0x48, 0x3, 
    0x48, 0x3, 0x48, 0x3, 0x49, 0x3, 0x49, 0x3, 0x4a, 0x3, 0x4a, 0x3, 0x4a, 
    0x3, 0x4a, 0x3, 0x4a, 0x5, 0x4a, 0x2dd, 0xa, 0x4a, 0x3, 0x4a, 0x5, 0x4a, 
    0x2e0, 0xa, 0x4a, 0x3, 0x4b, 0x3, 0x4b, 0x3, 0x4b, 0x3, 0x4b, 0x3, 0x4b, 
    0x3, 0x4b, 0x3, 0x4b, 0x3, 0x4b, 0x3, 0x4b, 0x3, 0x4b, 0x3, 0x4b, 0x3, 
    0x4b, 0x3, 0x4b, 0x3, 0x4b, 0x3, 0x4b, 0x3, 0x4b, 0x5, 0x4b, 0x2f2, 
    0xa, 0x4b, 0x3, 0x4c, 0x3, 0x4c, 0x3, 0x4d, 0x3, 0x4d, 0x3, 0x4e, 0x3, 
    0x4e, 0x3, 0x4f, 0x3, 0x4f, 0x3, 0x50, 0x3, 0x50, 0x3, 0x51, 0x3, 0x51, 
    0x3, 0x52, 0x3, 0x52, 0x3, 0x52, 0x3, 0x52, 0x3, 0x52, 0x5, 0x52, 0x305, 
    0xa, 0x52, 0x3, 0x52, 0x3, 0x52, 0x3, 0x52, 0x3, 0x52, 0x3, 0x52, 0x3, 
    0x52, 0x5, 0x52, 0x30d, 0xa, 0x52, 0x3, 0x52, 0x3, 0x52, 0x3, 0x52, 
    0x3, 0x52, 0x3, 0x52, 0x3, 0x52, 0x5, 0x52, 0x315, 0xa, 0x52, 0x3, 0x53, 
    0x3, 0x53, 0x3, 0x54, 0x3, 0x54, 0x3, 0x55, 0x3, 0x55, 0x3, 0x55, 0x3, 
    0x55, 0x3, 0x55, 0x5, 0x55, 0x320, 0xa, 0x55, 0x3, 0x55, 0x3, 0x55, 
    0x3, 0x56, 0x3, 0x56, 0x3, 0x57, 0x3, 0x57, 0x3, 0x57, 0x6, 0x57, 0x329, 
    0xa, 0x57, 0xd, 0x57, 0xe, 0x57, 0x32a, 0x3, 0x57, 0x3, 0x57, 0x3, 0x58, 
    0x3, 0x58, 0x3, 0x58, 0x3, 0x58, 0x3, 0x58, 0x3, 0x58, 0x3, 0x58, 0x5, 
    0x58, 0x336, 0xa, 0x58, 0x3, 0x59, 0x3, 0x59, 0x3, 0x59, 0x3, 0x5a, 
    0x3, 0x5a, 0x3, 0x5a, 0x3, 0x5b, 0x3, 0x5b, 0x3, 0x5b, 0x3, 0x5c, 0x3, 
    0x5c, 0x3, 0x5c, 0x3, 0x5d, 0x3, 0x5d, 0x3, 0x5d, 0x3, 0x5e, 0x3, 0x5e, 
    0x3, 0x5e, 0x3, 0x5f, 0x3, 0x5f, 0x3, 0x5f, 0x3, 0x60, 0x3, 0x60, 0x3, 
    0x61, 0x3, 0x61, 0x3, 0x61, 0x3, 0x62, 0x3, 0x62, 0x3, 0x62, 0x3, 0x62, 
    0x3, 0x62, 0x3, 0x62, 0x5, 0x62, 0x358, 0xa, 0x62, 0x3, 0x63, 0x3, 0x63, 
    0x3, 0x63, 0x2, 0x2, 0x64, 0x2, 0x4, 0x6, 0x8, 0xa, 0xc, 0xe, 0x10, 
    0x12, 0x14, 0x16, 0x18, 0x1a, 0x1c, 0x1e, 0x20, 0x22, 0x24, 0x26, 0x28, 
    0x2a, 0x2c, 0x2e, 0x30, 0x32, 0x34, 0x36, 0x38, 0x3a, 0x3c, 0x3e, 0x40, 
    0x42, 0x44, 0x46, 0x48, 0x4a, 0x4c, 0x4e, 0x50, 0x52, 0x54, 0x56, 0x58, 
    0x5a, 0x5c, 0x5e, 0x60, 0x62, 0x64, 0x66, 0x68, 0x6a, 0x6c, 0x6e, 0x70, 
    0x72, 0x74, 0x76, 0x78, 0x7a, 0x7c, 0x7e, 0x80, 0x82, 0x84, 0x86, 0x88, 
    0x8a, 0x8c, 0x8e, 0x90, 0x92, 0x94, 0x96, 0x98, 0x9a, 0x9c, 0x9e, 0xa0, 
    0xa2, 0xa4, 0xa6, 0xa8, 0xaa, 0xac, 0xae, 0xb0, 0xb2, 0xb4, 0xb6, 0xb8, 
    0xba, 0xbc, 0xbe, 0xc0, 0xc2, 0xc4, 0x2, 0x8, 0x3, 0x2, 0x24, 0x26, 
    0x3, 0x2, 0x24, 0x25, 0x4, 0x2, 0x31, 0x34, 0x4c, 0x4c, 0x3, 0x2, 0x54, 
    0x55, 0x3, 0x2, 0x3e, 0x45, 0x3, 0x2, 0x47, 0x4b, 0x2, 0x33a, 0x2, 0xc6, 
    0x3, 0x2, 0x2, 0x2, 0x4, 0xd5, 0x3, 0x2, 0x2, 0x2, 0x6, 0xd7, 0x3, 0x2, 
    0x2, 0x2, 0x8, 0xdb, 0x3, 0x2, 0x2, 0x2, 0xa, 0xfc, 0x3, 0x2, 0x2, 0x2, 
    0xc, 0xfe, 0x3, 0x2, 0x2, 0x2, 0xe, 0x107, 0x3, 0x2, 0x2, 0x2, 0x10, 
    0x110, 0x3, 0x2, 0x2, 0x2, 0x12, 0x119, 0x3, 0x2, 0x2, 0x2, 0x14, 0x122, 
    0x3, 0x2, 0x2, 0x2, 0x16, 0x12b, 0x3, 0x2, 0x2, 0x2, 0x18, 0x134, 0x3, 
    0x2, 0x2, 0x2, 0x1a, 0x13d, 0x3, 0x2, 0x2, 0x2, 0x1c, 0x146, 0x3, 0x2, 
    0x2, 0x2, 0x1e, 0x14f, 0x3, 0x2, 0x2, 0x2, 0x20, 0x158, 0x3, 0x2, 0x2, 
    0x2, 0x22, 0x161, 0x3, 0x2, 0x2, 0x2, 0x24, 0x16a, 0x3, 0x2, 0x2, 0x2, 
    0x26, 0x173, 0x3, 0x2, 0x2, 0x2, 0x28, 0x17c, 0x3, 0x2, 0x2, 0x2, 0x2a, 
    0x185, 0x3, 0x2, 0x2, 0x2, 0x2c, 0x18e, 0x3, 0x2, 0x2, 0x2, 0x2e, 0x197, 
    0x3, 0x2, 0x2, 0x2, 0x30, 0x1a0, 0x3, 0x2, 0x2, 0x2, 0x32, 0x1a9, 0x3, 
    0x2, 0x2, 0x2, 0x34, 0x1b2, 0x3, 0x2, 0x2, 0x2, 0x36, 0x1bb, 0x3, 0x2, 
    0x2, 0x2, 0x38, 0x1c4, 0x3, 0x2, 0x2, 0x2, 0x3a, 0x1cd, 0x3, 0x2, 0x2, 
    0x2, 0x3c, 0x1d6, 0x3, 0x2, 0x2, 0x2, 0x3e, 0x1d9, 0x3, 0x2, 0x2, 0x2, 
    0x40, 0x1dd, 0x3, 0x2, 0x2, 0x2, 0x42, 0x1e7, 0x3, 0x2, 0x2, 0x2, 0x44, 
    0x1f1, 0x3, 0x2, 0x2, 0x2, 0x46, 0x1f3, 0x3, 0x2, 0x2, 0x2, 0x48, 0x1f9, 
    0x3, 0x2, 0x2, 0x2, 0x4a, 0x201, 0x3, 0x2, 0x2, 0x2, 0x4c, 0x20b, 0x3, 
    0x2, 0x2, 0x2, 0x4e, 0x211, 0x3, 0x2, 0x2, 0x2, 0x50, 0x219, 0x3, 0x2, 
    0x2, 0x2, 0x52, 0x223, 0x3, 0x2, 0x2, 0x2, 0x54, 0x229, 0x3, 0x2, 0x2, 
    0x2, 0x56, 0x231, 0x3, 0x2, 0x2, 0x2, 0x58, 0x23b, 0x3, 0x2, 0x2, 0x2, 
    0x5a, 0x241, 0x3, 0x2, 0x2, 0x2, 0x5c, 0x249, 0x3, 0x2, 0x2, 0x2, 0x5e, 
    0x253, 0x3, 0x2, 0x2, 0x2, 0x60, 0x259, 0x3, 0x2, 0x2, 0x2, 0x62, 0x261, 
    0x3, 0x2, 0x2, 0x2, 0x64, 0x26d, 0x3, 0x2, 0x2, 0x2, 0x66, 0x26f, 0x3, 
    0x2, 0x2, 0x2, 0x68, 0x273, 0x3, 0x2, 0x2, 0x2, 0x6a, 0x275, 0x3, 0x2, 
    0x2, 0x2, 0x6c, 0x277, 0x3, 0x2, 0x2, 0x2, 0x6e, 0x279, 0x3, 0x2, 0x2, 
    0x2, 0x70, 0x27b, 0x3, 0x2, 0x2, 0x2, 0x72, 0x284, 0x3, 0x2, 0x2, 0x2, 
    0x74, 0x295, 0x3, 0x2, 0x2, 0x2, 0x76, 0x297, 0x3, 0x2, 0x2, 0x2, 0x78, 
    0x299, 0x3, 0x2, 0x2, 0x2, 0x7a, 0x29b, 0x3, 0x2, 0x2, 0x2, 0x7c, 0x29d, 
    0x3, 0x2, 0x2, 0x2, 0x7e, 0x2ac, 0x3, 0x2, 0x2, 0x2, 0x80, 0x2ae, 0x3, 
    0x2, 0x2, 0x2, 0x82, 0x2b3, 0x3, 0x2, 0x2, 0x2, 0x84, 0x2b5, 0x3, 0x2, 
    0x2, 0x2, 0x86, 0x2be, 0x3, 0x2, 0x2, 0x2, 0x88, 0x2ca, 0x3, 0x2, 0x2, 
    0x2, 0x8a, 0x2cc, 0x3, 0x2, 0x2, 0x2, 0x8c, 0x2cf, 0x3, 0x2, 0x2, 0x2, 
    0x8e, 0x2d2, 0x3, 0x2, 0x2, 0x2, 0x90, 0x2d5, 0x3, 0x2, 0x2, 0x2, 0x92, 
    0x2d7, 0x3, 0x2, 0x2, 0x2, 0x94, 0x2f1, 0x3, 0x2, 0x2, 0x2, 0x96, 0x2f3, 
    0x3, 0x2, 0x2, 0x2, 0x98, 0x2f5, 0x3, 0x2, 0x2, 0x2, 0x9a, 0x2f7, 0x3, 
    0x2, 0x2, 0x2, 0x9c, 0x2f9, 0x3, 0x2, 0x2, 0x2, 0x9e, 0x2fb, 0x3, 0x2, 
    0x2, 0x2, 0xa0, 0x2fd, 0x3, 0x2, 0x2, 0x2, 0xa2, 0x314, 0x3, 0x2, 0x2, 
    0x2, 0xa4, 0x316, 0x3, 0x2, 0x2, 0x2, 0xa6, 0x318, 0x3, 0x2, 0x2, 0x2, 
    0xa8, 0x31a, 0x3, 0x2, 0x2, 0x2, 0xaa, 0x323, 0x3, 0x2, 0x2, 0x2, 0xac, 
    0x325, 0x3, 0x2, 0x2, 0x2, 0xae, 0x335, 0x3, 0x2, 0x2, 0x2, 0xb0, 0x337, 
    0x3, 0x2, 0x2, 0x2, 0xb2, 0x33a, 0x3, 0x2, 0x2, 0x2, 0xb4, 0x33d, 0x3, 
    0x2, 0x2, 0x2, 0xb6, 0x340, 0x3, 0x2, 0x2, 0x2, 0xb8, 0x343, 0x3, 0x2, 
    0x2, 0x2, 0xba, 0x346, 0x3, 0x2, 0x2, 0x2, 0xbc, 0x349, 0x3, 0x2, 0x2, 
    0x2, 0xbe, 0x34c, 0x3, 0x2, 0x2, 0x2, 0xc0, 0x34e, 0x3, 0x2, 0x2, 0x2, 
    0xc2, 0x357, 0x3, 0x2, 0x2, 0x2, 0xc4, 0x359, 0x3, 0x2, 0x2, 0x2, 0xc6, 
    0xc7, 0x7, 0x3, 0x2, 0x2, 0xc7, 0xc8, 0x5, 0x4, 0x3, 0x2, 0xc8, 0xc9, 
    0x7, 0x4, 0x2, 0x2, 0xc9, 0xca, 0x5, 0x6, 0x4, 0x2, 0xca, 0xcc, 0x5, 
    0x70, 0x39, 0x2, 0xcb, 0xcd, 0x5, 0x8, 0x5, 0x2, 0xcc, 0xcb, 0x3, 0x2, 
    0x2, 0x2, 0xcc, 0xcd, 0x3, 0x2, 0x2, 0x2, 0xcd, 0xcf, 0x3, 0x2, 0x2, 
    0x2, 0xce, 0xd0, 0x5, 0x7c, 0x3f, 0x2, 0xcf, 0xce, 0x3, 0x2, 0x2, 0x2, 
    0xd0, 0xd1, 0x3, 0x2, 0x2, 0x2, 0xd1, 0xcf, 0x3, 0x2, 0x2, 0x2, 0xd1, 
    0xd2, 0x3, 0x2, 0x2, 0x2, 0xd2, 0xd3, 0x3, 0x2, 0x2, 0x2, 0xd3, 0xd4, 
    0x7, 0x5, 0x2, 0x2, 0xd4, 0x3, 0x3, 0x2, 0x2, 0x2, 0xd5, 0xd6, 0x7, 
    0x4e, 0x2, 0x2, 0xd6, 0x5, 0x3, 0x2, 0x2, 0x2, 0xd7, 0xd8, 0x7, 0x6, 
    0x2, 0x2, 0xd8, 0xd9, 0x7, 0x7, 0x2, 0x2, 0xd9, 0xda, 0x7, 0x4e, 0x2, 
    0x2, 0xda, 0x7, 0x3, 0x2, 0x2, 0x2, 0xdb, 0xdc, 0x7, 0x8, 0x2, 0x2, 
    0xdc, 0xde, 0x7, 0x4, 0x2, 0x2, 0xdd, 0xdf, 0x5, 0xa, 0x6, 0x2, 0xde, 
    0xdd, 0x3, 0x2, 0x2, 0x2, 0xdf, 0xe0, 0x3, 0x2, 0x2, 0x2, 0xe0, 0xde, 
    0x3, 0x2, 0x2, 0x2, 0xe0, 0xe1, 0x3, 0x2, 0x2, 0x2, 0xe1, 0xe2, 0x3, 
    0x2, 0x2, 0x2, 0xe2, 0xe3, 0x7, 0x5, 0x2, 0x2, 0xe3, 0x9, 0x3, 0x2, 
    0x2, 0x2, 0xe4, 0xfd, 0x5, 0xc, 0x7, 0x2, 0xe5, 0xfd, 0x5, 0xe, 0x8, 
    0x2, 0xe6, 0xfd, 0x5, 0x10, 0x9, 0x2, 0xe7, 0xfd, 0x5, 0x12, 0xa, 0x2, 
    0xe8, 0xfd, 0x5, 0x14, 0xb, 0x2, 0xe9, 0xfd, 0x5, 0x16, 0xc, 0x2, 0xea, 
    0xfd, 0x5, 0x18, 0xd, 0x2, 0xeb, 0xfd, 0x5, 0x1a, 0xe, 0x2, 0xec, 0xfd, 
    0x5, 0x1c, 0xf, 0x2, 0xed, 0xfd, 0x5, 0x1e, 0x10, 0x2, 0xee, 0xfd, 0x5, 
    0x20, 0x11, 0x2, 0xef, 0xfd, 0x5, 0x22, 0x12, 0x2, 0xf0, 0xfd, 0x5, 
    0x24, 0x13, 0x2, 0xf1, 0xfd, 0x5, 0x26, 0x14, 0x2, 0xf2, 0xfd, 0x5, 
    0x28, 0x15, 0x2, 0xf3, 0xfd, 0x5, 0x2a, 0x16, 0x2, 0xf4, 0xfd, 0x5, 
    0x2c, 0x17, 0x2, 0xf5, 0xfd, 0x5, 0x2e, 0x18, 0x2, 0xf6, 0xfd, 0x5, 
    0x30, 0x19, 0x2, 0xf7, 0xfd, 0x5, 0x32, 0x1a, 0x2, 0xf8, 0xfd, 0x5, 
    0x34, 0x1b, 0x2, 0xf9, 0xfd, 0x5, 0x36, 0x1c, 0x2, 0xfa, 0xfd, 0x5, 
    0x38, 0x1d, 0x2, 0xfb, 0xfd, 0x5, 0x3a, 0x1e, 0x2, 0xfc, 0xe4, 0x3, 
    0x2, 0x2, 0x2, 0xfc, 0xe5, 0x3, 0x2, 0x2, 0x2, 0xfc, 0xe6, 0x3, 0x2, 
    0x2, 0x2, 0xfc, 0xe7, 0x3, 0x2, 0x2, 0x2, 0xfc, 0xe8, 0x3, 0x2, 0x2, 
    0x2, 0xfc, 0xe9, 0x3, 0x2, 0x2, 0x2, 0xfc, 0xea, 0x3, 0x2, 0x2, 0x2, 
    0xfc, 0xeb, 0x3, 0x2, 0x2, 0x2, 0xfc, 0xec, 0x3, 0x2, 0x2, 0x2, 0xfc, 
    0xed, 0x3, 0x2, 0x2, 0x2, 0xfc, 0xee, 0x3, 0x2, 0x2, 0x2, 0xfc, 0xef, 
    0x3, 0x2, 0x2, 0x2, 0xfc, 0xf0, 0x3, 0x2, 0x2, 0x2, 0xfc, 0xf1, 0x3, 
    0x2, 0x2, 0x2, 0xfc, 0xf2, 0x3, 0x2, 0x2, 0x2, 0xfc, 0xf3, 0x3, 0x2, 
    0x2, 0x2, 0xfc, 0xf4, 0x3, 0x2, 0x2, 0x2, 0xfc, 0xf5, 0x3, 0x2, 0x2, 
    0x2, 0xfc, 0xf6, 0x3, 0x2, 0x2, 0x2, 0xfc, 0xf7, 0x3, 0x2, 0x2, 0x2, 
    0xfc, 0xf8, 0x3, 0x2, 0x2, 0x2, 0xfc, 0xf9, 0x3, 0x2, 0x2, 0x2, 0xfc, 
    0xfa, 0x3, 0x2, 0x2, 0x2, 0xfc, 0xfb, 0x3, 0x2, 0x2, 0x2, 0xfd, 0xb, 
    0x3, 0x2, 0x2, 0x2, 0xfe, 0xff, 0x5, 0x6c, 0x37, 0x2, 0xff, 0x100, 0x7, 
    0x9, 0x2, 0x2, 0x100, 0x101, 0x5, 0x6e, 0x38, 0x2, 0x101, 0x102, 0x7, 
    0xa, 0x2, 0x2, 0x102, 0x103, 0x7, 0xb, 0x2, 0x2, 0x103, 0x104, 0x7, 
    0xc, 0x2, 0x2, 0x104, 0x105, 0x7, 0x7, 0x2, 0x2, 0x105, 0x106, 0x5, 
    0x3c, 0x1f, 0x2, 0x106, 0xd, 0x3, 0x2, 0x2, 0x2, 0x107, 0x108, 0x5, 
    0x6c, 0x37, 0x2, 0x108, 0x109, 0x7, 0x9, 0x2, 0x2, 0x109, 0x10a, 0x5, 
    0x6e, 0x38, 0x2, 0x10a, 0x10b, 0x7, 0xa, 0x2, 0x2, 0x10b, 0x10c, 0x7, 
    0xd, 0x2, 0x2, 0x10c, 0x10d, 0x7, 0xc, 0x2, 0x2, 0x10d, 0x10e, 0x7, 
    0x7, 0x2, 0x2, 0x10e, 0x10f, 0x5, 0x3e, 0x20, 0x2, 0x10f, 0xf, 0x3, 
    0x2, 0x2, 0x2, 0x110, 0x111, 0x5, 0x6c, 0x37, 0x2, 0x111, 0x112, 0x7, 
    0x9, 0x2, 0x2, 0x112, 0x113, 0x5, 0x6e, 0x38, 0x2, 0x113, 0x114, 0x7, 
    0xa, 0x2, 0x2, 0x114, 0x115, 0x7, 0xe, 0x2, 0x2, 0x115, 0x116, 0x7, 
    0xc, 0x2, 0x2, 0x116, 0x117, 0x7, 0x7, 0x2, 0x2, 0x117, 0x118, 0x5, 
    0x40, 0x21, 0x2, 0x118, 0x11, 0x3, 0x2, 0x2, 0x2, 0x119, 0x11a, 0x5, 
    0x6c, 0x37, 0x2, 0x11a, 0x11b, 0x7, 0x9, 0x2, 0x2, 0x11b, 0x11c, 0x5, 
    0x6e, 0x38, 0x2, 0x11c, 0x11d, 0x7, 0xa, 0x2, 0x2, 0x11d, 0x11e, 0x7, 
    0xf, 0x2, 0x2, 0x11e, 0x11f, 0x7, 0xc, 0x2, 0x2, 0x11f, 0x120, 0x7, 
    0x7, 0x2, 0x2, 0x120, 0x121, 0x5, 0x42, 0x22, 0x2, 0x121, 0x13, 0x3, 
    0x2, 0x2, 0x2, 0x122, 0x123, 0x5, 0x6c, 0x37, 0x2, 0x123, 0x124, 0x7, 
    0x9, 0x2, 0x2, 0x124, 0x125, 0x5, 0x6e, 0x38, 0x2, 0x125, 0x126, 0x7, 
    0xa, 0x2, 0x2, 0x126, 0x127, 0x7, 0x10, 0x2, 0x2, 0x127, 0x128, 0x7, 
    0xc, 0x2, 0x2, 0x128, 0x129, 0x7, 0x7, 0x2, 0x2, 0x129, 0x12a, 0x5, 
    0x44, 0x23, 0x2, 0x12a, 0x15, 0x3, 0x2, 0x2, 0x2, 0x12b, 0x12c, 0x5, 
    0x6c, 0x37, 0x2, 0x12c, 0x12d, 0x7, 0x9, 0x2, 0x2, 0x12d, 0x12e, 0x5, 
    0x6e, 0x38, 0x2, 0x12e, 0x12f, 0x7, 0xa, 0x2, 0x2, 0x12f, 0x130, 0x7, 
    0x11, 0x2, 0x2, 0x130, 0x131, 0x7, 0xc, 0x2, 0x2, 0x131, 0x132, 0x7, 
    0x7, 0x2, 0x2, 0x132, 0x133, 0x5, 0x46, 0x24, 0x2, 0x133, 0x17, 0x3, 
    0x2, 0x2, 0x2, 0x134, 0x135, 0x5, 0x6c, 0x37, 0x2, 0x135, 0x136, 0x7, 
    0x9, 0x2, 0x2, 0x136, 0x137, 0x5, 0x6e, 0x38, 0x2, 0x137, 0x138, 0x7, 
    0xa, 0x2, 0x2, 0x138, 0x139, 0x7, 0x12, 0x2, 0x2, 0x139, 0x13a, 0x7, 
    0xc, 0x2, 0x2, 0x13a, 0x13b, 0x7, 0x7, 0x2, 0x2, 0x13b, 0x13c, 0x5, 
    0x48, 0x25, 0x2, 0x13c, 0x19, 0x3, 0x2, 0x2, 0x2, 0x13d, 0x13e, 0x5, 
    0x6c, 0x37, 0x2, 0x13e, 0x13f, 0x7, 0x9, 0x2, 0x2, 0x13f, 0x140, 0x5, 
    0x6e, 0x38, 0x2, 0x140, 0x141, 0x7, 0xa, 0x2, 0x2, 0x141, 0x142, 0x7, 
    0x13, 0x2, 0x2, 0x142, 0x143, 0x7, 0xc, 0x2, 0x2, 0x143, 0x144, 0x7, 
    0x7, 0x2, 0x2, 0x144, 0x145, 0x5, 0x4a, 0x26, 0x2, 0x145, 0x1b, 0x3, 
    0x2, 0x2, 0x2, 0x146, 0x147, 0x5, 0x6c, 0x37, 0x2, 0x147, 0x148, 0x7, 
    0x9, 0x2, 0x2, 0x148, 0x149, 0x5, 0x6e, 0x38, 0x2, 0x149, 0x14a, 0x7, 
    0xa, 0x2, 0x2, 0x14a, 0x14b, 0x7, 0x14, 0x2, 0x2, 0x14b, 0x14c, 0x7, 
    0xc, 0x2, 0x2, 0x14c, 0x14d, 0x7, 0x7, 0x2, 0x2, 0x14d, 0x14e, 0x5, 
    0x4c, 0x27, 0x2, 0x14e, 0x1d, 0x3, 0x2, 0x2, 0x2, 0x14f, 0x150, 0x5, 
    0x6c, 0x37, 0x2, 0x150, 0x151, 0x7, 0x9, 0x2, 0x2, 0x151, 0x152, 0x5, 
    0x6e, 0x38, 0x2, 0x152, 0x153, 0x7, 0xa, 0x2, 0x2, 0x153, 0x154, 0x7, 
    0x15, 0x2, 0x2, 0x154, 0x155, 0x7, 0xc, 0x2, 0x2, 0x155, 0x156, 0x7, 
    0x7, 0x2, 0x2, 0x156, 0x157, 0x5, 0x4e, 0x28, 0x2, 0x157, 0x1f, 0x3, 
    0x2, 0x2, 0x2, 0x158, 0x159, 0x5, 0x6c, 0x37, 0x2, 0x159, 0x15a, 0x7, 
    0x9, 0x2, 0x2, 0x15a, 0x15b, 0x5, 0x6e, 0x38, 0x2, 0x15b, 0x15c, 0x7, 
    0xa, 0x2, 0x2, 0x15c, 0x15d, 0x7, 0x16, 0x2, 0x2, 0x15d, 0x15e, 0x7, 
    0xc, 0x2, 0x2, 0x15e, 0x15f, 0x7, 0x7, 0x2, 0x2, 0x15f, 0x160, 0x5, 
    0x50, 0x29, 0x2, 0x160, 0x21, 0x3, 0x2, 0x2, 0x2, 0x161, 0x162, 0x5, 
    0x6c, 0x37, 0x2, 0x162, 0x163, 0x7, 0x9, 0x2, 0x2, 0x163, 0x164, 0x5, 
    0x6e, 0x38, 0x2, 0x164, 0x165, 0x7, 0xa, 0x2, 0x2, 0x165, 0x166, 0x7, 
    0x17, 0x2, 0x2, 0x166, 0x167, 0x7, 0xc, 0x2, 0x2, 0x167, 0x168, 0x7, 
    0x7, 0x2, 0x2, 0x168, 0x169, 0x5, 0x52, 0x2a, 0x2, 0x169, 0x23, 0x3, 
    0x2, 0x2, 0x2, 0x16a, 0x16b, 0x5, 0x6c, 0x37, 0x2, 0x16b, 0x16c, 0x7, 
    0x9, 0x2, 0x2, 0x16c, 0x16d, 0x5, 0x6e, 0x38, 0x2, 0x16d, 0x16e, 0x7, 
    0xa, 0x2, 0x2, 0x16e, 0x16f, 0x7, 0x18, 0x2, 0x2, 0x16f, 0x170, 0x7, 
    0xc, 0x2, 0x2, 0x170, 0x171, 0x7, 0x7, 0x2, 0x2, 0x171, 0x172, 0x5, 
    0x54, 0x2b, 0x2, 0x172, 0x25, 0x3, 0x2, 0x2, 0x2, 0x173, 0x174, 0x5, 
    0x6c, 0x37, 0x2, 0x174, 0x175, 0x7, 0x9, 0x2, 0x2, 0x175, 0x176, 0x5, 
    0x6e, 0x38, 0x2, 0x176, 0x177, 0x7, 0xa, 0x2, 0x2, 0x177, 0x178, 0x7, 
    0x19, 0x2, 0x2, 0x178, 0x179, 0x7, 0xc, 0x2, 0x2, 0x179, 0x17a, 0x7, 
    0x7, 0x2, 0x2, 0x17a, 0x17b, 0x5, 0x56, 0x2c, 0x2, 0x17b, 0x27, 0x3, 
    0x2, 0x2, 0x2, 0x17c, 0x17d, 0x5, 0x6c, 0x37, 0x2, 0x17d, 0x17e, 0x7, 
    0x9, 0x2, 0x2, 0x17e, 0x17f, 0x5, 0x6e, 0x38, 0x2, 0x17f, 0x180, 0x7, 
    0xa, 0x2, 0x2, 0x180, 0x181, 0x7, 0x1a, 0x2, 0x2, 0x181, 0x182, 0x7, 
    0xc, 0x2, 0x2, 0x182, 0x183, 0x7, 0x7, 0x2, 0x2, 0x183, 0x184, 0x5, 
    0x58, 0x2d, 0x2, 0x184, 0x29, 0x3, 0x2, 0x2, 0x2, 0x185, 0x186, 0x5, 
    0x6c, 0x37, 0x2, 0x186, 0x187, 0x7, 0x9, 0x2, 0x2, 0x187, 0x188, 0x5, 
    0x6e, 0x38, 0x2, 0x188, 0x189, 0x7, 0xa, 0x2, 0x2, 0x189, 0x18a, 0x7, 
    0x1b, 0x2, 0x2, 0x18a, 0x18b, 0x7, 0xc, 0x2, 0x2, 0x18b, 0x18c, 0x7, 
    0x7, 0x2, 0x2, 0x18c, 0x18d, 0x5, 0x5a, 0x2e, 0x2, 0x18d, 0x2b, 0x3, 
    0x2, 0x2, 0x2, 0x18e, 0x18f, 0x5, 0x6c, 0x37, 0x2, 0x18f, 0x190, 0x7, 
    0x9, 0x2, 0x2, 0x190, 0x191, 0x5, 0x6e, 0x38, 0x2, 0x191, 0x192, 0x7, 
    0xa, 0x2, 0x2, 0x192, 0x193, 0x7, 0x1c, 0x2, 0x2, 0x193, 0x194, 0x7, 
    0xc, 0x2, 0x2, 0x194, 0x195, 0x7, 0x7, 0x2, 0x2, 0x195, 0x196, 0x5, 
    0x5c, 0x2f, 0x2, 0x196, 0x2d, 0x3, 0x2, 0x2, 0x2, 0x197, 0x198, 0x5, 
    0x6c, 0x37, 0x2, 0x198, 0x199, 0x7, 0x9, 0x2, 0x2, 0x199, 0x19a, 0x5, 
    0x6e, 0x38, 0x2, 0x19a, 0x19b, 0x7, 0xa, 0x2, 0x2, 0x19b, 0x19c, 0x7, 
    0x1d, 0x2, 0x2, 0x19c, 0x19d, 0x7, 0xc, 0x2, 0x2, 0x19d, 0x19e, 0x7, 
    0x7, 0x2, 0x2, 0x19e, 0x19f, 0x5, 0x5e, 0x30, 0x2, 0x19f, 0x2f, 0x3, 
    0x2, 0x2, 0x2, 0x1a0, 0x1a1, 0x5, 0x6c, 0x37, 0x2, 0x1a1, 0x1a2, 0x7, 
    0x9, 0x2, 0x2, 0x1a2, 0x1a3, 0x5, 0x6e, 0x38, 0x2, 0x1a3, 0x1a4, 0x7, 
    0xa, 0x2, 0x2, 0x1a4, 0x1a5, 0x7, 0x1e, 0x2, 0x2, 0x1a5, 0x1a6, 0x7, 
    0xc, 0x2, 0x2, 0x1a6, 0x1a7, 0x7, 0x7, 0x2, 0x2, 0x1a7, 0x1a8, 0x5, 
    0x60, 0x31, 0x2, 0x1a8, 0x31, 0x3, 0x2, 0x2, 0x2, 0x1a9, 0x1aa, 0x5, 
    0x6c, 0x37, 0x2, 0x1aa, 0x1ab, 0x7, 0x9, 0x2, 0x2, 0x1ab, 0x1ac, 0x5, 
    0x6e, 0x38, 0x2, 0x1ac, 0x1ad, 0x7, 0xa, 0x2, 0x2, 0x1ad, 0x1ae, 0x7, 
    0x1f, 0x2, 0x2, 0x1ae, 0x1af, 0x7, 0xc, 0x2, 0x2, 0x1af, 0x1b0, 0x7, 
    0x7, 0x2, 0x2, 0x1b0, 0x1b1, 0x5, 0x62, 0x32, 0x2, 0x1b1, 0x33, 0x3, 
    0x2, 0x2, 0x2, 0x1b2, 0x1b3, 0x5, 0x6c, 0x37, 0x2, 0x1b3, 0x1b4, 0x7, 
    0x9, 0x2, 0x2, 0x1b4, 0x1b5, 0x5, 0x6e, 0x38, 0x2, 0x1b5, 0x1b6, 0x7, 
    0xa, 0x2, 0x2, 0x1b6, 0x1b7, 0x7, 0x20, 0x2, 0x2, 0x1b7, 0x1b8, 0x7, 
    0xc, 0x2, 0x2, 0x1b8, 0x1b9, 0x7, 0x7, 0x2, 0x2, 0x1b9, 0x1ba, 0x5, 
    0x64, 0x33, 0x2, 0x1ba, 0x35, 0x3, 0x2, 0x2, 0x2, 0x1bb, 0x1bc, 0x5, 
    0x6c, 0x37, 0x2, 0x1bc, 0x1bd, 0x7, 0x9, 0x2, 0x2, 0x1bd, 0x1be, 0x5, 
    0x6e, 0x38, 0x2, 0x1be, 0x1bf, 0x7, 0xa, 0x2, 0x2, 0x1bf, 0x1c0, 0x7, 
    0x21, 0x2, 0x2, 0x1c0, 0x1c1, 0x7, 0xc, 0x2, 0x2, 0x1c1, 0x1c2, 0x7, 
    0x7, 0x2, 0x2, 0x1c2, 0x1c3, 0x5, 0x68, 0x35, 0x2, 0x1c3, 0x37, 0x3, 
    0x2, 0x2, 0x2, 0x1c4, 0x1c5, 0x5, 0x6c, 0x37, 0x2, 0x1c5, 0x1c6, 0x7, 
    0x9, 0x2, 0x2, 0x1c6, 0x1c7, 0x5, 0x6e, 0x38, 0x2, 0x1c7, 0x1c8, 0x7, 
    0xa, 0x2, 0x2, 0x1c8, 0x1c9, 0x7, 0x22, 0x2, 0x2, 0x1c9, 0x1ca, 0x7, 
    0xc, 0x2, 0x2, 0x1ca, 0x1cb, 0x7, 0x7, 0x2, 0x2, 0x1cb, 0x1cc, 0x5, 
    0x5a, 0x2e, 0x2, 0x1cc, 0x39, 0x3, 0x2, 0x2, 0x2, 0x1cd, 0x1ce, 0x5, 
    0x6c, 0x37, 0x2, 0x1ce, 0x1cf, 0x7, 0x9, 0x2, 0x2, 0x1cf, 0x1d0, 0x5, 
    0x6e, 0x38, 0x2, 0x1d0, 0x1d1, 0x7, 0xa, 0x2, 0x2, 0x1d1, 0x1d2, 0x7, 
    0x23, 0x2, 0x2, 0x1d2, 0x1d3, 0x7, 0xc, 0x2, 0x2, 0x1d3, 0x1d4, 0x7, 
    0x7, 0x2, 0x2, 0x1d4, 0x1d5, 0x5, 0x5c, 0x2f, 0x2, 0x1d5, 0x3b, 0x3, 
    0x2, 0x2, 0x2, 0x1d6, 0x1d7, 0x7, 0x50, 0x2, 0x2, 0x1d7, 0x3d, 0x3, 
    0x2, 0x2, 0x2, 0x1d8, 0x1da, 0x7, 0x5c, 0x2, 0x2, 0x1d9, 0x1d8, 0x3, 
    0x2, 0x2, 0x2, 0x1d9, 0x1da, 0x3, 0x2, 0x2, 0x2, 0x1da, 0x1db, 0x3, 
    0x2, 0x2, 0x2, 0x1db, 0x1dc, 0x7, 0x55, 0x2, 0x2, 0x1dc, 0x3f, 0x3, 
    0x2, 0x2, 0x2, 0x1dd, 0x1de, 0x7, 0x55, 0x2, 0x2, 0x1de, 0x41, 0x3, 
    0x2, 0x2, 0x2, 0x1df, 0x1e1, 0x7, 0x5c, 0x2, 0x2, 0x1e0, 0x1df, 0x3, 
    0x2, 0x2, 0x2, 0x1e0, 0x1e1, 0x3, 0x2, 0x2, 0x2, 0x1e1, 0x1e2, 0x3, 
    0x2, 0x2, 0x2, 0x1e2, 0x1e8, 0x7, 0x55, 0x2, 0x2, 0x1e3, 0x1e5, 0x7, 
    0x5c, 0x2, 0x2, 0x1e4, 0x1e3, 0x3, 0x2, 0x2, 0x2, 0x1e4, 0x1e5, 0x3, 
    0x2, 0x2, 0x2, 0x1e5, 0x1e6, 0x3, 0x2, 0x2, 0x2, 0x1e6, 0x1e8, 0x7, 
    0x56, 0x2, 0x2, 0x1e7, 0x1e0, 0x3, 0x2, 0x2, 0x2, 0x1e7, 0x1e4, 0x3, 
    0x2, 0x2, 0x2, 0x1e8, 0x43, 0x3, 0x2, 0x2, 0x2, 0x1e9, 0x1eb, 0x7, 0x5c, 
    0x2, 0x2, 0x1ea, 0x1e9, 0x3, 0x2, 0x2, 0x2, 0x1ea, 0x1eb, 0x3, 0x2, 
    0x2, 0x2, 0x1eb, 0x1ec, 0x3, 0x2, 0x2, 0x2, 0x1ec, 0x1f2, 0x7, 0x55, 
    0x2, 0x2, 0x1ed, 0x1ef, 0x7, 0x5c, 0x2, 0x2, 0x1ee, 0x1ed, 0x3, 0x2, 
    0x2, 0x2, 0x1ee, 0x1ef, 0x3, 0x2, 0x2, 0x2, 0x1ef, 0x1f0, 0x3, 0x2, 
    0x2, 0x2, 0x1f0, 0x1f2, 0x7, 0x56, 0x2, 0x2, 0x1f1, 0x1ea, 0x3, 0x2, 
    0x2, 0x2, 0x1f1, 0x1ee, 0x3, 0x2, 0x2, 0x2, 0x1f2, 0x45, 0x3, 0x2, 0x2, 
    0x2, 0x1f3, 0x1f4, 0x7, 0x9, 0x2, 0x2, 0x1f4, 0x1f5, 0x5, 0x3c, 0x1f, 
    0x2, 0x1f5, 0x1f6, 0x7, 0xa, 0x2, 0x2, 0x1f6, 0x1f7, 0x5, 0x3c, 0x1f, 
    0x2, 0x1f7, 0x1f8, 0x7, 0xc, 0x2, 0x2, 0x1f8, 0x47, 0x3, 0x2, 0x2, 0x2, 
    0x1f9, 0x1fa, 0x7, 0x9, 0x2, 0x2, 0x1fa, 0x1fb, 0x5, 0x3c, 0x1f, 0x2, 
    0x1fb, 0x1fc, 0x7, 0xa, 0x2, 0x2, 0x1fc, 0x1fd, 0x5, 0x3c, 0x1f, 0x2, 
    0x1fd, 0x1fe, 0x7, 0xa, 0x2, 0x2, 0x1fe, 0x1ff, 0x5, 0x3c, 0x1f, 0x2, 
    0x1ff, 0x200, 0x7, 0xc, 0x2, 0x2, 0x200, 0x49, 0x3, 0x2, 0x2, 0x2, 0x201, 
    0x202, 0x7, 0x9, 0x2, 0x2, 0x202, 0x203, 0x5, 0x3c, 0x1f, 0x2, 0x203, 
    0x204, 0x7, 0xa, 0x2, 0x2, 0x204, 0x205, 0x5, 0x3c, 0x1f, 0x2, 0x205, 
    0x206, 0x7, 0xa, 0x2, 0x2, 0x206, 0x207, 0x5, 0x3c, 0x1f, 0x2, 0x207, 
    0x208, 0x7, 0xa, 0x2, 0x2, 0x208, 0x209, 0x5, 0x3c, 0x1f, 0x2, 0x209, 
    0x20a, 0x7, 0xc, 0x2, 0x2, 0x20a, 0x4b, 0x3, 0x2, 0x2, 0x2, 0x20b, 0x20c, 
    0x7, 0x9, 0x2, 0x2, 0x20c, 0x20d, 0x5, 0x3e, 0x20, 0x2, 0x20d, 0x20e, 
    0x7, 0xa, 0x2, 0x2, 0x20e, 0x20f, 0x5, 0x3e, 0x20, 0x2, 0x20f, 0x210, 
    0x7, 0xc, 0x2, 0x2, 0x210, 0x4d, 0x3, 0x2, 0x2, 0x2, 0x211, 0x212, 0x7, 
    0x9, 0x2, 0x2, 0x212, 0x213, 0x5, 0x3e, 0x20, 0x2, 0x213, 0x214, 0x7, 
    0xa, 0x2, 0x2, 0x214, 0x215, 0x5, 0x3e, 0x20, 0x2, 0x215, 0x216, 0x7, 
    0xa, 0x2, 0x2, 0x216, 0x217, 0x5, 0x3e, 0x20, 0x2, 0x217, 0x218, 0x7, 
    0xc, 0x2, 0x2, 0x218, 0x4f, 0x3, 0x2, 0x2, 0x2, 0x219, 0x21a, 0x7, 0x9, 
    0x2, 0x2, 0x21a, 0x21b, 0x5, 0x3e, 0x20, 0x2, 0x21b, 0x21c, 0x7, 0xa, 
    0x2, 0x2, 0x21c, 0x21d, 0x5, 0x3e, 0x20, 0x2, 0x21d, 0x21e, 0x7, 0xa, 
    0x2, 0x2, 0x21e, 0x21f, 0x5, 0x3e, 0x20, 0x2, 0x21f, 0x220, 0x7, 0xa, 
    0x2, 0x2, 0x220, 0x221, 0x5, 0x3e, 0x20, 0x2, 0x221, 0x222, 0x7, 0xc, 
    0x2, 0x2, 0x222, 0x51, 0x3, 0x2, 0x2, 0x2, 0x223, 0x224, 0x7, 0x9, 0x2, 
    0x2, 0x224, 0x225, 0x5, 0x40, 0x21, 0x2, 0x225, 0x226, 0x7, 0xa, 0x2, 
    0x2, 0x226, 0x227, 0x5, 0x40, 0x21, 0x2, 0x227, 0x228, 0x7, 0xc, 0x2, 
    0x2, 0x228, 0x53, 0x3, 0x2, 0x2, 0x2, 0x229, 0x22a, 0x7, 0x9, 0x2, 0x2, 
    0x22a, 0x22b, 0x5, 0x40, 0x21, 0x2, 0x22b, 0x22c, 0x7, 0xa, 0x2, 0x2, 
    0x22c, 0x22d, 0x5, 0x40, 0x21, 0x2, 0x22d, 0x22e, 0x7, 0xa, 0x2, 0x2, 
    0x22e, 0x22f, 0x5, 0x40, 0x21, 0x2, 0x22f, 0x230, 0x7, 0xc, 0x2, 0x2, 
    0x230, 0x55, 0x3, 0x2, 0x2, 0x2, 0x231, 0x232, 0x7, 0x9, 0x2, 0x2, 0x232, 
    0x233, 0x5, 0x40, 0x21, 0x2, 0x233, 0x234, 0x7, 0xa, 0x2, 0x2, 0x234, 
    0x235, 0x5, 0x40, 0x21, 0x2, 0x235, 0x236, 0x7, 0xa, 0x2, 0x2, 0x236, 
    0x237, 0x5, 0x40, 0x21, 0x2, 0x237, 0x238, 0x7, 0xa, 0x2, 0x2, 0x238, 
    0x239, 0x5, 0x40, 0x21, 0x2, 0x239, 0x23a, 0x7, 0xc, 0x2, 0x2, 0x23a, 
    0x57, 0x3, 0x2, 0x2, 0x2, 0x23b, 0x23c, 0x7, 0x9, 0x2, 0x2, 0x23c, 0x23d, 
    0x5, 0x42, 0x22, 0x2, 0x23d, 0x23e, 0x7, 0xa, 0x2, 0x2, 0x23e, 0x23f, 
    0x5, 0x42, 0x22, 0x2, 0x23f, 0x240, 0x7, 0xc, 0x2, 0x2, 0x240, 0x59, 
    0x3, 0x2, 0x2, 0x2, 0x241, 0x242, 0x7, 0x9, 0x2, 0x2, 0x242, 0x243, 
    0x5, 0x42, 0x22, 0x2, 0x243, 0x244, 0x7, 0xa, 0x2, 0x2, 0x244, 0x245, 
    0x5, 0x42, 0x22, 0x2, 0x245, 0x246, 0x7, 0xa, 0x2, 0x2, 0x246, 0x247, 
    0x5, 0x42, 0x22, 0x2, 0x247, 0x248, 0x7, 0xc, 0x2, 0x2, 0x248, 0x5b, 
    0x3, 0x2, 0x2, 0x2, 0x249, 0x24a, 0x7, 0x9, 0x2, 0x2, 0x24a, 0x24b, 
    0x5, 0x42, 0x22, 0x2, 0x24b, 0x24c, 0x7, 0xa, 0x2, 0x2, 0x24c, 0x24d, 
    0x5, 0x42, 0x22, 0x2, 0x24d, 0x24e, 0x7, 0xa, 0x2, 0x2, 0x24e, 0x24f, 
    0x5, 0x42, 0x22, 0x2, 0x24f, 0x250, 0x7, 0xa, 0x2, 0x2, 0x250, 0x251, 
    0x5, 0x42, 0x22, 0x2, 0x251, 0x252, 0x7, 0xc, 0x2, 0x2, 0x252, 0x5d, 
    0x3, 0x2, 0x2, 0x2, 0x253, 0x254, 0x7, 0x9, 0x2, 0x2, 0x254, 0x255, 
    0x5, 0x44, 0x23, 0x2, 0x255, 0x256, 0x7, 0xa, 0x2, 0x2, 0x256, 0x257, 
    0x5, 0x44, 0x23, 0x2, 0x257, 0x258, 0x7, 0xc, 0x2, 0x2, 0x258, 0x5f, 
    0x3, 0x2, 0x2, 0x2, 0x259, 0x25a, 0x7, 0x9, 0x2, 0x2, 0x25a, 0x25b, 
    0x5, 0x44, 0x23, 0x2, 0x25b, 0x25c, 0x7, 0xa, 0x2, 0x2, 0x25c, 0x25d, 
    0x5, 0x44, 0x23, 0x2, 0x25d, 0x25e, 0x7, 0xa, 0x2, 0x2, 0x25e, 0x25f, 
    0x5, 0x44, 0x23, 0x2, 0x25f, 0x260, 0x7, 0xc, 0x2, 0x2, 0x260, 0x61, 
    0x3, 0x2, 0x2, 0x2, 0x261, 0x262, 0x7, 0x9, 0x2, 0x2, 0x262, 0x263, 
    0x5, 0x44, 0x23, 0x2, 0x263, 0x264, 0x7, 0xa, 0x2, 0x2, 0x264, 0x265, 
    0x5, 0x44, 0x23, 0x2, 0x265, 0x266, 0x7, 0xa, 0x2, 0x2, 0x266, 0x267, 
    0x5, 0x44, 0x23, 0x2, 0x267, 0x268, 0x7, 0xa, 0x2, 0x2, 0x268, 0x269, 
    0x5, 0x44, 0x23, 0x2, 0x269, 0x26a, 0x7, 0xc, 0x2, 0x2, 0x26a, 0x63, 
    0x3, 0x2, 0x2, 0x2, 0x26b, 0x26e, 0x5, 0x66, 0x34, 0x2, 0x26c, 0x26e, 
    0x7, 0x4e, 0x2, 0x2, 0x26d, 0x26b, 0x3, 0x2, 0x2, 0x2, 0x26d, 0x26c, 
    0x3, 0x2, 0x2, 0x2, 0x26e, 0x65, 0x3, 0x2, 0x2, 0x2, 0x26f, 0x270, 0x9, 
    0x2, 0x2, 0x2, 0x270, 0x67, 0x3, 0x2, 0x2, 0x2, 0x271, 0x274, 0x5, 0x6a, 
    0x36, 0x2, 0x272, 0x274, 0x7, 0x4e, 0x2, 0x2, 0x273, 0x271, 0x3, 0x2, 
    0x2, 0x2, 0x273, 0x272, 0x3, 0x2, 0x2, 0x2, 0x274, 0x69, 0x3, 0x2, 0x2, 
    0x2, 0x275, 0x276, 0x9, 0x3, 0x2, 0x2, 0x276, 0x6b, 0x3, 0x2, 0x2, 0x2, 
    0x277, 0x278, 0x7, 0x5d, 0x2, 0x2, 0x278, 0x6d, 0x3, 0x2, 0x2, 0x2, 
    0x279, 0x27a, 0x7, 0x4e, 0x2, 0x2, 0x27a, 0x6f, 0x3, 0x2, 0x2, 0x2, 
    0x27b, 0x27c, 0x7, 0x27, 0x2, 0x2, 0x27c, 0x27e, 0x7, 0x4, 0x2, 0x2, 
    0x27d, 0x27f, 0x5, 0x72, 0x3a, 0x2, 0x27e, 0x27d, 0x3, 0x2, 0x2, 0x2, 
    0x27f, 0x280, 0x3, 0x2, 0x2, 0x2, 0x280, 0x27e, 0x3, 0x2, 0x2, 0x2, 
    0x280, 0x281, 0x3, 0x2, 0x2, 0x2, 0x281, 0x282, 0x3, 0x2, 0x2, 0x2, 
    0x282, 0x283, 0x7, 0x5, 0x2, 0x2, 0x283, 0x71, 0x3, 0x2, 0x2, 0x2, 0x284, 
    0x289, 0x7, 0x53, 0x2, 0x2, 0x285, 0x286, 0x7, 0x28, 0x2, 0x2, 0x286, 
    0x287, 0x5, 0x7a, 0x3e, 0x2, 0x287, 0x288, 0x7, 0x29, 0x2, 0x2, 0x288, 
    0x28a, 0x3, 0x2, 0x2, 0x2, 0x289, 0x285, 0x3, 0x2, 0x2, 0x2, 0x289, 
    0x28a, 0x3, 0x2, 0x2, 0x2, 0x28a, 0x28b, 0x3, 0x2, 0x2, 0x2, 0x28b, 
    0x28c, 0x7, 0x7, 0x2, 0x2, 0x28c, 0x28d, 0x5, 0x74, 0x3b, 0x2, 0x28d, 
    0x73, 0x3, 0x2, 0x2, 0x2, 0x28e, 0x296, 0x5, 0x76, 0x3c, 0x2, 0x28f, 
    0x290, 0x7, 0x9, 0x2, 0x2, 0x290, 0x291, 0x5, 0x76, 0x3c, 0x2, 0x291, 
    0x292, 0x7, 0xa, 0x2, 0x2, 0x292, 0x293, 0x5, 0x78, 0x3d, 0x2, 0x293, 
    0x294, 0x7, 0xc, 0x2, 0x2, 0x294, 0x296, 0x3, 0x2, 0x2, 0x2, 0x295, 
    0x28e, 0x3, 0x2, 0x2, 0x2, 0x295, 0x28f, 0x3, 0x2, 0x2, 0x2, 0x296, 
    0x75, 0x3, 0x2, 0x2, 0x2, 0x297, 0x298, 0x7, 0x55, 0x2, 0x2, 0x298, 
    0x77, 0x3, 0x2, 0x2, 0x2, 0x299, 0x29a, 0x7, 0x55, 0x2, 0x2, 0x29a, 
    0x79, 0x3, 0x2, 0x2, 0x2, 0x29b, 0x29c, 0x7, 0x55, 0x2, 0x2, 0x29c, 
    0x7b, 0x3, 0x2, 0x2, 0x2, 0x29d, 0x29e, 0x7, 0x2a, 0x2, 0x2, 0x29e, 
    0x29f, 0x7, 0x9, 0x2, 0x2, 0x29f, 0x2a0, 0x5, 0x7e, 0x40, 0x2, 0x2a0, 
    0x2a1, 0x7, 0xa, 0x2, 0x2, 0x2a1, 0x2a2, 0x5, 0x80, 0x41, 0x2, 0x2a2, 
    0x2a3, 0x7, 0xc, 0x2, 0x2, 0x2a3, 0x2a7, 0x7, 0x4, 0x2, 0x2, 0x2a4, 
    0x2a6, 0x5, 0x82, 0x42, 0x2, 0x2a5, 0x2a4, 0x3, 0x2, 0x2, 0x2, 0x2a6, 
    0x2a9, 0x3, 0x2, 0x2, 0x2, 0x2a7, 0x2a5, 0x3, 0x2, 0x2, 0x2, 0x2a7, 
    0x2a8, 0x3, 0x2, 0x2, 0x2, 0x2a8, 0x2aa, 0x3, 0x2, 0x2, 0x2, 0x2a9, 
    0x2a7, 0x3, 0x2, 0x2, 0x2, 0x2aa, 0x2ab, 0x7, 0x5, 0x2, 0x2, 0x2ab, 
    0x7d, 0x3, 0x2, 0x2, 0x2, 0x2ac, 0x2ad, 0x7, 0x5d, 0x2, 0x2, 0x2ad, 
    0x7f, 0x3, 0x2, 0x2, 0x2, 0x2ae, 0x2af, 0x7, 0x5d, 0x2, 0x2, 0x2af, 
    0x81, 0x3, 0x2, 0x2, 0x2, 0x2b0, 0x2b4, 0x5, 0x88, 0x45, 0x2, 0x2b1, 
    0x2b4, 0x5, 0x84, 0x43, 0x2, 0x2b2, 0x2b4, 0x5, 0xc0, 0x61, 0x2, 0x2b3, 
    0x2b0, 0x3, 0x2, 0x2, 0x2, 0x2b3, 0x2b1, 0x3, 0x2, 0x2, 0x2, 0x2b3, 
    0x2b2, 0x3, 0x2, 0x2, 0x2, 0x2b4, 0x83, 0x3, 0x2, 0x2, 0x2, 0x2b5, 0x2b6, 
    0x7, 0x2b, 0x2, 0x2, 0x2b6, 0x2b8, 0x7, 0x4, 0x2, 0x2, 0x2b7, 0x2b9, 
    0x5, 0x86, 0x44, 0x2, 0x2b8, 0x2b7, 0x3, 0x2, 0x2, 0x2, 0x2b9, 0x2ba, 
    0x3, 0x2, 0x2, 0x2, 0x2ba, 0x2b8, 0x3, 0x2, 0x2, 0x2, 0x2ba, 0x2bb, 
    0x3, 0x2, 0x2, 0x2, 0x2bb, 0x2bc, 0x3, 0x2, 0x2, 0x2, 0x2bc, 0x2bd, 
    0x7, 0x5, 0x2, 0x2, 0x2bd, 0x85, 0x3, 0x2, 0x2, 0x2, 0x2be, 0x2bf, 0x7, 
    0x4e, 0x2, 0x2, 0x2bf, 0x2c0, 0x7, 0x7, 0x2, 0x2, 0x2c0, 0x2c1, 0x7, 
    0x4e, 0x2, 0x2, 0x2c1, 0x87, 0x3, 0x2, 0x2, 0x2, 0x2c2, 0x2cb, 0x5, 
    0x8a, 0x46, 0x2, 0x2c3, 0x2cb, 0x5, 0x8c, 0x47, 0x2, 0x2c4, 0x2cb, 0x5, 
    0x8e, 0x48, 0x2, 0x2c5, 0x2cb, 0x5, 0x90, 0x49, 0x2, 0x2c6, 0x2cb, 0x5, 
    0x92, 0x4a, 0x2, 0x2c7, 0x2cb, 0x5, 0xa2, 0x52, 0x2, 0x2c8, 0x2cb, 0x5, 
    0xa8, 0x55, 0x2, 0x2c9, 0x2cb, 0x5, 0xac, 0x57, 0x2, 0x2ca, 0x2c2, 0x3, 
    0x2, 0x2, 0x2, 0x2ca, 0x2c3, 0x3, 0x2, 0x2, 0x2, 0x2ca, 0x2c4, 0x3, 
    0x2, 0x2, 0x2, 0x2ca, 0x2c5, 0x3, 0x2, 0x2, 0x2, 0x2ca, 0x2c6, 0x3, 
    0x2, 0x2, 0x2, 0x2ca, 0x2c7, 0x3, 0x2, 0x2, 0x2, 0x2ca, 0x2c8, 0x3, 
    0x2, 0x2, 0x2, 0x2ca, 0x2c9, 0x3, 0x2, 0x2, 0x2, 0x2cb, 0x89, 0x3, 0x2, 
    0x2, 0x2, 0x2cc, 0x2cd, 0x7, 0x2c, 0x2, 0x2, 0x2cd, 0x2ce, 0x7, 0x51, 
    0x2, 0x2, 0x2ce, 0x8b, 0x3, 0x2, 0x2, 0x2, 0x2cf, 0x2d0, 0x7, 0x2d, 
    0x2, 0x2, 0x2d0, 0x2d1, 0x7, 0x52, 0x2, 0x2, 0x2d1, 0x8d, 0x3, 0x2, 
    0x2, 0x2, 0x2d2, 0x2d3, 0x7, 0x2e, 0x2, 0x2, 0x2d3, 0x2d4, 0x7, 0x4f, 
    0x2, 0x2, 0x2d4, 0x8f, 0x3, 0x2, 0x2, 0x2, 0x2d5, 0x2d6, 0x7, 0x2f, 
    0x2, 0x2, 0x2d6, 0x91, 0x3, 0x2, 0x2, 0x2, 0x2d7, 0x2dc, 0x7, 0x30, 
    0x2, 0x2, 0x2d8, 0x2d9, 0x7, 0x28, 0x2, 0x2, 0x2d9, 0x2da, 0x5, 0x96, 
    0x4c, 0x2, 0x2da, 0x2db, 0x7, 0x29, 0x2, 0x2, 0x2db, 0x2dd, 0x3, 0x2, 
    0x2, 0x2, 0x2dc, 0x2d8, 0x3, 0x2, 0x2, 0x2, 0x2dc, 0x2dd, 0x3, 0x2, 
    0x2, 0x2, 0x2dd, 0x2df, 0x3, 0x2, 0x2, 0x2, 0x2de, 0x2e0, 0x5, 0x94, 
    0x4b, 0x2, 0x2df, 0x2de, 0x3, 0x2, 0x2, 0x2, 0x2df, 0x2e0, 0x3, 0x2, 
    0x2, 0x2, 0x2e0, 0x93, 0x3, 0x2, 0x2, 0x2, 0x2e1, 0x2e2, 0x7, 0x9, 0x2, 
    0x2, 0x2e2, 0x2e3, 0x5, 0x98, 0x4d, 0x2, 0x2e3, 0x2e4, 0x7, 0xa, 0x2, 
    0x2, 0x2e4, 0x2e5, 0x5, 0x9a, 0x4e, 0x2, 0x2e5, 0x2e6, 0x7, 0xc, 0x2, 
    0x2, 0x2e6, 0x2f2, 0x3, 0x2, 0x2, 0x2, 0x2e7, 0x2e8, 0x7, 0x9, 0x2, 
    0x2, 0x2e8, 0x2e9, 0x5, 0x98, 0x4d, 0x2, 0x2e9, 0x2ea, 0x7, 0xa, 0x2, 
    0x2, 0x2ea, 0x2eb, 0x5, 0x9a, 0x4e, 0x2, 0x2eb, 0x2ec, 0x7, 0xa, 0x2, 
    0x2, 0x2ec, 0x2ed, 0x5, 0x9c, 0x4f, 0x2, 0x2ed, 0x2ee, 0x7, 0xa, 0x2, 
    0x2, 0x2ee, 0x2ef, 0x5, 0x9e, 0x50, 0x2, 0x2ef, 0x2f0, 0x7, 0xc, 0x2, 
    0x2, 0x2f0, 0x2f2, 0x3, 0x2, 0x2, 0x2, 0x2f1, 0x2e1, 0x3, 0x2, 0x2, 
    0x2, 0x2f1, 0x2e7, 0x3, 0x2, 0x2, 0x2, 0x2f2, 0x95, 0x3, 0x2, 0x2, 0x2, 
    0x2f3, 0x2f4, 0x7, 0x55, 0x2, 0x2, 0x2f4, 0x97, 0x3, 0x2, 0x2, 0x2, 
    0x2f5, 0x2f6, 0x5, 0xa0, 0x51, 0x2, 0x2f6, 0x99, 0x3, 0x2, 0x2, 0x2, 
    0x2f7, 0x2f8, 0x5, 0xa0, 0x51, 0x2, 0x2f8, 0x9b, 0x3, 0x2, 0x2, 0x2, 
    0x2f9, 0x2fa, 0x7, 0x4c, 0x2, 0x2, 0x2fa, 0x9d, 0x3, 0x2, 0x2, 0x2, 
    0x2fb, 0x2fc, 0x7, 0x4c, 0x2, 0x2, 0x2fc, 0x9f, 0x3, 0x2, 0x2, 0x2, 
    0x2fd, 0x2fe, 0x9, 0x4, 0x2, 0x2, 0x2fe, 0xa1, 0x3, 0x2, 0x2, 0x2, 0x2ff, 
    0x304, 0x7, 0x35, 0x2, 0x2, 0x300, 0x301, 0x7, 0x28, 0x2, 0x2, 0x301, 
    0x302, 0x5, 0x96, 0x4c, 0x2, 0x302, 0x303, 0x7, 0x29, 0x2, 0x2, 0x303, 
    0x305, 0x3, 0x2, 0x2, 0x2, 0x304, 0x300, 0x3, 0x2, 0x2, 0x2, 0x304, 
    0x305, 0x3, 0x2, 0x2, 0x2, 0x305, 0x306, 0x3, 0x2, 0x2, 0x2, 0x306, 
    0x315, 0x5, 0xa4, 0x53, 0x2, 0x307, 0x30c, 0x7, 0x35, 0x2, 0x2, 0x308, 
    0x309, 0x7, 0x28, 0x2, 0x2, 0x309, 0x30a, 0x5, 0x96, 0x4c, 0x2, 0x30a, 
    0x30b, 0x7, 0x29, 0x2, 0x2, 0x30b, 0x30d, 0x3, 0x2, 0x2, 0x2, 0x30c, 
    0x308, 0x3, 0x2, 0x2, 0x2, 0x30c, 0x30d, 0x3, 0x2, 0x2, 0x2, 0x30d, 
    0x30e, 0x3, 0x2, 0x2, 0x2, 0x30e, 0x30f, 0x7, 0x9, 0x2, 0x2, 0x30f, 
    0x310, 0x5, 0xa4, 0x53, 0x2, 0x310, 0x311, 0x7, 0xa, 0x2, 0x2, 0x311, 
    0x312, 0x5, 0xa6, 0x54, 0x2, 0x312, 0x313, 0x7, 0xc, 0x2, 0x2, 0x313, 
    0x315, 0x3, 0x2, 0x2, 0x2, 0x314, 0x2ff, 0x3, 0x2, 0x2, 0x2, 0x314, 
    0x307, 0x3, 0x2, 0x2, 0x2, 0x315, 0xa3, 0x3, 0x2, 0x2, 0x2, 0x316, 0x317, 
    0x7, 0x4d, 0x2, 0x2, 0x317, 0xa5, 0x3, 0x2, 0x2, 0x2, 0x318, 0x319, 
    0x7, 0x4d, 0x2, 0x2, 0x319, 0xa7, 0x3, 0x2, 0x2, 0x2, 0x31a, 0x31f, 
    0x7, 0x36, 0x2, 0x2, 0x31b, 0x31c, 0x7, 0x28, 0x2, 0x2, 0x31c, 0x31d, 
    0x5, 0x96, 0x4c, 0x2, 0x31d, 0x31e, 0x7, 0x29, 0x2, 0x2, 0x31e, 0x320, 
    0x3, 0x2, 0x2, 0x2, 0x31f, 0x31b, 0x3, 0x2, 0x2, 0x2, 0x31f, 0x320, 
    0x3, 0x2, 0x2, 0x2, 0x320, 0x321, 0x3, 0x2, 0x2, 0x2, 0x321, 0x322, 
    0x5, 0xaa, 0x56, 0x2, 0x322, 0xa9, 0x3, 0x2, 0x2, 0x2, 0x323, 0x324, 
    0x9, 0x5, 0x2, 0x2, 0x324, 0xab, 0x3, 0x2, 0x2, 0x2, 0x325, 0x326, 0x7, 
    0x37, 0x2, 0x2, 0x326, 0x328, 0x7, 0x4, 0x2, 0x2, 0x327, 0x329, 0x5, 
    0xae, 0x58, 0x2, 0x328, 0x327, 0x3, 0x2, 0x2, 0x2, 0x329, 0x32a, 0x3, 
    0x2, 0x2, 0x2, 0x32a, 0x328, 0x3, 0x2, 0x2, 0x2, 0x32a, 0x32b, 0x3, 
    0x2, 0x2, 0x2, 0x32b, 0x32c, 0x3, 0x2, 0x2, 0x2, 0x32c, 0x32d, 0x7, 
    0x5, 0x2, 0x2, 0x32d, 0xad, 0x3, 0x2, 0x2, 0x2, 0x32e, 0x336, 0x5, 0xb0, 
    0x59, 0x2, 0x32f, 0x336, 0x5, 0xb2, 0x5a, 0x2, 0x330, 0x336, 0x5, 0xb4, 
    0x5b, 0x2, 0x331, 0x336, 0x5, 0xb6, 0x5c, 0x2, 0x332, 0x336, 0x5, 0xb8, 
    0x5d, 0x2, 0x333, 0x336, 0x5, 0xba, 0x5e, 0x2, 0x334, 0x336, 0x5, 0xbc, 
    0x5f, 0x2, 0x335, 0x32e, 0x3, 0x2, 0x2, 0x2, 0x335, 0x32f, 0x3, 0x2, 
    0x2, 0x2, 0x335, 0x330, 0x3, 0x2, 0x2, 0x2, 0x335, 0x331, 0x3, 0x2, 
    0x2, 0x2, 0x335, 0x332, 0x3, 0x2, 0x2, 0x2, 0x335, 0x333, 0x3, 0x2, 
    0x2, 0x2, 0x335, 0x334, 0x3, 0x2, 0x2, 0x2, 0x336, 0xaf, 0x3, 0x2, 0x2, 
    0x2, 0x337, 0x338, 0x7, 0x38, 0x2, 0x2, 0x338, 0x339, 0x7, 0x55, 0x2, 
    0x2, 0x339, 0xb1, 0x3, 0x2, 0x2, 0x2, 0x33a, 0x33b, 0x7, 0x39, 0x2, 
    0x2, 0x33b, 0x33c, 0x7, 0x55, 0x2, 0x2, 0x33c, 0xb3, 0x3, 0x2, 0x2, 
    0x2, 0x33d, 0x33e, 0x7, 0x3a, 0x2, 0x2, 0x33e, 0x33f, 0x7, 0x55, 0x2, 
    0x2, 0x33f, 0xb5, 0x3, 0x2, 0x2, 0x2, 0x340, 0x341, 0x7, 0x3b, 0x2, 
    0x2, 0x341, 0x342, 0x7, 0x4f, 0x2, 0x2, 0x342, 0xb7, 0x3, 0x2, 0x2, 
    0x2, 0x343, 0x344, 0x7, 0x2a, 0x2, 0x2, 0x344, 0x345, 0x5, 0xbe, 0x60, 
    0x2, 0x345, 0xb9, 0x3, 0x2, 0x2, 0x2, 0x346, 0x347, 0x7, 0x3c, 0x2, 
    0x2, 0x347, 0x348, 0x5, 0xbe, 0x60, 0x2, 0x348, 0xbb, 0x3, 0x2, 0x2, 
    0x2, 0x349, 0x34a, 0x7, 0x3d, 0x2, 0x2, 0x34a, 0x34b, 0x5, 0xbe, 0x60, 
    0x2, 0x34b, 0xbd, 0x3, 0x2, 0x2, 0x2, 0x34c, 0x34d, 0x9, 0x6, 0x2, 0x2, 
    0x34d, 0xbf, 0x3, 0x2, 0x2, 0x2, 0x34e, 0x34f, 0x7, 0x46, 0x2, 0x2, 
    0x34f, 0x350, 0x5, 0xc2, 0x62, 0x2, 0x350, 0xc1, 0x3, 0x2, 0x2, 0x2, 
    0x351, 0x358, 0x5, 0xc4, 0x63, 0x2, 0x352, 0x358, 0x7, 0x55, 0x2, 0x2, 
    0x353, 0x354, 0x5, 0xc4, 0x63, 0x2, 0x354, 0x355, 0x7, 0x5c, 0x2, 0x2, 
    0x355, 0x356, 0x7, 0x55, 0x2, 0x2, 0x356, 0x358, 0x3, 0x2, 0x2, 0x2, 
    0x357, 0x351, 0x3, 0x2, 0x2, 0x2, 0x357, 0x352, 0x3, 0x2, 0x2, 0x2, 
    0x357, 0x353, 0x3, 0x2, 0x2, 0x2, 0x358, 0xc3, 0x3, 0x2, 0x2, 0x2, 0x359, 
    0x35a, 0x9, 0x7, 0x2, 0x2, 0x35a, 0xc5, 0x3, 0x2, 0x2, 0x2, 0x20, 0xcc, 
    0xd1, 0xe0, 0xfc, 0x1d9, 0x1e0, 0x1e4, 0x1e7, 0x1ea, 0x1ee, 0x1f1, 0x26d, 
    0x273, 0x280, 0x289, 0x295, 0x2a7, 0x2b3, 0x2ba, 0x2ca, 0x2dc, 0x2df, 
    0x2f1, 0x304, 0x30c, 0x314, 0x31f, 0x32a, 0x335, 0x357, 
  };

  atn::ATNDeserializer deserializer;
  _atn = deserializer.deserialize(_serializedATN);

  size_t count = _atn.getNumberOfDecisions();
  _decisionToDFA.reserve(count);
  for (size_t i = 0; i < count; i++) { 
    _decisionToDFA.emplace_back(_atn.getDecisionState(i), i);
  }
}

UShaderParser::Initializer UShaderParser::_init;
