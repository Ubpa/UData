
// Generated from UShader.g4 by ANTLR 4.8

#pragma once


#include "antlr4-runtime.h"


namespace Ubpa::Utopia::details {


class  UShaderParser : public antlr4::Parser {
public:
  enum {
    T__0 = 1, T__1 = 2, T__2 = 3, T__3 = 4, T__4 = 5, T__5 = 6, T__6 = 7, 
    T__7 = 8, T__8 = 9, T__9 = 10, T__10 = 11, T__11 = 12, T__12 = 13, T__13 = 14, 
    T__14 = 15, T__15 = 16, T__16 = 17, T__17 = 18, T__18 = 19, T__19 = 20, 
    T__20 = 21, T__21 = 22, T__22 = 23, T__23 = 24, T__24 = 25, T__25 = 26, 
    T__26 = 27, T__27 = 28, T__28 = 29, T__29 = 30, T__30 = 31, T__31 = 32, 
    T__32 = 33, T__33 = 34, T__34 = 35, T__35 = 36, T__36 = 37, T__37 = 38, 
    T__38 = 39, T__39 = 40, T__40 = 41, T__41 = 42, T__42 = 43, T__43 = 44, 
    T__44 = 45, T__45 = 46, T__46 = 47, T__47 = 48, T__48 = 49, T__49 = 50, 
    T__50 = 51, T__51 = 52, T__52 = 53, T__53 = 54, T__54 = 55, T__55 = 56, 
    T__56 = 57, T__57 = 58, T__58 = 59, T__59 = 60, T__60 = 61, T__61 = 62, 
    T__62 = 63, T__63 = 64, T__64 = 65, T__65 = 66, T__66 = 67, T__67 = 68, 
    T__68 = 69, T__69 = 70, T__70 = 71, T__71 = 72, T__72 = 73, BlendFactorAlpha = 74, 
    BlendOpEnum = 75, StringLiteral = 76, Comparator = 77, BooleanLiteral = 78, 
    FillMode = 79, CullMode = 80, RootDescriptorType = 81, ColorMask_RGBA = 82, 
    IntegerLiteral = 83, FloatingLiteral = 84, ExponentPart = 85, DecimalLiteral = 86, 
    OctalLiteral = 87, HexadecimalLiteral = 88, BinaryLiteral = 89, Sign = 90, 
    ID = 91, Whitespace = 92, Newline = 93, BlockComment = 94, LineComment = 95
  };

  enum {
    RuleShader = 0, RuleShader_name = 1, RuleHlsl = 2, RuleProperty_block = 3, 
    RuleProperty = 4, RuleProperty_bool = 5, RuleProperty_int = 6, RuleProperty_uint = 7, 
    RuleProperty_float = 8, RuleProperty_double = 9, RuleProperty_bool2 = 10, 
    RuleProperty_bool3 = 11, RuleProperty_bool4 = 12, RuleProperty_int2 = 13, 
    RuleProperty_int3 = 14, RuleProperty_int4 = 15, RuleProperty_uint2 = 16, 
    RuleProperty_uint3 = 17, RuleProperty_uint4 = 18, RuleProperty_float2 = 19, 
    RuleProperty_float3 = 20, RuleProperty_float4 = 21, RuleProperty_double2 = 22, 
    RuleProperty_double3 = 23, RuleProperty_double4 = 24, RuleProperty_2D = 25, 
    RuleProperty_cube = 26, RuleProperty_rgb = 27, RuleProperty_rgba = 28, 
    RuleVal_bool = 29, RuleVal_int = 30, RuleVal_uint = 31, RuleVal_float = 32, 
    RuleVal_double = 33, RuleVal_bool2 = 34, RuleVal_bool3 = 35, RuleVal_bool4 = 36, 
    RuleVal_int2 = 37, RuleVal_int3 = 38, RuleVal_int4 = 39, RuleVal_uint2 = 40, 
    RuleVal_uint3 = 41, RuleVal_uint4 = 42, RuleVal_float2 = 43, RuleVal_float3 = 44, 
    RuleVal_float4 = 45, RuleVal_double2 = 46, RuleVal_double3 = 47, RuleVal_double4 = 48, 
    RuleVal_tex2d = 49, RuleDefault_texture_2d = 50, RuleVal_texcube = 51, 
    RuleDefault_texture_cube = 52, RuleProperty_name = 53, RuleDisplay_name = 54, 
    RuleRoot_signature = 55, RuleRoot_parameter = 56, RuleRegister_index = 57, 
    RuleShader_register = 58, RuleRegister_space = 59, RuleRegister_num = 60, 
    RulePass = 61, RuleVs = 62, RulePs = 63, RulePass_statement = 64, RuleTags = 65, 
    RuleTag = 66, RuleRender_state_setup = 67, RuleFill = 68, RuleCull = 69, 
    RuleZtest = 70, RuleZwrite_off = 71, RuleBlend = 72, RuleBlend_expr = 73, 
    RuleIndex = 74, RuleBlend_src_factor_color = 75, RuleBlend_dst_factor_color = 76, 
    RuleBlend_src_factor_alpha = 77, RuleBlend_dst_factor_alpha = 78, RuleBlend_factor = 79, 
    RuleBlend_op = 80, RuleBlend_op_color = 81, RuleBlend_op_alpha = 82, 
    RuleColor_mask = 83, RuleColor_mask_value = 84, RuleStencil = 85, RuleStencil_state_setup = 86, 
    RuleStencil_ref = 87, RuleStencil_mask_read = 88, RuleStencil_mask_write = 89, 
    RuleStencil_compare = 90, RuleStencil_pass = 91, RuleStencil_fail = 92, 
    RuleStencil_zfail = 93, RuleStencil_op = 94, RuleQueue = 95, RuleVal_queue = 96, 
    RuleQueue_key = 97
  };

  UShaderParser(antlr4::TokenStream *input);
  ~UShaderParser();

  virtual std::string getGrammarFileName() const override;
  virtual const antlr4::atn::ATN& getATN() const override { return _atn; };
  virtual const std::vector<std::string>& getTokenNames() const override { return _tokenNames; }; // deprecated: use vocabulary instead.
  virtual const std::vector<std::string>& getRuleNames() const override;
  virtual antlr4::dfa::Vocabulary& getVocabulary() const override;


  class ShaderContext;
  class Shader_nameContext;
  class HlslContext;
  class Property_blockContext;
  class PropertyContext;
  class Property_boolContext;
  class Property_intContext;
  class Property_uintContext;
  class Property_floatContext;
  class Property_doubleContext;
  class Property_bool2Context;
  class Property_bool3Context;
  class Property_bool4Context;
  class Property_int2Context;
  class Property_int3Context;
  class Property_int4Context;
  class Property_uint2Context;
  class Property_uint3Context;
  class Property_uint4Context;
  class Property_float2Context;
  class Property_float3Context;
  class Property_float4Context;
  class Property_double2Context;
  class Property_double3Context;
  class Property_double4Context;
  class Property_2DContext;
  class Property_cubeContext;
  class Property_rgbContext;
  class Property_rgbaContext;
  class Val_boolContext;
  class Val_intContext;
  class Val_uintContext;
  class Val_floatContext;
  class Val_doubleContext;
  class Val_bool2Context;
  class Val_bool3Context;
  class Val_bool4Context;
  class Val_int2Context;
  class Val_int3Context;
  class Val_int4Context;
  class Val_uint2Context;
  class Val_uint3Context;
  class Val_uint4Context;
  class Val_float2Context;
  class Val_float3Context;
  class Val_float4Context;
  class Val_double2Context;
  class Val_double3Context;
  class Val_double4Context;
  class Val_tex2dContext;
  class Default_texture_2dContext;
  class Val_texcubeContext;
  class Default_texture_cubeContext;
  class Property_nameContext;
  class Display_nameContext;
  class Root_signatureContext;
  class Root_parameterContext;
  class Register_indexContext;
  class Shader_registerContext;
  class Register_spaceContext;
  class Register_numContext;
  class PassContext;
  class VsContext;
  class PsContext;
  class Pass_statementContext;
  class TagsContext;
  class TagContext;
  class Render_state_setupContext;
  class FillContext;
  class CullContext;
  class ZtestContext;
  class Zwrite_offContext;
  class BlendContext;
  class Blend_exprContext;
  class IndexContext;
  class Blend_src_factor_colorContext;
  class Blend_dst_factor_colorContext;
  class Blend_src_factor_alphaContext;
  class Blend_dst_factor_alphaContext;
  class Blend_factorContext;
  class Blend_opContext;
  class Blend_op_colorContext;
  class Blend_op_alphaContext;
  class Color_maskContext;
  class Color_mask_valueContext;
  class StencilContext;
  class Stencil_state_setupContext;
  class Stencil_refContext;
  class Stencil_mask_readContext;
  class Stencil_mask_writeContext;
  class Stencil_compareContext;
  class Stencil_passContext;
  class Stencil_failContext;
  class Stencil_zfailContext;
  class Stencil_opContext;
  class QueueContext;
  class Val_queueContext;
  class Queue_keyContext; 

  class  ShaderContext : public antlr4::ParserRuleContext {
  public:
    ShaderContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Shader_nameContext *shader_name();
    HlslContext *hlsl();
    Root_signatureContext *root_signature();
    Property_blockContext *property_block();
    std::vector<PassContext *> pass();
    PassContext* pass(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ShaderContext* shader();

  class  Shader_nameContext : public antlr4::ParserRuleContext {
  public:
    Shader_nameContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *StringLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Shader_nameContext* shader_name();

  class  HlslContext : public antlr4::ParserRuleContext {
  public:
    HlslContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *StringLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  HlslContext* hlsl();

  class  Property_blockContext : public antlr4::ParserRuleContext {
  public:
    Property_blockContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<PropertyContext *> property();
    PropertyContext* property(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_blockContext* property_block();

  class  PropertyContext : public antlr4::ParserRuleContext {
  public:
    PropertyContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_boolContext *property_bool();
    Property_intContext *property_int();
    Property_uintContext *property_uint();
    Property_floatContext *property_float();
    Property_doubleContext *property_double();
    Property_bool2Context *property_bool2();
    Property_bool3Context *property_bool3();
    Property_bool4Context *property_bool4();
    Property_int2Context *property_int2();
    Property_int3Context *property_int3();
    Property_int4Context *property_int4();
    Property_uint2Context *property_uint2();
    Property_uint3Context *property_uint3();
    Property_uint4Context *property_uint4();
    Property_float2Context *property_float2();
    Property_float3Context *property_float3();
    Property_float4Context *property_float4();
    Property_double2Context *property_double2();
    Property_double3Context *property_double3();
    Property_double4Context *property_double4();
    Property_2DContext *property_2D();
    Property_cubeContext *property_cube();
    Property_rgbContext *property_rgb();
    Property_rgbaContext *property_rgba();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  PropertyContext* property();

  class  Property_boolContext : public antlr4::ParserRuleContext {
  public:
    Property_boolContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_boolContext *val_bool();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_boolContext* property_bool();

  class  Property_intContext : public antlr4::ParserRuleContext {
  public:
    Property_intContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_intContext *val_int();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_intContext* property_int();

  class  Property_uintContext : public antlr4::ParserRuleContext {
  public:
    Property_uintContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_uintContext *val_uint();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_uintContext* property_uint();

  class  Property_floatContext : public antlr4::ParserRuleContext {
  public:
    Property_floatContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_floatContext *val_float();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_floatContext* property_float();

  class  Property_doubleContext : public antlr4::ParserRuleContext {
  public:
    Property_doubleContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_doubleContext *val_double();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_doubleContext* property_double();

  class  Property_bool2Context : public antlr4::ParserRuleContext {
  public:
    Property_bool2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_bool2Context *val_bool2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_bool2Context* property_bool2();

  class  Property_bool3Context : public antlr4::ParserRuleContext {
  public:
    Property_bool3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_bool3Context *val_bool3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_bool3Context* property_bool3();

  class  Property_bool4Context : public antlr4::ParserRuleContext {
  public:
    Property_bool4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_bool4Context *val_bool4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_bool4Context* property_bool4();

  class  Property_int2Context : public antlr4::ParserRuleContext {
  public:
    Property_int2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_int2Context *val_int2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_int2Context* property_int2();

  class  Property_int3Context : public antlr4::ParserRuleContext {
  public:
    Property_int3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_int3Context *val_int3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_int3Context* property_int3();

  class  Property_int4Context : public antlr4::ParserRuleContext {
  public:
    Property_int4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_int4Context *val_int4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_int4Context* property_int4();

  class  Property_uint2Context : public antlr4::ParserRuleContext {
  public:
    Property_uint2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_uint2Context *val_uint2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_uint2Context* property_uint2();

  class  Property_uint3Context : public antlr4::ParserRuleContext {
  public:
    Property_uint3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_uint3Context *val_uint3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_uint3Context* property_uint3();

  class  Property_uint4Context : public antlr4::ParserRuleContext {
  public:
    Property_uint4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_uint4Context *val_uint4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_uint4Context* property_uint4();

  class  Property_float2Context : public antlr4::ParserRuleContext {
  public:
    Property_float2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_float2Context *val_float2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_float2Context* property_float2();

  class  Property_float3Context : public antlr4::ParserRuleContext {
  public:
    Property_float3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_float3Context *val_float3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_float3Context* property_float3();

  class  Property_float4Context : public antlr4::ParserRuleContext {
  public:
    Property_float4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_float4Context *val_float4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_float4Context* property_float4();

  class  Property_double2Context : public antlr4::ParserRuleContext {
  public:
    Property_double2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_double2Context *val_double2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_double2Context* property_double2();

  class  Property_double3Context : public antlr4::ParserRuleContext {
  public:
    Property_double3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_double3Context *val_double3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_double3Context* property_double3();

  class  Property_double4Context : public antlr4::ParserRuleContext {
  public:
    Property_double4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_double4Context *val_double4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_double4Context* property_double4();

  class  Property_2DContext : public antlr4::ParserRuleContext {
  public:
    Property_2DContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_tex2dContext *val_tex2d();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_2DContext* property_2D();

  class  Property_cubeContext : public antlr4::ParserRuleContext {
  public:
    Property_cubeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_texcubeContext *val_texcube();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_cubeContext* property_cube();

  class  Property_rgbContext : public antlr4::ParserRuleContext {
  public:
    Property_rgbContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_float3Context *val_float3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_rgbContext* property_rgb();

  class  Property_rgbaContext : public antlr4::ParserRuleContext {
  public:
    Property_rgbaContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Property_nameContext *property_name();
    Display_nameContext *display_name();
    Val_float4Context *val_float4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_rgbaContext* property_rgba();

  class  Val_boolContext : public antlr4::ParserRuleContext {
  public:
    Val_boolContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *BooleanLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_boolContext* val_bool();

  class  Val_intContext : public antlr4::ParserRuleContext {
  public:
    Val_intContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IntegerLiteral();
    antlr4::tree::TerminalNode *Sign();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_intContext* val_int();

  class  Val_uintContext : public antlr4::ParserRuleContext {
  public:
    Val_uintContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IntegerLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_uintContext* val_uint();

  class  Val_floatContext : public antlr4::ParserRuleContext {
  public:
    Val_floatContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IntegerLiteral();
    antlr4::tree::TerminalNode *Sign();
    antlr4::tree::TerminalNode *FloatingLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_floatContext* val_float();

  class  Val_doubleContext : public antlr4::ParserRuleContext {
  public:
    Val_doubleContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IntegerLiteral();
    antlr4::tree::TerminalNode *Sign();
    antlr4::tree::TerminalNode *FloatingLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_doubleContext* val_double();

  class  Val_bool2Context : public antlr4::ParserRuleContext {
  public:
    Val_bool2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Val_boolContext *> val_bool();
    Val_boolContext* val_bool(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_bool2Context* val_bool2();

  class  Val_bool3Context : public antlr4::ParserRuleContext {
  public:
    Val_bool3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Val_boolContext *> val_bool();
    Val_boolContext* val_bool(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_bool3Context* val_bool3();

  class  Val_bool4Context : public antlr4::ParserRuleContext {
  public:
    Val_bool4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Val_boolContext *> val_bool();
    Val_boolContext* val_bool(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_bool4Context* val_bool4();

  class  Val_int2Context : public antlr4::ParserRuleContext {
  public:
    Val_int2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Val_intContext *> val_int();
    Val_intContext* val_int(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_int2Context* val_int2();

  class  Val_int3Context : public antlr4::ParserRuleContext {
  public:
    Val_int3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Val_intContext *> val_int();
    Val_intContext* val_int(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_int3Context* val_int3();

  class  Val_int4Context : public antlr4::ParserRuleContext {
  public:
    Val_int4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Val_intContext *> val_int();
    Val_intContext* val_int(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_int4Context* val_int4();

  class  Val_uint2Context : public antlr4::ParserRuleContext {
  public:
    Val_uint2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Val_uintContext *> val_uint();
    Val_uintContext* val_uint(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_uint2Context* val_uint2();

  class  Val_uint3Context : public antlr4::ParserRuleContext {
  public:
    Val_uint3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Val_uintContext *> val_uint();
    Val_uintContext* val_uint(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_uint3Context* val_uint3();

  class  Val_uint4Context : public antlr4::ParserRuleContext {
  public:
    Val_uint4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Val_uintContext *> val_uint();
    Val_uintContext* val_uint(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_uint4Context* val_uint4();

  class  Val_float2Context : public antlr4::ParserRuleContext {
  public:
    Val_float2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Val_floatContext *> val_float();
    Val_floatContext* val_float(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_float2Context* val_float2();

  class  Val_float3Context : public antlr4::ParserRuleContext {
  public:
    Val_float3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Val_floatContext *> val_float();
    Val_floatContext* val_float(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_float3Context* val_float3();

  class  Val_float4Context : public antlr4::ParserRuleContext {
  public:
    Val_float4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Val_floatContext *> val_float();
    Val_floatContext* val_float(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_float4Context* val_float4();

  class  Val_double2Context : public antlr4::ParserRuleContext {
  public:
    Val_double2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Val_doubleContext *> val_double();
    Val_doubleContext* val_double(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_double2Context* val_double2();

  class  Val_double3Context : public antlr4::ParserRuleContext {
  public:
    Val_double3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Val_doubleContext *> val_double();
    Val_doubleContext* val_double(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_double3Context* val_double3();

  class  Val_double4Context : public antlr4::ParserRuleContext {
  public:
    Val_double4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Val_doubleContext *> val_double();
    Val_doubleContext* val_double(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_double4Context* val_double4();

  class  Val_tex2dContext : public antlr4::ParserRuleContext {
  public:
    Val_tex2dContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Default_texture_2dContext *default_texture_2d();
    antlr4::tree::TerminalNode *StringLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_tex2dContext* val_tex2d();

  class  Default_texture_2dContext : public antlr4::ParserRuleContext {
  public:
    Default_texture_2dContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Default_texture_2dContext* default_texture_2d();

  class  Val_texcubeContext : public antlr4::ParserRuleContext {
  public:
    Val_texcubeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Default_texture_cubeContext *default_texture_cube();
    antlr4::tree::TerminalNode *StringLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_texcubeContext* val_texcube();

  class  Default_texture_cubeContext : public antlr4::ParserRuleContext {
  public:
    Default_texture_cubeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Default_texture_cubeContext* default_texture_cube();

  class  Property_nameContext : public antlr4::ParserRuleContext {
  public:
    Property_nameContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *ID();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Property_nameContext* property_name();

  class  Display_nameContext : public antlr4::ParserRuleContext {
  public:
    Display_nameContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *StringLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Display_nameContext* display_name();

  class  Root_signatureContext : public antlr4::ParserRuleContext {
  public:
    Root_signatureContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Root_parameterContext *> root_parameter();
    Root_parameterContext* root_parameter(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Root_signatureContext* root_signature();

  class  Root_parameterContext : public antlr4::ParserRuleContext {
  public:
    Root_parameterContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *RootDescriptorType();
    Register_indexContext *register_index();
    Register_numContext *register_num();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Root_parameterContext* root_parameter();

  class  Register_indexContext : public antlr4::ParserRuleContext {
  public:
    Register_indexContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Shader_registerContext *shader_register();
    Register_spaceContext *register_space();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Register_indexContext* register_index();

  class  Shader_registerContext : public antlr4::ParserRuleContext {
  public:
    Shader_registerContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IntegerLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Shader_registerContext* shader_register();

  class  Register_spaceContext : public antlr4::ParserRuleContext {
  public:
    Register_spaceContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IntegerLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Register_spaceContext* register_space();

  class  Register_numContext : public antlr4::ParserRuleContext {
  public:
    Register_numContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IntegerLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Register_numContext* register_num();

  class  PassContext : public antlr4::ParserRuleContext {
  public:
    PassContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    VsContext *vs();
    PsContext *ps();
    std::vector<Pass_statementContext *> pass_statement();
    Pass_statementContext* pass_statement(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  PassContext* pass();

  class  VsContext : public antlr4::ParserRuleContext {
  public:
    VsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *ID();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  VsContext* vs();

  class  PsContext : public antlr4::ParserRuleContext {
  public:
    PsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *ID();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  PsContext* ps();

  class  Pass_statementContext : public antlr4::ParserRuleContext {
  public:
    Pass_statementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Render_state_setupContext *render_state_setup();
    TagsContext *tags();
    QueueContext *queue();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Pass_statementContext* pass_statement();

  class  TagsContext : public antlr4::ParserRuleContext {
  public:
    TagsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<TagContext *> tag();
    TagContext* tag(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TagsContext* tags();

  class  TagContext : public antlr4::ParserRuleContext {
  public:
    TagContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<antlr4::tree::TerminalNode *> StringLiteral();
    antlr4::tree::TerminalNode* StringLiteral(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TagContext* tag();

  class  Render_state_setupContext : public antlr4::ParserRuleContext {
  public:
    Render_state_setupContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    FillContext *fill();
    CullContext *cull();
    ZtestContext *ztest();
    Zwrite_offContext *zwrite_off();
    BlendContext *blend();
    Blend_opContext *blend_op();
    Color_maskContext *color_mask();
    StencilContext *stencil();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Render_state_setupContext* render_state_setup();

  class  FillContext : public antlr4::ParserRuleContext {
  public:
    FillContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *FillMode();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  FillContext* fill();

  class  CullContext : public antlr4::ParserRuleContext {
  public:
    CullContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *CullMode();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  CullContext* cull();

  class  ZtestContext : public antlr4::ParserRuleContext {
  public:
    ZtestContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Comparator();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ZtestContext* ztest();

  class  Zwrite_offContext : public antlr4::ParserRuleContext {
  public:
    Zwrite_offContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Zwrite_offContext* zwrite_off();

  class  BlendContext : public antlr4::ParserRuleContext {
  public:
    BlendContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IndexContext *index();
    Blend_exprContext *blend_expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  BlendContext* blend();

  class  Blend_exprContext : public antlr4::ParserRuleContext {
  public:
    Blend_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Blend_src_factor_colorContext *blend_src_factor_color();
    Blend_dst_factor_colorContext *blend_dst_factor_color();
    Blend_src_factor_alphaContext *blend_src_factor_alpha();
    Blend_dst_factor_alphaContext *blend_dst_factor_alpha();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Blend_exprContext* blend_expr();

  class  IndexContext : public antlr4::ParserRuleContext {
  public:
    IndexContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IntegerLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  IndexContext* index();

  class  Blend_src_factor_colorContext : public antlr4::ParserRuleContext {
  public:
    Blend_src_factor_colorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Blend_factorContext *blend_factor();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Blend_src_factor_colorContext* blend_src_factor_color();

  class  Blend_dst_factor_colorContext : public antlr4::ParserRuleContext {
  public:
    Blend_dst_factor_colorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Blend_factorContext *blend_factor();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Blend_dst_factor_colorContext* blend_dst_factor_color();

  class  Blend_src_factor_alphaContext : public antlr4::ParserRuleContext {
  public:
    Blend_src_factor_alphaContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *BlendFactorAlpha();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Blend_src_factor_alphaContext* blend_src_factor_alpha();

  class  Blend_dst_factor_alphaContext : public antlr4::ParserRuleContext {
  public:
    Blend_dst_factor_alphaContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *BlendFactorAlpha();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Blend_dst_factor_alphaContext* blend_dst_factor_alpha();

  class  Blend_factorContext : public antlr4::ParserRuleContext {
  public:
    Blend_factorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *BlendFactorAlpha();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Blend_factorContext* blend_factor();

  class  Blend_opContext : public antlr4::ParserRuleContext {
  public:
    Blend_opContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Blend_op_colorContext *blend_op_color();
    IndexContext *index();
    Blend_op_alphaContext *blend_op_alpha();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Blend_opContext* blend_op();

  class  Blend_op_colorContext : public antlr4::ParserRuleContext {
  public:
    Blend_op_colorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *BlendOpEnum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Blend_op_colorContext* blend_op_color();

  class  Blend_op_alphaContext : public antlr4::ParserRuleContext {
  public:
    Blend_op_alphaContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *BlendOpEnum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Blend_op_alphaContext* blend_op_alpha();

  class  Color_maskContext : public antlr4::ParserRuleContext {
  public:
    Color_maskContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Color_mask_valueContext *color_mask_value();
    IndexContext *index();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Color_maskContext* color_mask();

  class  Color_mask_valueContext : public antlr4::ParserRuleContext {
  public:
    Color_mask_valueContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IntegerLiteral();
    antlr4::tree::TerminalNode *ColorMask_RGBA();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Color_mask_valueContext* color_mask_value();

  class  StencilContext : public antlr4::ParserRuleContext {
  public:
    StencilContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Stencil_state_setupContext *> stencil_state_setup();
    Stencil_state_setupContext* stencil_state_setup(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  StencilContext* stencil();

  class  Stencil_state_setupContext : public antlr4::ParserRuleContext {
  public:
    Stencil_state_setupContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Stencil_refContext *stencil_ref();
    Stencil_mask_readContext *stencil_mask_read();
    Stencil_mask_writeContext *stencil_mask_write();
    Stencil_compareContext *stencil_compare();
    Stencil_passContext *stencil_pass();
    Stencil_failContext *stencil_fail();
    Stencil_zfailContext *stencil_zfail();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Stencil_state_setupContext* stencil_state_setup();

  class  Stencil_refContext : public antlr4::ParserRuleContext {
  public:
    Stencil_refContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IntegerLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Stencil_refContext* stencil_ref();

  class  Stencil_mask_readContext : public antlr4::ParserRuleContext {
  public:
    Stencil_mask_readContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IntegerLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Stencil_mask_readContext* stencil_mask_read();

  class  Stencil_mask_writeContext : public antlr4::ParserRuleContext {
  public:
    Stencil_mask_writeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IntegerLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Stencil_mask_writeContext* stencil_mask_write();

  class  Stencil_compareContext : public antlr4::ParserRuleContext {
  public:
    Stencil_compareContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Comparator();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Stencil_compareContext* stencil_compare();

  class  Stencil_passContext : public antlr4::ParserRuleContext {
  public:
    Stencil_passContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Stencil_opContext *stencil_op();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Stencil_passContext* stencil_pass();

  class  Stencil_failContext : public antlr4::ParserRuleContext {
  public:
    Stencil_failContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Stencil_opContext *stencil_op();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Stencil_failContext* stencil_fail();

  class  Stencil_zfailContext : public antlr4::ParserRuleContext {
  public:
    Stencil_zfailContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Stencil_opContext *stencil_op();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Stencil_zfailContext* stencil_zfail();

  class  Stencil_opContext : public antlr4::ParserRuleContext {
  public:
    Stencil_opContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Stencil_opContext* stencil_op();

  class  QueueContext : public antlr4::ParserRuleContext {
  public:
    QueueContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Val_queueContext *val_queue();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  QueueContext* queue();

  class  Val_queueContext : public antlr4::ParserRuleContext {
  public:
    Val_queueContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Queue_keyContext *queue_key();
    antlr4::tree::TerminalNode *IntegerLiteral();
    antlr4::tree::TerminalNode *Sign();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Val_queueContext* val_queue();

  class  Queue_keyContext : public antlr4::ParserRuleContext {
  public:
    Queue_keyContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Queue_keyContext* queue_key();


private:
  static std::vector<antlr4::dfa::DFA> _decisionToDFA;
  static antlr4::atn::PredictionContextCache _sharedContextCache;
  static std::vector<std::string> _ruleNames;
  static std::vector<std::string> _tokenNames;

  static std::vector<std::string> _literalNames;
  static std::vector<std::string> _symbolicNames;
  static antlr4::dfa::Vocabulary _vocabulary;
  static antlr4::atn::ATN _atn;
  static std::vector<uint16_t> _serializedATN;


  struct Initializer {
    Initializer();
  };
  static Initializer _init;
};

}  // namespace Ubpa::Utopia::details
