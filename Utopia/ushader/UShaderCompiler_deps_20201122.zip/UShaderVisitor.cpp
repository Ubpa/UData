
// Generated from UShader.g4 by ANTLR 4.8


#include "UShaderVisitor.h"


using namespace Ubpa::Utopia::details;

