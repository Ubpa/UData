#pragma once

#include <crossguid/guid.hpp>
#include <iostream>
#include <unordered_map>

int test(std::ostream &outStream);
